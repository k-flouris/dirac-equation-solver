//Copyright (c) 2014 Jens-Daniel Debus, ETH Zurich
#ifndef MACROS_HPP
#define MACROS_HPP

// #define LB_NDEBUG1   // if defined, level-1 assertions are switched off
// #define LB_NDEBUG2   // if defined, level-2 assertions are switched off
#define MAKE_TESTS   // if defined, preliminary tests are performed

#define LB_OMP 1     // for OMP parallelization (0=off, 1=on) 
#define FILE_OUTPUT_LB 1  // write data to txt files or not
#define FILE_OUTPUT_SPRINGMESH 0  // write data to txt files or not
#define TIME_DIGITS_IN_OUTPUT_FILENAME 8  // number of digits in output files
#define EPSILON (1e-10)  // Precision for comparison between doubles

#define MAX_PARSER_RECURSION_LEVEL 10

// ==================== PACKAGES ====================
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <iomanip>
#include <regex>

// STL Containers:
#include <stack>
#include <vector>
#include <initializer_list>
#include <unordered_map>
#include <unordered_set>
#include <list>
#include <tuple>

// Math:
#include <cmath>
#include <complex>
#include <functional>
#include <algorithm>

// Else:
#include <omp.h>
#include <ctime>
#include <cstdlib>
#include <sys/stat.h>
#include <sys/time.h>
#include <unistd.h>
#include <limits>
#include <utility>
#include <thread>



// ==================== MACROS ====================
#define GET_MACRO(_1,_2,NAME,...) NAME

#ifndef LINE
#define LINE ((std::strrchr(__FILE__,'/') ? std::strrchr(__FILE__,'/')+1 : __FILE__ ) + std::string(":") + std::to_string(__LINE__))
#endif

// Assertions
#ifndef LB_NDEBUG1
#define ASSERT12(cond,message) if(!(cond)) { std::cout << "\n\033[1;31mASSERT1: " << LINE << ": Condition " #cond " not fulfilled!\n" << message << "\033[0m" << std::endl; std::exit(1); }
#else
#define ASSERT12(cond,message) {}
#endif
#define ASSERT11(cond) ASSERT12(cond,"")
#define ASSERT1(...) GET_MACRO(__VA_ARGS__, ASSERT12, ASSERT11)(__VA_ARGS__)

#ifndef LB_NDEBUG2
#define ASSERT22(cond,message) if(!(cond)) { std::cout << "\n\033[1;31mASSERT2: " << LINE << ": Condition " #cond " not fulfilled!\n" << message << "\033[0m" << std::endl; std::exit(1); }
#else
#define ASSERT22(cond,message) {}
#endif
#define ASSERT21(cond) ASSERT22(cond,"")
#define ASSERT2(...) GET_MACRO(__VA_ARGS__, ASSERT22, ASSERT21)(__VA_ARGS__)

// debugging helpers
#ifndef HERE
#define HERE { std::cout << LINE << "Here!" << std::endl; }
#endif
#ifndef EXIT
#define EXIT { std::cout << LINE << "Exiting!" << std::endl; exit(0); }
#endif

// Math
#define MOD(a,b) ((((a)%(b))+(b))%(b)) // periodic mod
#define SIGN(i) ((i<2) ? (+1.) : (-1.))   // spinor sign convention (+,+,-,-)
#define I std::complex<double>(0, 1)

// Convert string to bool
#define BOOL(str) (str == "true" || str == "1")
#define IS_NUMBER(str) (std::regex_match(str, std::regex("^[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?$", std::regex_constants::basic)))
#define SHOW(a) #a



// ============= NAMESPACES =========================
using std::cout;
using std::endl;
using std::flush;
using std::string;
using std::to_string;
using std::vector;
using std::function;
using std::complex;
using std::abs; // Attention: C-version from math.h takes and returns int only




// ============= ENUMERATIONS =========================
enum ExitCode { UNFINISHED = -1, SUCCESS = 0, TIME_LIMIT_REACHED, SIGNAL_CAUGHT, ERROR };
enum LatticeType { D2Q9 };
enum TimeFlag { STATIC, DYNAMIC };
enum BoundaryType  { PERIODIC, EXTRAPOLATION, MOEBIUS, RING, CLOSED, MOEBIUS_PERIODIC };
enum PotentialImplementation  { SCALAR, VECTOR, NORM, XC, VF_XC };
enum HamiltonianType  { DIRAC, GRAPHENE };



// ============== ERROR AND HELP ====================
void print_help (const char* name) {
  std::cout << "Usage: " << name << " [-c configfile] [--[var_name] [value]]" << std::endl;
  exit (SUCCESS);
}

void error (string error_message) {
  cout << "\033[1;31m" << error_message << "\nExiting.\033[0m" << endl;
  exit (ERROR);
}



// ============== FOLDERS ====================
void init_folders (string path) {

  string current_folder ("");
  string delimiters = "/";
  size_t current;
  size_t next = -1;

  do {
    current = next + 1;
    next = path.find_first_of (delimiters, current);
    current_folder += path.substr (current, next-current) + string ("/");
    std::system (string ("mkdir -p '"+current_folder+"'").c_str());
  } while (next != string::npos);
  std::system (string ("mkdir -p '"+path+"/data'").c_str());
}

void init_folders (string path,  string cfgname) {

  init_folders (path);

  // copy config file into data folder
  std::system (string ("cp '"+cfgname+"' '"+path+"'").c_str());
}


// ================= STRING CASTS ====================
// Convert to string (with precision n)
template<typename T> string tostring (const T& v, const int n=16) {
  std::stringstream stream;
  stream << std::setprecision(n) << v;
  return stream.str();
}
  
template<typename T> string tostring (complex<T> v, const int n=6) {
  string plus = (v.imag() < 0) ? "" : "+";
  return tostring (v.real(),n) + plus + tostring (v.imag(),n) + "i";
}

template<typename T> T cast_string (string s);

template<> string cast_string<string> (string s) {
  return s;
};
template<> bool cast_string<bool> (string s) {
  if (s=="false") return false;
  else if (s=="true") return true;
  else error ("ERROR in "+LINE+": Not a boolean: " + s);
};
template<> TimeFlag cast_string<TimeFlag> (string s) {
  if (s=="STATIC") return STATIC;
  else if (s=="DYNAMIC") return DYNAMIC;
  else error ("ERROR in "+LINE+": Geometry mode unknown: " +  s);
};
template<> BoundaryType cast_string<BoundaryType> (string s) {
  if (s=="EXTRAPOLATION") return EXTRAPOLATION;
  else if (s=="PERIODIC") return PERIODIC;
  else if (s=="MOEBIUS") return MOEBIUS;
  else if (s=="RING") return RING;
  else if (s=="CLOSED") return CLOSED;
  else if (s=="MOEBIUS_PERIODIC") return MOEBIUS_PERIODIC;


  else error ("ERROR in "+LINE+": Boundary type unknown: " +  s);
};
template<> PotentialImplementation cast_string<PotentialImplementation> (string s) {
  if (s=="SCALAR") return SCALAR;
  else if (s=="VECTOR") return VECTOR;
  else if (s=="NORM") return NORM;
  else if (s=="XC") return XC;
  else if (s=="VF_XC") return VF_XC;
  else error ("ERROR in "+LINE+": Potential implementation unknown: " +  s);
};

template<> HamiltonianType cast_string<HamiltonianType> (string s) {
  if (s=="GRAPHENE") return GRAPHENE;
  else if (s=="DIRAC") return DIRAC;
  else error ("ERROR in "+LINE+": Potential implementation unknown: " +  s);
};


// ==================== TYPEDEFS ====================
typedef double float_type; // for all real numbers and fields
typedef int_fast32_t size_type; // for spatial/lattice dimension
typedef long sim_time_type; // for the simulation time
typedef long signed_position_type; // for the Position object
typedef unsigned long position_type; // for the Position object




// ==================== HERMITE POLYNOMIALS  ====================
int factorial (int n) {
  return (n==1 || n==0) ? 1 : factorial (n-1) *n;
};

// physicist's Hermite polynomials
float_type Hermite (float_type x, int n) {
  float_type res=0;
  for (int m=0; m<=n/2; m++){
    res += pow (-1,m) *pow (2*x,n-2*m) / (factorial (m) * factorial (n-2*m));
  }
  return factorial (n) *res;
};




// ==================== VECTOR OPERATIONS ====================
// push back to a vector,  if not contained already
template<class T>
void insert_uniquely (std::vector<T>& vec,  T e) {
  if (std::find (vec.begin(), vec.end(), e) ==vec.end())
    vec.push_back (e);
}





// ==================== TIMER CLASS ====================
class Timer {
  private:
    timeval t0, t1;
  public:
    Timer() {};
    void start() {
      gettimeofday (&t0, NULL);
    };
    void stop() {
      gettimeofday (&t1, NULL);
    };
    double duration() {
      return (double) (t1.tv_usec - t0.tv_usec) /1000000 + (double) (t1.tv_sec - t0.tv_sec);
    };
};





// ==================== SPLIT A STRING ======================
std::string remove_token (const std::string& s, char token) {
  std::string s1 (s);
  s1.erase (std::remove (s1.begin(), s1.end(), token), s1.end());
  return s1;

}



std::vector<std::string>& split (const std::string& s, char delim, std::vector<std::string>& elems) {
  std::stringstream ss (s);
  std::string item;
  while (std::getline (ss, item, delim)) {
    elems.push_back (item);
  }
  return elems;
}


std::vector<std::string> split (const std::string& s, char delim) {
  std::vector<std::string> elems;
  split (s, delim, elems);
  elems.erase (std::remove_if (elems.begin(), elems.end(), [] (const std::string& s_) {
    return s_.length() ==0;
  }), elems.end());
  return elems;
}



// to_string with precision
template <typename T>
std::string to_string_with_precision (const T a_value, const int n = 6) {
  std::ostringstream out;
  out << std::setprecision (n) << a_value;
  return out.str();
}



// ================= OSTREAM for standard container types =======================
template < class T >
std::ostream& operator << (std::ostream& os, const std::vector<T>& v) {
  os << "[";
  for (typename std::vector<T>::const_iterator ii = v.begin(); ii != v.end(); ++ii) {
    os << *ii;
    if (ii != v.end()-1) os << ", ";
  }
  os << "]";
  return os;
}

template < class T >
std::ostream& operator << (std::ostream& os, const std::unordered_set<T>& v) {
  os << "[ ";
  for (auto ii = v.begin(); ii != v.end(); ++ii) {
    os << *ii << " ";
  }
  os << "]";
  return os;
}

template < class T,  class U >
std::ostream& operator << (std::ostream& os, const std::unordered_map<T, U>& v) {
  os << "[ ";
  for (auto ii = v.begin(); ii != v.end(); ++ii) {
    os << "(" <<  ii->first << ", " << ii->second << ") ";
  }
  os << "]";
  return os;
}



// ============ FILEOUTSTREAM / FILEINSTREAM for state files ============

class fileoutstream : public std::ofstream {
  private:
    std::ios_base::openmode mode;

  public:
    fileoutstream (const char* filename, std::ios_base::openmode mode_ = std::ios_base::out)
      : std::ofstream (filename, mode_),  mode (mode_) {}

    bool is_binary_mode() {
      return (mode & std::ios_base::binary) == std::ios_base::binary;
    }
};

class fileinstream : public std::ifstream {
  private:
    std::ios_base::openmode mode;

  public:
    fileinstream (const char* filename, std::ios_base::openmode mode_ = std::ios_base::in)
      : std::ifstream (filename, mode_),  mode (mode_) {}

    bool is_binary_mode() {
      return (mode & std::ios_base::binary) == std::ios_base::binary;
    }
};


template<typename T>
fileoutstream& operator << (fileoutstream& out, const T v) {
  if (!out.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  out.write (reinterpret_cast<const char*> (&v), sizeof (T));
  return out;
}

template<typename T>
fileinstream& operator >> (fileinstream& in, T& v) {
  if (!in.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  in.read (reinterpret_cast<char*> (&v), sizeof (T));
  return in;
}

template<typename T>
fileoutstream& operator << (fileoutstream& out, const vector<T>& v) {
  if (!out.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  size_type N = v.size();
  out.write (reinterpret_cast<const char*> (&N), sizeof (size_type));
  out.write (reinterpret_cast<const char*> (v.data()), N*sizeof (T));
  return out;
}

template<typename T>
fileinstream& operator >> (fileinstream& in, vector<T>& v) {
  if (!in.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  size_type N;
  in.read (reinterpret_cast<char*> (&N), sizeof (size_type));
  v.resize (N);
  in.read (reinterpret_cast<char*> (v.data()),N* sizeof (T));
  return in;
}

template<typename T>
fileoutstream& operator << (fileoutstream& out, const vector<vector<T>>& v) {
  if (!out.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  size_type N = v.size();
  out.write (reinterpret_cast<const char*> (&N), sizeof (size_type));
  for (size_type i=0; i<N; i++) {
    size_type Ni = v[i].size();
    out.write (reinterpret_cast<const char*> (&Ni), sizeof (size_type));
    out.write (reinterpret_cast<const char*> (v[i].data()), Ni*sizeof (T));
  }
  return out;
}

template<typename T>
fileinstream& operator >> (fileinstream& in, vector<vector<T>>& v) {
  if (!in.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  size_type N;
  in.read (reinterpret_cast<char*> (&N), sizeof (size_type));
  v.resize (N);
  for (size_type i=0; i<N; i++) {
    size_type Ni;
    in.read (reinterpret_cast<char*> (&Ni), sizeof (size_type));
    v[i].resize (Ni);
    in.read (reinterpret_cast<char*> (v[i].data()), Ni*sizeof (T));
  }
  return in;
}

template<typename T,  typename U>
fileoutstream& operator << (fileoutstream& out, const std::unordered_map<T, U>& v) {
  if (!out.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  size_type N = v.size();
  out.write (reinterpret_cast<const char*> (&N), sizeof (size_type));
  for (auto it = v.begin(); it != v.end(); ++it) {
    T v1 = it->first;
    U v2 = it->second;
    out.write (reinterpret_cast<const char*> (&v1), sizeof (T));
    out.write (reinterpret_cast<const char*> (&v2), sizeof (U));
  }
  return out;
}

template<typename T,  typename U>
fileinstream& operator >> (fileinstream& in,  std::unordered_map<T, U>& v) {
  if (!in.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
  v.clear();
  size_type N;
  in.read (reinterpret_cast<char*> (&N), sizeof (size_type));
  for (size_type i=0; i<N; i++) {
    T v1;
    U v2;
    in.read (reinterpret_cast<char*> (&v1), sizeof (T));
    in.read (reinterpret_cast<char*> (&v2), sizeof (U));
    v.insert (std::make_pair (v1, v2));
  }
  return in;
}

// template<class T, size_type D, size_type O, TensorSymmetryType S>
// fileoutstream& operator << (fileoutstream& out, const Tensor<T, D, O, S>& v) {
//   if (!out.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
//   for (size_type i=0; i<v.size(); i++)
//     out.write (reinterpret_cast<const char*> (&v[i]), sizeof (T));
//   return out;
// }
// 
// template<class T, size_type D, size_type O, TensorSymmetryType S>
// fileinstream& operator >> (fileinstream& in, Tensor<T, D, O, S>& v) {
//   if (!in.is_binary_mode()) error ("ERROR in "+LINE+": Only binary mode supported.");
//   for (size_type i=0; i<v.size(); i++)
//     in.read (reinterpret_cast<char*> (&v[i]), sizeof (T));
//   return in;
// }

#endif

