//Copyright (c) 2015 Jens-Daniel Debus, ETH Zurich
#ifndef LATTICE_HPP
#define LATTICE_HPP

#include "macros.hpp"
#include "tensor.hpp"




namespace { // anonymous namespace to avoid linker errors ("multiple definitions of static members")

    // General template
    template<LatticeType T> class Lattice;

    // Specialization
    template <>
    class Lattice<D2Q9> {

        public:
        constexpr static const size_type D = 2, Q = 9;
        constexpr static const float_type C_SQ = 1./3.;
 

        // Position type conversion
        constexpr static const size_type pos_shift = ( 8*sizeof ( position_type ) ) /D;
        constexpr static const position_type max_pos_unsigned = ( static_cast<position_type> ( 1 ) << pos_shift ) - 1;
        constexpr static const signed_position_type max_pos= + ( static_cast<signed_position_type> ( max_pos_unsigned/2 ) );
        constexpr static const signed_position_type min_pos= - ( static_cast<signed_position_type> ( max_pos_unsigned/2 ) );

        constexpr static const LatticeVector<float_type, D, Q> c = {
            {
                0, -1, 0, 0, 1, -1, -1, 1, 1, 
                0, 0, -1, 1, 0, -1, 1, -1, 1
            }
        };
        
        // Index of lattice vector (x - sign*n_c) //give it a sign and gives index of next neightbour //c is component 
        constexpr static inline const size_type lattice_index( const size_type c,  const size_type sign ) {
	  return (c==0) ? X_PLUS(sign) : Y_PLUS(sign);
	}
        
        constexpr static inline const size_type X_PLUS( const size_type sign ) { 
	  return (sign>0) ? 1 : 4;
	}
        constexpr static inline const size_type Y_PLUS( const size_type sign ) { 
	  return (sign>0) ? 2 : 3;
	}
             
        constexpr static const LatticeScalar<float_type, Q> w =
        {{ 4./9., 1./9., 1./9., 1./9., 1./9., 1./36., 1./36., 1./36., 1./36.}};
        
	// gives the inverse direction of the l 
        constexpr static const LatticeScalar<size_type, Q> l_inv =
        {{0, 4, 3, 2, 1, 8, 7, 6, 5}};
	
        constexpr static const std::pair<size_type, size_type> NN_range = std::make_pair ( 1,5 );

        static float_type dt;

        static inline Vector<size_type, D> p_to_ijk ( const position_type p ) {
            Vector<size_type, D> ijk;
            for ( size_type i=0; i<D; i++ ) {
                // get bit segments 1,..,D
                ijk ( i ) = static_cast<size_type> ( ( p & ( max_pos_unsigned << ( i*pos_shift ) ) ) >> ( i*pos_shift ) );
                // shift to negative numbers
                ijk ( i ) += static_cast<size_type> ( min_pos );
            }
            return ijk;
        }

        static inline position_type ijk_to_p ( Vector<size_type, D> const& ijk ) {
            position_type p = static_cast<position_type> ( 0 );
            for ( size_type i=0; i<D; i++ ) {
                ASSERT2 ( min_pos <= ijk ( i ) && ijk ( i ) <= max_pos );
                p += static_cast<position_type> ( ( ijk ( i ) - min_pos ) << ( i*pos_shift ) ); // shift to positive numbers and to corresponding bit segment
            }
            return p;
        }

        // returns the lattice index of the grid point clostest to the real space coordinates xyz
        static inline Vector<size_type, D> xyz_to_ijk ( Vector<float_type, D> const& xyz ) {
            Vector<size_type, D> ijk;
            for ( size_type i=0; i<D; i++ )
                ijk ( i ) = round ( xyz ( i ) /dt );
            return ijk;
        }

        // translates lattices indices into real space coordinates
        static inline Vector<float_type, D> ijk_to_xyz ( Vector<size_type, D> const& ijk ) {
            Vector<float_type, D> xyz;
            for ( size_type i=0; i<D; i++ )
                xyz ( i ) = ijk ( i ) *dt;
            return xyz;
        }

        static inline position_type xyz_to_p ( Vector<float_type, D> const& xyz ) {
            return  ijk_to_p ( xyz_to_ijk ( xyz ) );
        }

        static inline Vector<float_type, D> p_to_xyz ( const position_type p ) {
            return  ijk_to_xyz ( p_to_ijk ( p ) );
        }
    };







    constexpr LatticeVector<float_type,Lattice<D2Q9>::D, Lattice<D2Q9>::Q> Lattice<D2Q9>::c;
    constexpr LatticeScalar<float_type,Lattice<D2Q9>::Q> Lattice<D2Q9>::w;
    constexpr LatticeScalar<size_type,Lattice<D2Q9>::Q> Lattice<D2Q9>::l_inv;
//     constexpr LatticeScalar<size_type,Lattice<D2Q9>::Q> Lattice<D2Q9>::K_inv;

    float_type Lattice<D2Q9>::dt;

} // end namespace
#endif // !defined LATTICE_HPP


