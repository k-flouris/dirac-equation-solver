//Copyright (c) 2015 Jens-Daniel Debus, ETH Zurich
#ifndef TENSOR_HPP
#define TENSOR_HPP

#include <array>        // std::array
#include <algorithm>    // std::sort
#include <iostream>     // std::cout

#include "macros.hpp"   // only for ASSERTIONS

#define SQ(x) ((x)*(x))

typedef int_fast32_t size_type; // for spatial/lattice dimension

enum TensorSymmetryType { NO_SYM, SYM, SEMI_SYM };

// Declare a base_traits traits class template:
template <class derived_type> struct base_traits;



//================= Vector Expressions =========================

/**
 * @brief CRTP base class for vector expressions
 * @details This class represents a vector expression (e.g. expressions of the form E = a*V+W).
 * These expressions are only evaluated when calling the []-operator
 * when accessing a particular element of the vector expression.
 * In this way, vector expression templates allow for optimization
 * of vector expressions through inlining at compile time
 * (e.g. E[i] is evaluated as (a*V[i] + W[i])).
 * Vector expressions also work for general tensors (using linear indexing).
 * @tparam E Type of the specific vector expression, passed by CRTP
 * @tparam N Dimension of the vector expression
 */
template <class E, size_type N>
class VectorExpression {
  public:
    /// Type of the values stored in the vector
    typedef typename base_traits<E>::value_type value_type;

    /**
     * @brief This operator is used to access the elements of the vector expression
     * @param i Index of the element
     * @return Reference to []-operator of the specific vector expression E, passed via CRTP
     */
    inline value_type operator[] (size_type i) const {
      return static_cast<E const&> (*this) [i];
    }

    /**
     * @brief Returns the dimension of the vector.
     * @return Dimension of the vector expression.
     */
    size_type size() const {
      return N;
    }

    /**
     * @brief Returns a reference to the specific vector expression E.
     */
    operator E& () {
      return static_cast<      E&> (*this);
    }

    /**
     * @brief Returns a const reference to the specific vector expressions E.
     */
    operator E const& () const {
      return static_cast<const E&> (*this);
    }
};


/**
 * @brief Specific vector expression for vector addition (V + W).
 * @tparam E1 Type of the vector expression on the left side of the addition operator.
 * @tparam E2 Type of the vector expression on the right side of the addition operator.
 * @tparam N Length of the vector
 */
template<class E1, class E2, size_type N>
class VectorAddition : public VectorExpression<VectorAddition<E1,E2,N>,N> {

    E1 const& L_;
    E2 const& R_;

  public:
    typedef typename base_traits<VectorAddition<E1,E2,N>>::value_type value_type;

    VectorAddition (VectorExpression<E1,N> const& L, VectorExpression<E2,N> const& R)
      : L_ (L), R_ (R) {};

    inline value_type operator[] (size_type i) const {
      return L_[i] + R_[i];
    }
};



/**
 * @brief Specific vector expression for vector substraction (V - W).
 * @tparam E1 Type of the vector expression on the left side of the minus operator.
 * @tparam E2 Type of the vector expression on the right side of the minus operator.
 * @tparam N Length of the vector
 */
template<class E1, class E2, size_type N>
class VectorDifference : public VectorExpression<VectorDifference<E1,E2,N>,N> {

    E1 const& L_;
    E2 const& R_;

  public:
    typedef typename base_traits<VectorDifference<E1,E2,N>>::value_type value_type;

    VectorDifference (VectorExpression<E1,N> const& L, VectorExpression<E2,N> const& R)
      : L_ (L), R_ (R) {};

    inline value_type operator[] (size_type i) const {
      return L_[i] - R_[i];
    }
};


/**
 * @brief Specific vector expression for scalar-vector multiplication (a*V).
 * @tparam T Type of the scalar.
 * @tparam E Type of the vector expression
 * @tparam N Length of the vector
 */
template<class T, class E, size_type N>
class VectorScalarMultiplication : public VectorExpression<VectorScalarMultiplication<T,E,N>,N> {

    T const& a_;
    E const& V_;

  public:
    typedef typename base_traits<VectorScalarMultiplication<T,E,N>>::value_type value_type;

    VectorScalarMultiplication (T const& a, VectorExpression<E,N> const& V)
      : a_ (a), V_ (V) {};

    inline value_type operator[] (size_type i) const {
      return a_ * V_[i];
    }
};


/**
 * @brief Specific vector expression for scalar-vector division (V/a).
 * @tparam T Type of the scalar.
 * @tparam E Type of the vector expression
 * @tparam N Length of the vector
 */
template<class T, class E, size_type N>
class VectorScalarDivision : public VectorExpression<VectorScalarDivision<T,E,N>,N> {

    T const& a_;
    E const& V_;

  public:
    typedef typename base_traits<VectorScalarDivision<T,E,N>>::value_type value_type;

    VectorScalarDivision (T const& a, VectorExpression<E,N> const& V)
      : a_ (a), V_ (V) {};

    inline value_type operator[] (size_type i) const {
      return V_[i] / a_;
    }
};



/**
 * @brief Specific vector expressions for vector negation (-V).
 * @tparam E Type of the vector expression
 * @tparam N Length of the vector
 */
template<class E, size_type N>
class VectorMirroring : public VectorExpression<VectorMirroring<E,N>,N> {

    E const& V_;

  public:
    typedef typename base_traits<VectorMirroring<E,N>>::value_type value_type;

    VectorMirroring (VectorExpression<E,N> const& V)
      : V_ (V) {};

    inline value_type operator[] (size_type i) const {
      return -V_[i];
    }
};







// =================== Vector base class ======================

/**
 * @brief Vector base class, containing the data. This vector base is also the specific vector expression for a simple vector.
 * @details The vector base class contains the (linear) data container, used for all tensors.
 * @tparam T Value type (type of the vector elements)
 * @tparam N Length of the vector
 */
template <class T, size_type N>
class VectorBase : public VectorExpression<VectorBase<T,N>,N> {

  protected:
    std::array<T,N> data_;

  public:
    typedef typename base_traits<VectorBase<T,N>>::value_type value_type;

    /// Default constructor
    VectorBase() {};


    /**
     * @brief Constructor to initialize a tensor from a brace-enclosed initializer list or from a std::array
     * @param a Number with which all elements are to be initialized
     */
    VectorBase (T a) {
      for (size_type i=0; i<N; ++i)
        data_[i]=a;
    };


    /**
     * @brief Constructor to initialize a VectorBase object from a brace-enclosed initializer list or from a std::array
     * @param rhs Brace-enclosed initializer list, e.g. {1,2,...}, or std::array
     *
     * Example:
     * ~~~{.cpp}
     *     VectorBase<int,3> v1 ({ 1,5,9 });
     *     VectorBase<double,4> v2 ({ 1.0,5.2,9.5,-0.1 });
     *
     *  std::array<int,3> a {{ 1,2,3 }};
     *     VectorBase<int,3> v3 (a);
     * ~~~
     */
    constexpr VectorBase (std::array<T,N> const& rhs) : data_ (rhs) {};


    /**
     * @brief Copy Constructor to initialize a vector as a copy of another VectorBase
     * @param rhs Vector to be copied
     *
     * Example:
     * ~~~{.cpp}
     *     VectorBase<int,3> v1 {{ 1, 2, 3}};
     *     VectorBase<int,3> v2 (v1);
     * ~~~
     */
    constexpr VectorBase (VectorBase<T,N> const& rhs) : data_ (rhs.data_) {};

    /**
     * @brief Copy Constructor to initialize a vector as a copy of any vector expression
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     VectorBase<int,2> v1 {{ 1, 2 }};
     *     VectorBase<int,2> v2 {{ 3, 4 }};
     *
     *     VectorBase<int,2> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    VectorBase (VectorExpression<E,N> const& V) {
      for (size_type i=0; i<N; ++i)
        data_[i]=V[i];
    }



    /**
         * @brief Bracket operator to access the data elements
         * @param i Index of the data element (i=0,...,N-1)
         * @return Reference to the i-th element
         */
    inline T& operator[] (size_type i) {
      return data_[i];
    }


    /**
         * @brief Bracket operator to access the data elements
         * @param i Index of the data element (i=0,...,N-1)
         * @return Const reference to the i-th element
         */
    inline constexpr T const& operator[] (size_type i) const {
      return data_[i];
    }


    /**
         * @brief Function to access the data elements
         * @param i Index of the data element (i=0,...,N-1)
         * @return Reference to the i-th element
         */
    inline T& at (size_type i) {
      return data_[i];
    }


    /**
         * @brief Function to access the data elements
         * @param i Index of the data element (i=0,...,N-1)
         * @return Const reference to the i-th element
         */
    inline constexpr T const& at (size_type i) const {
      return data_[i];
    }


    /**
         * @brief Bracket operator to access the data elements
         * @param i Index of the data element (i=0,...,N-1)
         * @return reference to the i-th element
         */
    inline T& operator() (size_type i) {
      return at (i);
    }


    /**
         * @brief Bracket operator to access the data elements
         * @param i Index of the data element (i=0,...,N-1)
         * @return Const reference to the i-th element
         */
    inline constexpr T const& operator() (size_type i) const {
      return at (i);
    }


    /**
         * @brief Sets all data elements to zero
         */
    void zero () {
      for (size_type i=0; i<N; ++i)
        data_[ i ] = static_cast<T> (0);
    }


    /**
    * @brief Swaps this VectorBase object with another one
    * @param rhs VectorBase object
    */
    void swap (VectorBase<T,N>& rhs) {
      std::swap (data_,rhs.data_);
    }

    /**
     * @brief Sorts the data, using std::sort
     */
    void sort() {
      std::sort (data_.begin(), data_.end());
    }

    /**
     * @brief Compound assignment operator += (plus operator with assignment)
     * @tparam E Type of the vector expression
     * @param V VectorExpression on the right hand side of +=
     * @return const reference to this object
     */
    template<class E>
    VectorBase<T,N> const& operator += (VectorExpression<E,N> const& V) {
      *this = *this + V;
      return *this;
    }


    /**
     * @brief Compound assignment operator -= (minus operator with assignment)
     * @tparam E Type of the vector expression
     * @param V VectorExpression on the right hand side of -=
     * @return const reference to this object
     */
    template<class E>
    VectorBase<T,N> const& operator -= (VectorExpression<E,N> const& V) {
      *this = *this - V;
      return *this;
    }


    /**
     * @brief Compound assignment operator *= (multiplication operator with assignment)
     * @tparam E Type of the vector expression
     * @param V VectorExpression on the right hand side of *=
     * @return const reference to this object
     */
    VectorBase<T,N> const& operator *= (T const& a) {
      *this = *this * a;
      return *this;
    }


    /**
     * @brief Compound assignment operator /= (divide operator with assignment)
     * @tparam E Type of the vector expression
     * @param V VectorExpression on the right hand side of /=
     * @return const reference to this object
     */
    VectorBase<T,N> const& operator /= (T const& a) {
      *this = *this / a;
      return *this;
    }
};



/**
 * @brief General template definition for tensors
 * @tparam T data value type
 * @tparam D spatial dimension of the tensor
 * @tparam O rank of the tensor (supported: rank 1,2,3)
 * @tparam S symmetry of the tensor (no symmetries, symmetric, semi-symmetric)
 */
template<class T, size_type D, size_type O=1, TensorSymmetryType S=NO_SYM> class Tensor;


/**
 * @brief A tensor of rank 1 (a vector)
 * @tparam T data value type
 * @tparam D spatial dimension of the vector
 */
template<class T, size_type D>
class Tensor<T,D,1,NO_SYM> : public VectorBase<T,D> {

  protected:
    using VectorBase<T,D>::data_;

  public:
    using VectorBase<T,D>::value_type;

    /**
     * @brief Default constructor
     */
    Tensor() {};

    /**
     * @brief Constructor to initialize all tensor elements with the same number
     * @details TODO: constexpr possible here?
     * @param a Number with which all elements are to be initialized
     */
    Tensor (T a)
      : VectorBase<T,D> (a) {};


    /**
     * @brief Constructor to initialize a tensor from a brace-enclosed initializer list or from a std::array
     * @param rhs Brace-enclosed initializer list, e.g. {1,2,...}, or std::array
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3> v1 ({ 1, 2, 3});
     *     Tensor<int,3> v2 {{ 1, 2, 3}};
     * ~~~
     */
    constexpr Tensor (std::array<T,D> const& rhs)
      : VectorBase<T,D> (rhs) {};


    /**
     * @brief Copy Constructor to initialize a tensor as a copy of any (compatible) vector expression
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,2> v1 {{ 1, 2 }};
     *     Tensor<int,2> v2 {{ 3, 4 }};
     *
     *     Tensor<int,2> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E,D> const& v) {
      for (size_type i=0; i<D; ++i)
        data_[i]=v[i];
    }
};


/**
 * @brief A tensor of rank 2 (a matrix) without any symmetry property
 * @tparam T data value type
 * @tparam D spatial dimension of the tensor
 */
template<class T, size_type D>
class Tensor<T,D,2,NO_SYM> : public VectorBase<T,D* D> {

  protected:
    using VectorBase<T,D* D>::data_;

  public:
    using VectorBase<T,D* D>::value_type;

    /**
     * @brief Default constructor
     */
    Tensor() {}

    /**
     * @brief Constructor to initialize all tensor elements with the same number
     * @details TODO: constexpr possible here?
     * @param a Number with which all elements are to be initialized
     */
    Tensor (T a)
      : VectorBase<T,D* D> (a) {}

    /**
     * @brief Constructor to initialize a tensor from a brace-enclosed initializer list or from a std::array
     * @param rhs Brace-enclosed initializer list, e.g. {1,2,...}, or std::array
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3,2> v1 ({ 11, 12, 13,
     *                           21, 22, 23,
     *                           31, 32, 33 });
     *     Tensor<int,3,2> v2 {{ 11, 12, 13,
     *                           21, 22, 23,
     *                           31, 32, 33 }};
     * ~~~
     */
    constexpr Tensor (std::array<T,D* D> const& rhs)
      : VectorBase<T,D* D> (rhs) {}

    /**
     * @brief Copy Constructor to initialize a tensor as a copy of any rank-2-tensor expression (without symmetry)
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3,2> v1 {{ 1, 2, 3,
     *                           4, 5, 6,
     *                           7, 8, 9 }};
     *
     *     Tensor<int,3,2> v2 {{ 5, 13, 2,
     *                           8, 1, 10,
     *                           14, 3, 7 }};
     *
     *     Tensor<int,3,2> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E,D* D> const& v) {
      for (size_type i=0; i<D*D; ++i)
        data_[i]=v[i];
    }

    /**
     * @brief Copy Constructor to initialize a tensor as a copy of any symmetric rank-2-tensor expression
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3,2,SYM> v1 {{ 1, 4, 7
     *                               4, 5, 8
     *                               7, 8, 9 }};
     *
     *     Tensor<int,3,2,SYM> v2 {{ 5, 8, 14
     *                               8, 1, 3
     *                              14, 3, 7 }};
     *
     *     Tensor<int,3,2> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E,D* (D+1) /2> const& v) {
      Tensor<T,D,2,SYM> M (v);

      for (size_type i=0; i<D; ++i)
        for (size_type j=0; j<D; ++j)
          at (i,j) = M (i,j);
    }

    /**
     * @brief Copy Constructor to initialize a tensor as a copy of a vector of row vectors
     * @param rhs vector of row vectors
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3> row1 = {{ 1, 2, 3}};
     *     Tensor<int,3> row2 = {{ 4, 5, 6}};
     *     Tensor<int,3> row3 = {{ 7, 8, 9}};
     *     Tensor<Tensor<int,3>,3> v = {{ row1,
     *                                    row2,
     *                                    row3 }};
     *
     *     Tensor<int,3,2> v1 ( v );
     * ~~~
     */
    Tensor (Tensor<Tensor<T,D>,D> const& v) {
      for (size_type i=0; i<D; ++i)
        for (size_type j=0; j<D; ++j)
          at (i,j) = v (i) (j);
    }

    /**
     * @brief Function to access the data elements
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Reference to the element (i,j)
     */
    inline T& at (size_type i, size_type j) {
      return data_[i*D + j];
    }

    /**
     * @brief Function to access the data elements
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Const reference to the element (i,j)
     */
    inline constexpr T const& at (size_type i, size_type j) const {
      return data_[i*D + j];
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Reference to the element (i,j)
     */
    inline T& operator() (size_type i, size_type j) {
      return at (i,j);
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Const reference to the element (i,j)
     */
    inline constexpr T const& operator() (size_type i, size_type j) const {
      return at (i,j);
    }

    /**
     * @brief Returns row i of the matrix
     * @param j row index
     * @return row vector
     */
    inline Tensor<T,D> row (size_type i) const {
      Tensor<T,D> row;
      for (size_type j=0; j<D; j++)
        row (j) = operator() (i,j);
      return row;
    }

    /**
     * @brief Returns column j of the matrix
     * @param j column index
     * @return column vector
     */
    inline Tensor<T,D> col (size_type j) const {
      Tensor<T,D> column;
      for (size_type i=0; i<D; i++)
        column (i) = operator() (i,j);
      return column;
    }

    /**
     * @brief Returns the spatial dimension of the tensor
     * @return Spatial dimension D
     */
    size_type get_D() const {
      return D;
    }
};


/**
 * @brief A symmetric tensor of rank 2 (a symmetric matrix)
 * @details The symmetry property reduces the number of stored components from (D*D) to (D*(D+1)/2)
 * @tparam T data value type
 * @tparam D spatial dimension of the tensor
 */
template<class T, size_type D>
class Tensor<T,D,2,SYM> : public VectorBase<T,D* (D+1) /2> {

  protected:
    using VectorBase<T,D* (D+1) /2>::data_;

  public:
    using VectorBase<T,D* (D+1) /2>::value_type;

    /**
     * @brief Default constructor
     */
    Tensor() {}

    /**
     * @brief Constructor to initialize all tensor elements with the same number
     * @details TODO: constexpr possible here?
     * @param a Number with which all elements are to be initialized
     */
    Tensor (T a)
      : VectorBase<T,D* (D+1) /2> (a) {}

    /**
     * @brief Constructor to initialize a tensor from a brace-enclosed initializer list or from a std::array
     * @param rhs Brace-enclosed initializer list, e.g. {1,2,...}, or std::array
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3,2,SYM> v1 {{ 1, 0, 0,
     *                               0, 1, 0,
     *                               0, 0, 1 }};
     *
     *     Tensor<int,3,2,SYM> v2 {{ 5, 8, 14,
     *                               8, 1, 3,
     *                              14, 3, 7 }};
     * ~~~
     */
    Tensor (std::array<T,D* D> const& v) {
      ASSERT2 (is_symmetric (v));
      size_type ind = 0;

      for (const T* it=begin (v); it!=end (v); ++it) {
        size_type i = ind/D;
        size_type j = ind%D;

        if (j<=i) at (i,j) = *it;

        ind++;
      }
    }

    /**
     * @brief Copy Constructor to initialize a tensor as a copy of any rank-2-tensor expression (without symmetry)
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3,2> v1 {{ 1, 0, 0,
     *                           0, 1, 0,
     *                           0, 0, 1 }};
     *
     *     Tensor<int,3,2> v2 {{ 5, 8, 14,
     *                           8, 1, 3,
     *                          14, 3, 7 }};
     *
     *     Tensor<int,3,2,SYM> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E,D* D> const& v) {
      ASSERT2 (is_symmetric (v));

      for (size_type i=0; i<D; ++i)
        for (size_type j=0; j<=i; ++j)
          at (i,j) = v[i*D + j];
    }

    /**
     * @brief Copy Constructor to initialize a tensor as a copy of a symmetric rank-2-tensor expression
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,3,2,SYM> v1 {{ 1, 0, 0,
     *                               0, 1, 0,
     *                               0, 0, 1 }};
     *
     *     Tensor<int,3,2,SYM> v2 {{ 5, 8, 14,
     *                               8, 1, 3,
     *                              14, 3, 7 }};
     *
     *     Tensor<int,3,2,SYM> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E,D* (D+1) /2> const& v) {
      for (size_type i=0; i<D* (D+1) /2; ++i)
        data_[i]=v[i];
    }

    /**
     * @brief Direct access to the data elements, requires i>=j
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Reference to the element (i,j)
     */
    inline T& at (size_type i, size_type j) {
      return data_[i* (i+1) /2 + j];
    }

    /**
     * @brief Direct access to the data elements, requires i>=j
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Const reference to the element (i,j)
     */
    inline constexpr T const& at (size_type i, size_type j) const {
      return data_[i* (i+1) /2 + j];
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Reference to the element (i,j)
     */
    inline T& operator() (size_type i, size_type j) {
      return (i>=j) ? at (i,j) : at (j,i);
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-2-tensor
     * @param j second index of the rank-2-tensor
     * @return Const reference to the element (i,j)
     */
    inline constexpr T const& operator() (size_type i, size_type j) const {
      return (i>=j) ? at (i,j) : at (j,i);
    }

    /**
     * @brief Returns row i of the matrix
     * @param j row index
     * @return row vector
     */
    inline Tensor<T,D> row (size_type i) const {
      Tensor<T,D> row;
      for (size_type j=0; j<D; j++)
        row (j) = operator() (i,j);
      return row;
    }

    /**
     * @brief Returns column j of the matrix
     * @param j column index
     * @return column vector
     */
    inline Tensor<T,D> col (size_type j) const {
      Tensor<T,D> column;
      for (size_type i=0; i<D; i++)
        column (i) = operator() (i,j);
      return column;
    }

    /**
     * @brief Returns the spatial dimension of the tensor
     * @return Spatial dimension D
     */
    size_type get_D() const {
      return D;
    }

    /**
     * @brief Auxiliary function for constructor. Checks, if an array fufils the symmetry property.
     * @param v Array with data entries
     * @return true, if input array fulfils the symmetry property; false, if it does not
     */
    bool is_symmetric (std::array<T,D* D> const& v) {
      Tensor<T,D,2> temp;
      size_type ind = 0;

      for (const T* it=begin (v); it!=end (v); ++it) {
        size_type i = ind/D;
        size_type j = ind%D;
        temp (i,j) = *it;
        ind++;
      }

      for (size_type i=0; i<D; ++i)
        for (size_type j=0; j<i; ++j)
          if (temp (i,j) != temp (j,i))
            return false;

      return true;
    }


    /**
     * @brief Auxiliary function for constructor. Checks, if a vector expression fufils the symmetry property.
     * @tparam E vector expression type
     * @param v vector expression
     * @return true, if input array fulfils the symmetry property; false, if it does not
     */
    template<class E>
    bool is_symmetric (VectorExpression<E,D* D> const& v) {

      for (size_type i=0; i<D; ++i)
        for (size_type j=0; j<i; ++j)
          if (v[i*D+j] != v[j*D+i])
            return false;

      return true;
    }
};


/**
 * @brief A tensor of rank 3 without any symmetry property
 * @tparam T data value type
 * @tparam D spatial dimension of the tensor
 */
template<class T, size_type D>
class Tensor<T,D,3,NO_SYM> : public VectorBase<T,D* D* D> {

  protected:
    using VectorBase<T,D* D* D>::data_;

  public:
    using VectorBase<T,D* D* D>::value_type;

    /**
     * @brief Default constructor
     */
    Tensor() {}

    /**
     * @brief Constructor to initialize all tensor elements with the same number
     * @details TODO: constexpr possible here?
     * @param a Number with which all elements are to be initialized
     */
    Tensor (T a)
      : VectorBase<T,D* D* D> (a) {}


    /**
     * @brief Constructor to initialize a tensor from a brace-enclosed initializer list or from a std::array
     * @param rhs Brace-enclosed initializer list, e.g. {1,2,...}, or std::array
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,2,3> v1 ({ 111, 112,
     *                           121, 122,
     *
     *                           211, 212,
     *                           221, 222 });
     *
     *
     *     Tensor<int,2,3> v2 {{ 111, 112,
     *                           121, 122,
     *
     *                           211, 212,
     *                           221, 222 }};
     * ~~~
     */
    constexpr Tensor (std::array<T,D* D* D> const& rhs)
      : VectorBase<T,D* D* D> (rhs) {}

    /**
     * @brief Copy Constructor to initialize a tensor as a copy of any rank-3-tensor expression (without symmetry)
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,2,3> v1 ({ 111, 112,
     *                           121, 122,
     *
     *                           211, 212,
     *                           221, 222 });
     *
     *
     *     Tensor<int,2,3> v2 {{ 111, 112,
     *                           121, 122,
     *
     *                           211, 212,
     *                           221, 222 }};
     *
     *     Tensor<int,2,3> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E,D* D* D> const& v) {
      for (size_type i=0; i<D*D*D; ++i)
        data_[i]=v[i];
    }

    /**
     * @brief Function to access the data elements
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Reference to the element (i,j,k)
     */
    inline T& at (size_type i, size_type j, size_type k) {
      return data_[i*D*D + j*D + k];
    }

    /**
     * @brief Function to access the data elements
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Const reference to the element (i,j,k)
     */
    inline constexpr T const& at (size_type i, size_type j, size_type k) const {
      return data_[i*D*D + j*D + k];
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Const reference to the element (i,j,k)
     */
    inline T& operator() (size_type i, size_type j, size_type k) {
      return at (i,j,k);
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Const reference to the element (i,j,k)
     */
    inline constexpr T const& operator() (size_type i, size_type j, size_type k) const {
      return at (i,j,k);
    }

    /**
     * @brief Returns the spatial dimension of the tensor
     * @return Spatial dimension D
     */
    size_type get_D() const {
      return D;
    }
};



/**
 * @brief A fully-symmetric tensor of rank 3
 * @details The symmetry property reduces the number of stored components from (D*D*D) to (D*(D+1)*(D+2)/6)
 * @tparam T data value type
 * @tparam D spatial dimension of the tensor
 */
template<class T, size_type D>
class Tensor<T,D,3,SYM> : public VectorBase<T, (D+2)* (D+1)* D/6> {

  protected:
    using VectorBase<T, (D+2)* (D+1)* D/6>::data_;

  public:
    using VectorBase<T, (D+2)* (D+1)* D/6>::value_type;

    /**
     * @brief Default constructor
     */
    Tensor() {}

    /**
     * @brief Constructor to initialize all tensor elements with the same number
     * @details TODO: constexpr possible here?
     * @param a Number with which all elements are to be initialized
     */
    Tensor (T a)
      : VectorBase<T, (D+2)* (D+1)* D/6> (a) {}


    /**
     * @brief Constructor to initialize a tensor from a brace-enclosed initializer list or from a std::array
     * @param rhs Brace-enclosed initializer list, e.g. {1,2,...}, or std::array
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,2,3,SYM> v1 ({ 111, 112,
     *                               112, 122,
     *
     *                               112, 122,
     *                               122, 222 });
     *
     *
     *     Tensor<int,2,3,SYM> v1 {{ 111, 112,
     *                               112, 122,
     *
     *                               112, 122,
     *                               122, 222 }};
     * ~~~
     */
    Tensor (std::array<T,D* D* D> const& v) {

      ASSERT2 (is_symmetric (v));

      size_type ind = 0;

      for (const T* it=begin (v); it!=end (v); ++it) {
        size_type i = (ind/D) /D;
        size_type j = (ind/D) %D;
        size_type k = ind%D;

        if (i<=j && j<=k) at (i,j,k) = *it;

        ind++;
      }
    };


    /**
     * @brief Copy Constructor to initialize a tensor as a copy of any rank-3-tensor expression (without symmetry)
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,2,3,SYM> v1 ({ 111, 112,
     *                               112, 122,
     *
     *                               112, 122,
     *                               122, 222 });
     *
     *
     *     Tensor<int,2,3,SYM> v1 {{ 111, 112,
     *                               112, 122,
     *
     *                               112, 122,
     *                               122, 222 }};
     *
     *     Tensor<int,2,3,SYM> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E, (D+2) * (D+1) *D/6> const& v) {
      for (size_type i=0; i< (D+2) * (D+1) *D/6; ++i)
        data_[i]=v[i];
    }

    /**
     * @brief Direct access to the data elements, requires i>=j>=k
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Reference to the element (i,j,k)
     */
    inline T& at (size_type i, size_type j, size_type k) {
      return data_[ (i+2) * (i+1) *i/6 + (j+1) *j/2 + k];
    }

    /**
     * @brief Direct access to the data elements, requires i>=j>=k
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Const reference to the element (i,j,k)
     */
    inline constexpr T const& at (size_type i, size_type j, size_type k) const {
      return data_[ (i+2) * (i+1) *i/6 + (j+1) *j/2 + k];
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Reference to the element (i,j,k)
     */
    inline T& operator() (size_type i, size_type j, size_type k) {
      return (i>=j && j>=k) ? at (i,j,k)
             : ( (i>=k && k>=j) ? at (i,k,j)
                 : ( (j>=i && i>=k) ? at (j,i,k)
                     : ( (j>=k && k>=i) ? at (j,k,i)
                         : ( (k>=i && i>=j) ? at (k,i,j)
                             : at (k,j,i)))));
    }

    /**
     * @brief Bracket operator to access the data elements
     * @param i first index of the rank-3-tensor
     * @param j second index of the rank-3-tensor
     * @param k third index of the rank-3-tensor
     * @return Const reference to the element (i,j,k)
     */
    inline constexpr T const& operator() (size_type i, size_type j, size_type k) const {
      return (i>=j && j>=k) ? at (i,j,k)
             : ( (i>=k && k>=j) ? at (i,k,j)
                 : ( (j>=i && i>=k) ? at (j,i,k)
                     : ( (j>=k && k>=i) ? at (j,k,i)
                         : ( (k>=i && i>=j) ? at (k,i,j)
                             : at (k,j,i)))));
    }

    /**
     * @brief Returns the spatial dimension of the tensor
     * @return Spatial dimension D
     */
    size_type get_D() const {
      return D;
    }

    /**
     * @brief Auxiliary function for constructor. Checks, if an array fufils the symmetry property.
     * @param v Array with data entries
     * @return true, if input array fulfils the symmetry property; false, if it does not
     */
    bool is_symmetric (std::array<T,D* D* D> const& v) {
      Tensor<T,D,3> temp;
      size_type ind = 0;

      for (const T* it=begin (v); it!=end (v); ++it) {
        size_type i = (ind/D) /D;
        size_type j = (ind/D) %D;
        size_type k = ind%D;
        temp (i,j,k) = *it;
        ind++;
      }

      for (size_type i=0; i<D; ++i)
        for (size_type j=0; j<=i; ++j)
          for (size_type k=0; k<=j; ++k)
            if (temp (i,j,k) != temp (i,k,j)
                || temp (i,j,k) != temp (j,i,k)
                || temp (i,j,k) != temp (j,k,i)
                || temp (i,j,k) != temp (k,i,j)
                || temp (i,j,k) != temp (k,j,i)) return false;

      return true;
    }
};



/**
 * @brief A semi-symmetric tensor of rank 3 (symmetric only in the last 2 indices)
 * @details The symmetry property reduces the number of stored components from (D*D*D) to (D*D*(D+1)/2)
 * @tparam T data value type
 * @tparam D spatial dimension of the tensor
 */
template<class T, size_type D>
class Tensor<T,D,3,SEMI_SYM> : public VectorBase<T, D* D* (D+1) /2> {

  protected:
    using VectorBase<T, D* D* (D+1) /2>::data_;

  public:
    using VectorBase<T, D* D* (D+1) /2>::value_type;

    /**
     * @brief Default constructor
     */
    Tensor() {}

    /**
     * @brief Constructor to initialize all tensor elements with the same number
     * @details TODO: constexpr possible here?
     * @param a Number with which all elements are to be initialized
     */
    Tensor (T a)
      : VectorBase<T, D* D* (D+1) /2> (a) {}

    /**
     * @brief Constructor to initialize a tensor from a brace-enclosed initializer list or from a std::array
     * @param rhs Brace-enclosed initializer list, e.g. {1,2,...}, or std::array
     *
     * Example:
     * ~~~{.cpp}
     *
     *     Tensor<int,2,3> v1 ({ 111, 112,
     *                           112, 122,
     *
     *                           112, 122,
     *                           122, 222 });
     *
     *
     *     Tensor<int,2,3> v1 {{ 111, 112,
     *                           112, 122,
     *
     *                           112, 122,
     *                           122, 222 }};
     *
     *     Tensor<int,2,3,SEMI_SYM> v3 ( 3*v1+(-v2/2) );
     * ~~~
     */
    Tensor (std::array<T,D* D* D> const& v) {

      ASSERT2 (is_semi_symmetric (v));

      size_type ind = 0;

      for (const T* it=begin (v); it!=end (v); ++it) {
        size_type i = (ind/D) /D;
        size_type j = (ind/D) %D;
        size_type k = ind%D;

        if (j<=k) at (i,j,k) = *it;

        ind++;
      }
    }

    /**
     * @brief Copy Constructor to initialize a tensor as a copy of any rank-3-tensor expression (without symmetry)
     * @param rhs vector expression to be copied
     * @tparam E Type of the vector expression
     *
     * Example:
     * ~~~{.cpp}
     *     Tensor<int,2,3> v1 ({ 111, 112,
     *                           121, 122,
     *
     *                           211, 212,
     *                           221, 222 });
     *
     *
     *     Tensor<int,2,3,SEMI_SYM> v2 (v1);
     * ~~~
     */
    template<class E>
    Tensor (VectorExpression<E,D* D* (D+1) /2> const& v) {
      for (size_type i=0; i< D* D* (D+1) /2; ++i)
        data_[i]=v[i];
    }

    inline T& at (size_type i, size_type j, size_type k) {
      return data_[ i* (D* (D+1) /2) + (j+1) *j/2 + k];
    }

    inline constexpr T const& at (size_type i, size_type j, size_type k) const {
      return data_[ i* (D* (D+1) /2) + (j+1) *j/2 + k];
    }

    inline T& operator() (size_type i, size_type j, size_type k) {
      return (j>=k) ? at (i,j,k) : at (i,k,j);
    }

    inline constexpr T const& operator() (size_type i, size_type j, size_type k) const {
      return (j>=k) ? at (i,j,k) : at (i,k,j);
    }

    size_type get_D() const {
      return D;
    }

    bool is_semi_symmetric (std::array<T,D* D* D> const& v) {
      Tensor<T,D,3> temp;
      size_type ind = 0;

      for (const T* it=begin (v); it!=end (v); ++it) {
        size_type i = (ind/D) /D;
        size_type j = (ind/D) %D;
        size_type k = ind%D;
        temp (i,j,k) = *it;
        ind++;
      }

      for (size_type i=0; i<D; ++i)
        for (size_type j=0; j<D; ++j)
          for (size_type k=0; k<j; ++k)
            if (temp (i,j,k) != temp (i,k,j)) return false;

      return true;
    }
};



//========================================================================

// default lattice tensor: a lattice vector
template<class T, size_type D, size_type Q, size_type O=1, TensorSymmetryType S=NO_SYM> class LatticeTensor;

// a lattice vector:
template<class T, size_type D, size_type Q>
class LatticeTensor<T,D,Q,1,NO_SYM> : public VectorBase<T,D* Q> {

  protected:
    using VectorBase<T,D* Q>::data_;

  public:
    using VectorBase<T,D* Q>::value_type;

    LatticeTensor() {}

    /// constexpr?
    LatticeTensor (T a)
      : VectorBase<T,D* Q> (a) {}

    // Constructor for initializer lists or std::array: // VectorBase<T,N> ({t1,t2,...});
    constexpr LatticeTensor (std::array<T,D* Q> const& rhs)
      : VectorBase<T,D* Q> (rhs) {}

    // Construct from any VectorExpression of non-symmetric type (size = D*D)
    template<class E>
    LatticeTensor (VectorExpression<E,D* Q> const& v) {
      for (size_type i=0; i<D*Q; ++i)
        data_[i]=v[i];
    }

    inline T& at (size_type i, size_type l) {
      return data_[i*Q + l];
    }

    inline constexpr T const& at (size_type i, size_type l) const {
      return data_[i*Q + l];
    }

    inline T& operator() (size_type i, size_type l) {
      return at (i,l);
    }

    inline constexpr T const& operator() (size_type i, size_type l) const {
      return at (i,l);
    }

    inline Tensor<T,D> const operator() (size_type l) const {
      Tensor<T,D> v;

      for (size_type i=0; i<D; ++i)
        v (i) = at (i,l);

      return v;
    }

    size_type get_D() const {
      return D;
    }
    size_type get_Q() const {
      return Q;
    }
};



// 2nd-order lattice tensor:
template<class T, size_type D, size_type Q>
class LatticeTensor<T,D,Q,2,NO_SYM> : public VectorBase<T,D* D* Q> {
  protected:
    using VectorBase<T,D* D* Q>::data_;

  public:
    using VectorBase<T,D* D* Q>::value_type;

    LatticeTensor() {}

    /// constexpr?
    LatticeTensor (T a)
      : VectorBase<T,D* D* Q> (a) {}

    // Constructor for initializer lists or std::array: // VectorBase<T,N> ({t1,t2,...});
    constexpr LatticeTensor (std::array<T,D* D* Q> const& rhs)
      : VectorBase<T,D* D* Q> (rhs) {}

    // Construct from any VectorExpression of non-symmetric type (size = D*D)
    template<class E>
    LatticeTensor (VectorExpression<E,D* D* Q> const& v) {
      for (size_type i=0; i<D*D*Q; ++i)
        data_[i]=v[i];
    }

    inline T& at (size_type i, size_type j, size_type l) {
      return data_[ (i*D + j) *Q+l];
    }

    inline constexpr T const& at (size_type i, size_type j, size_type l) const {
      return data_[ (i*D + j) *Q+l];
    }

    inline T& operator() (size_type i, size_type j, size_type l) {
      return at (i,j,l);
    }

    inline constexpr T const& operator() (size_type i, size_type j, size_type l) const {
      return at (i,j,l);
    }

    size_type get_D() const {
      return D;
    }
    size_type get_Q() const {
      return Q;
    }
};




// 2nd-order symmetric lattice tensor:
template<class T, size_type D, size_type Q>
class LatticeTensor<T,D,Q,2,SYM> : public VectorBase<T,D* (D+1) /2*Q> {

  protected:
    using VectorBase<T,D* (D+1) /2*Q>::data_;

  public:
    using VectorBase<T,D* (D+1) /2*Q>::value_type;

    LatticeTensor() {}

    /// constexpr?
    LatticeTensor (T a)
      : VectorBase<T,D* (D+1) /2*Q> (a) {}

    // Constructor for initializer lists or std::array: // VectorBase<T,N> ({t1,t2,...});
    constexpr LatticeTensor (std::array<T,D* (D+1) /2*Q> const& rhs)
      : VectorBase<T,D* (D+1) /2*Q> (rhs) {}

    // Construct from any VectorExpression of symmetric type (size = D*(D+1)/2)
    template<class E>
    LatticeTensor (VectorExpression<E,D* (D+1) /2*Q> const& v) {
      for (size_type i=0; i<D* (D+1) /2*Q; ++i)
        data_[i]=v[i];
    }

    inline T& at (size_type i, size_type j,  size_type l) {
      return data_[ (i* (i+1) /2 + j) *Q+l];
    }

    inline constexpr T const& at (size_type i, size_type j,  size_type l) const {
      return data_[ (i* (i+1) /2 + j) *Q+l];
    }

    inline T& operator() (size_type i, size_type j,  size_type l) {
      return (i>=j) ? at (i,j, l) : at (j,i, l);
    }

    inline constexpr T const& operator() (size_type i, size_type j,  size_type l) const {
      return (i>=j) ? at (i,j, l) : at (j,i, l);
    }

    size_type get_D() const {
      return D;
    }
    size_type get_Q() const {
      return Q;
    }
};




// 3nd-order lattice tensor:
template<class T, size_type D, size_type Q>
class LatticeTensor<T,D,Q,3,NO_SYM> : public VectorBase<T, D* D* D* Q> {

  protected:
    using VectorBase<T,D* D* D* Q>::data_;

  public:
    using VectorBase<T,D* D* D* Q>::value_type;

    LatticeTensor() {}

    /// constexpr?
    LatticeTensor (T a)
      : VectorBase<T,D* D* D* Q> (a) {}

    // Constructor for initializer lists or std::array: // VectorBase<T,N> ({t1,t2,...});
    constexpr LatticeTensor (std::array<T,D* D* D* Q> const& rhs)
      : VectorBase<T,D* D* D* Q> (rhs) {}

    // Construct from any VectorExpression:
    template<class E>
    LatticeTensor (VectorExpression<E,D* D* D* Q> const& v) {
      for (size_type i=0; i<D*D*D*Q; ++i)
        data_[i]=v[i];
    }

    inline T& at (size_type i, size_type j, size_type k, size_type l) {
      return data_[ (i*D*D + j*D + k) *Q + l];
    }

    inline constexpr T const& at (size_type i, size_type j, size_type k, size_type l) const {
      return data_[ (i*D*D + j*D + k) *Q + l];
    }

    inline T& operator() (size_type i, size_type j, size_type k, size_type l) {
      return at (i,j,k,l);
    }

    inline constexpr T const& operator() (size_type i, size_type j, size_type k, size_type l) const {
      return at (i,j,k,l);
    }

    size_type get_D() const {
      return D;
    }
    size_type get_Q() const {
      return Q;
    }
};





// 3nd-order fully symmetric lattice tensor:
template<class T, size_type D, size_type Q>
class LatticeTensor<T,D,Q,3,SYM> : public VectorBase<T, (D+2)* (D+1)* D/6*Q> {

  protected:
    using VectorBase<T, (D+2)* (D+1)* D/6*Q>::data_;

  public:
    using VectorBase<T, (D+2)* (D+1)* D/6*Q>::value_type;

    LatticeTensor() {}

    /// constexpr?
    LatticeTensor (T a)
      : VectorBase<T, (D+2)* (D+1)* D/6*Q> (a) {}

    // Constructor for initializer lists or std::array: // VectorBase<T,N> ({t1,t2,...});
    constexpr LatticeTensor (std::array<T, (D+2) * (D+1) *D/6*Q> const& rhs)
      : VectorBase<T, (D+2)* (D+1)* D/6*Q> (rhs) {}

    // Construct from any VectorExpression:
    template<class E>
    LatticeTensor (VectorExpression<E, (D+2) * (D+1) *D/6> const& v) {
      for (size_type i=0; i< (D+2) * (D+1) *D/6; ++i)
        data_[i]=v[i];
    }

    inline T& at (size_type i, size_type j, size_type k,  size_type l) {
      return data_[ ( (i+2) * (i+1) *i/6 + (j+1) *j/2 + k) *Q+l];
    }

    inline constexpr T const& at (size_type i, size_type j, size_type k,  size_type l) const {
      return data_[ ( (i+2) * (i+1) *i/6 + (j+1) *j/2 + k) *Q+l];
    }

    inline T& operator() (size_type i, size_type j, size_type k,  size_type l) {
      return (i>=j && j>=k) ? at (i,j,k,l)
             : ( (i>=k && k>=j) ? at (i,k,j,l)
                 : ( (j>=i && i>=k) ? at (j,i,k,l)
                     : ( (j>=k && k>=i) ? at (j,k,i,l)
                         : ( (k>=i && i>=j) ? at (k,i,j,l)
                             : at (k,j,i,l)))));
    }

    inline constexpr T const& operator() (size_type i, size_type j, size_type k,  size_type l) const {
      return (i>=j && j>=k) ? at (i,j,k,l)
             : ( (i>=k && k>=j) ? at (i,k,j,l)
                 : ( (j>=i && i>=k) ? at (j,i,k,l)
                     : ( (j>=k && k>=i) ? at (j,k,i,l)
                         : ( (k>=i && i>=j) ? at (k,i,j,l)
                             : at (k,j,i,l)))));
    }

    size_type get_D() const {
      return D;
    }
    size_type get_Q() const {
      return Q;
    }
};









// ============= base traits specializations ==================

template<>
template<class T, size_type N>
struct base_traits< VectorBase<T,N> > {
  typedef T value_type;
};

template<>
template<class E1, class E2, size_type N>
struct base_traits< VectorAddition<E1,E2,N> > {
  typedef typename E1::value_type value_type;
};

template<>
template<class E1, class E2, size_type N>
struct base_traits< VectorDifference<E1,E2,N> > {
  typedef typename E1::value_type value_type;
};

template<>
template<class T, class E, size_type N>
struct base_traits< VectorScalarMultiplication<T,E,N> > {
  typedef typename E::value_type value_type;
};

template<>
template<class T, class E, size_type N>
struct base_traits< VectorScalarDivision<T,E,N>> {
  typedef typename E::value_type value_type;
};

template<>
template<class E, size_type N>
struct base_traits< VectorMirroring<E,N>> {
  typedef typename E::value_type value_type;
};




// ============= overloaded operators =========================

// Binary operators:
template <class E1, class E2, size_type N>
inline constexpr VectorAddition<E1,E2,N> const operator+ (VectorExpression<E1,N> const& L, VectorExpression<E2,N> const& R) {
  return VectorAddition<E1,E2,N> (L,R);
}

template <class E1, class E2, size_type N>
inline constexpr VectorDifference<E1,E2,N> const operator- (VectorExpression<E1,N> const& L, VectorExpression<E2,N> const& R) {
  return VectorDifference<E1,E2,N> (L,R);
}

template <class T, class E, size_type N>
inline constexpr VectorScalarMultiplication<T,E,N> const operator* (T const& a, VectorExpression<E,N> const& V) {
  return VectorScalarMultiplication<T,E,N> (a,V);
}

template <class T, class E, size_type N>
inline constexpr VectorScalarMultiplication<T,E,N> const operator* (VectorExpression<E,N> const& V, T const& a) {
  return a*V;
}

template <class T, class E, size_type N>
inline constexpr VectorScalarDivision<T,E,N> const operator/ (VectorExpression<E,N> const& V, T const& a) {
  return VectorScalarDivision<T,E,N> (a,V);
}


// Unary operators:
template<class E, size_type N>
inline constexpr VectorMirroring<E,N> const operator- (VectorExpression<E,N> const& V) {
  return VectorMirroring<E,N> (V);
}

template<class E, size_type N>
inline constexpr VectorExpression<E,N> const& operator+ (VectorExpression<E,N> const& V) {
  return V;
}


// Boolean operators:
template<class E1, class E2, size_type N>
inline bool operator!= (VectorExpression<E1,N> const& L, VectorExpression<E2,N> const& R) {
  for (size_type i=0; i<L.size(); i++)
    if (L [ i ] != R [ i ]) return true;

  return false;
}

template<class E1, class E2, size_type N>
inline bool operator== (VectorExpression<E1,N> const& L, VectorExpression<E2,N> const& R) {
  return ! (L!=R);
}



// Misc vector operations:
template < class E1, class E2, size_type N, class T=typename E1::value_type >
inline constexpr T dot (VectorExpression<E1,N>  const& L, VectorExpression<E2,N> const& R, const int i=0) {
  return (i<N) ? L[i]*R[i] + dot (L,R,i+1) : T (0);
}

template < class T, size_type N >
inline constexpr std::complex<T> dot (Tensor<std::complex<T>, N> const& L, Tensor<std::complex<T>, N> const& R, const int i=0) {
  return (i<N) ? conj(L[i])*R[i] + dot (L,R,i+1) : T (0);
}

template < class E, size_type N, class T=typename E::value_type >
inline constexpr T sum (VectorExpression<E,N> const& v, const int i=0) {
  return (i<N) ? v[i] + sum (v,i+1) : T (0);
}

template < class E, size_type N, class T=typename E::value_type >
inline constexpr double norm (VectorExpression<E,N> const& v) {
  return sqrt (norm2 (v));
}

template < class E, size_type N, class T=typename E::value_type >
inline constexpr T norm2 (VectorExpression<E,N> const& v) {
  return dot (v,v);
}

template<class T,  size_type N>
inline T norm2 (Tensor<std::complex<T>, N> const& psi) {  
  return real(dot(psi,psi));
}

template <class T>
inline Tensor<T,3> cross_prod (const Tensor<T,3>& L, const Tensor<T,3>& R) {
  return Tensor<T,3> ( {L (1) *R (2) - L (2) *R (1),
                        L (2) *R (0) - L (0) *R (2),
                        L (0) *R (1) - L (1) *R (0)
                       });
}




// Misc matrix operations:
template <class T, size_type D, TensorSymmetryType S1, TensorSymmetryType S2>
inline Tensor<T,D,2,NO_SYM> const operator* (Tensor<T,D,2,S1> M1, Tensor<T,D,2,S2> M2) {
  Tensor<T,D,2,NO_SYM> result;

  for (size_type i=0; i<D; ++i) {
    for (size_type j=0; j<D; ++j) {
      result (i,j) = 0;

      for (size_type k=0; k<D; ++k)
        result (i,j) += M1 (i,k) * M2 (k,j);
    }
  }

  return result;
}

template <class T, size_type D, TensorSymmetryType S>
inline Tensor<T,D> const operator* (Tensor<T,D> const& v, Tensor<T,D,2,S> const& M) {
  Tensor<T,D> result;

  for (size_type i=0; i<D; ++i) {
    result (i) = 0;

    for (size_type j=0; j<D; ++j)
      result (i) += v (j) * M (j,i);
  }

  return result;
}

template <class T, size_type D, TensorSymmetryType S>
inline Tensor<T,D> const operator* (Tensor<T,D,2,S> const& M,  Tensor<T,D> const& v) {
  Tensor<T,D> result;

  for (size_type i=0; i<D; ++i) {
    result (i) = 0;

    for (size_type j=0; j<D; ++j)
      result (i) += M (i,j) * v (j) ;
  }

  return result;
}

template<class T>
inline T det (Tensor<T,2,2,NO_SYM> const& M) {
  T det_ = M.at (0,0) *M.at (1,1)-M.at (1,0) *M.at (0,1);
  return det_;
}

template<class T>
inline T det (Tensor<T,2,2,SYM> const& M) {
  T det_ = M.at (0,0) *M.at (1,1)-M.at (1,0) *M.at (1,0);
  return det_;
}

template<class T>
inline T det (Tensor<T,3,2,NO_SYM> const& M) {
  T det_ = M.at (0,0) * (M.at (2,2) *M.at (1,1)-M.at (2,1) *M.at (1,2))
           -M.at (1,0) * (M.at (2,2) *M.at (0,1)-M.at (2,1) *M.at (0,2))
           +M.at (2,0) * (M.at (1,2) *M.at (0,1)-M.at (1,1) *M.at (0,2));
  return det_;
}

template<class T>
inline T det (Tensor<T,3,2,SYM> const& M) {
  T det_ = M.at (0,0) * (M.at (2,2) *M.at (1,1)-M.at (2,1) *M.at (2,1))
           -M.at (1,0) * (M.at (2,2) *M.at (1,0)-M.at (2,1) *M.at (2,0))
           +M.at (2,0) * (M.at (2,1) *M.at (1,0)-M.at (1,1) *M.at (2,0));
  return det_;
}

template<class T, TensorSymmetryType S>
inline T det (Tensor<T,4,2,S> const& M) {
  T det_ = M (0,3) *M (1,2) *M (2,1) *M (3,0) - M (0,2) *M (1,3) *M (2,1) *M (3,0) - M (0,3) *M (1,1) *M (2,2) *M (3,0) + M (0,1) *M (1,3) *M (2,2) *M (3,0) +
           M (0,2) *M (1,1) *M (2,3) *M (3,0) - M (0,1) *M (1,2) *M (2,3) *M (3,0) - M (0,3) *M (1,2) *M (2,0) *M (3,1) + M (0,2) *M (1,3) *M (2,0) *M (3,1) +
           M (0,3) *M (1,0) *M (2,2) *M (3,1) - M (0,0) *M (1,3) *M (2,2) *M (3,1) - M (0,2) *M (1,0) *M (2,3) *M (3,1) + M (0,0) *M (1,2) *M (2,3) *M (3,1) +
           M (0,3) *M (1,1) *M (2,0) *M (3,2) - M (0,1) *M (1,3) *M (2,0) *M (3,2) - M (0,3) *M (1,0) *M (2,1) *M (3,2) + M (0,0) *M (1,3) *M (2,1) *M (3,2) +
           M (0,1) *M (1,0) *M (2,3) *M (3,2) - M (0,0) *M (1,1) *M (2,3) *M (3,2) - M (0,2) *M (1,1) *M (2,0) *M (3,3) + M (0,1) *M (1,2) *M (2,0) *M (3,3) +
           M (0,2) *M (1,0) *M (2,1) *M (3,3) - M (0,0) *M (1,2) *M (2,1) *M (3,3) - M (0,1) *M (1,0) *M (2,2) *M (3,3) + M (0,0) *M (1,1) *M (2,2) *M (3,3);
  return det_;
}

template <class T, size_type D, TensorSymmetryType S>
inline Tensor<T,D,2,S> transpose (Tensor<T,D,2,S> const& M) {
  Tensor<T,D,2,S> result;

  for (size_type i=0; i<D; ++i)
    for (size_type j=0; j<D; ++j)
      result (i, j) = M (j, i);

  return result;
}


template<class T>
inline void diagonalize (Tensor<T,2,2,SYM> const& M, Tensor<T, 2, 2>& Q, Tensor<T,2>& w) {
  T a = M.at (0, 0);
  T b = M.at (1, 1);
  T c = M.at (1, 0);
  T Delta = std::sqrt ( (a-b) * (a-b) + 4*c*c);

  w = 0.5*Tensor<T,2> {{ (a+b+Delta), (a+b-Delta) }};

  Tensor<T, 2> e1,  e2;

  if (c==0) {
    e1 = {{ 1, 0 }};
    e2 = {{ 0, 1 }};
  } else {
    e1 = {{ 2*c, (b-a+Delta) }};
    e2 = {{ 2*c, (b-a-Delta) }};
    e1 /= norm (e1);
    e2 /= norm (e2);
  }

  Q = {{
      e1 (0),  e2 (0),
      e1 (1),  e2 (1)
    }
  };
}


template<class T>
inline void diagonalize (Tensor<T,3,2,SYM> const& M, Tensor<T, 3, 2>& Q, Tensor<T,3>& w) {

  Tensor<T,3,2,SYM> A = M;

// ----------------------------------------------------------------------------
// https://www.mpi-hd.mpg.de/personalhomes/globes/3x3
//
// Calculates the eigenvalues of a hermitian 3x3 matrix A using Cardano's
// analytical algorithm.
// Only the diagonal and upper triangular parts of A are accessed. The access
// is read-only.
// ----------------------------------------------------------------------------
// Parameters:
//   A: The hermitian input matrix
//   w: Storage buffer for eigenvalues
// ----------------------------------------------------------------------------
// Return value:
//   0: Success
//  -1: Error
// ----------------------------------------------------------------------------
  {
    double m, c1, c0;

    // Determine coefficients of characteristic polynomial. We write
    //       | a   d   f  |
    //  A =  | d*  b   e  |
    //       | f*  e*  c  |
    double de = A.at (1,0) * A.at (2,1);                      // d * e
    double dd = SQ (A.at (1,0));                             // d * conj(d)
    double ee = SQ (A.at (2,1));                             // e * conj(e)
    double ff = SQ (A.at (2,0));                             // f * conj(f)
    m  = A.at (0,0) + A.at (1,1) + A.at (2,2);
    c1 = (A.at (0,0) *A.at (1,1)    // a*b + a*c + b*c - d*conj(d) - e*conj(e) - f*conj(f)
          + A.at (0,0) *A.at (2,2)
          + A.at (1,1) *A.at (2,2))
         - (dd + ee + ff);
    c0 = A.at (2,2) *dd + A.at (0,0) *ee + A.at (1,1) *ff
         - A.at (0,0) *A.at (1,1) *A.at (2,2)
         - 2.0 * A.at (2,0) *de;
    // c*d*conj(d) + a*e*conj(e) + b*f*conj(f) - a*b*c - 2*Re(conj(f)*d*e)

    double p, sqrt_p, q, c, s, phi;
    p = SQ (m) - 3.0*c1;
    q = m* (p - (3.0/2.0) *c1) - (27.0/2.0) *c0;
    sqrt_p = sqrt (abs (p));

    phi = 27.0 * (0.25*SQ (c1) * (p - c1) + c0* (q + 27.0/4.0*c0));
    phi = (1.0/3.0) * atan2 (sqrt (abs (phi)), q);

    c = sqrt_p*cos (phi);
    s = (1.0/sqrt (3.)) *sqrt_p*sin (phi);

    w (1)  = (1.0/3.0) * (m - c);
    w (2)  = w (1) + s;
    w (0)  = w (1) + c;
    w (1) -= s;
  }



// ----------------------------------------------------------------------------
// https://www.mpi-hd.mpg.de/personalhomes/globes/3x3
//
// Calculates the eigenvalues and normalized eigenvectors of a hermitian 3x3
// matrix A using Cardano's method for the eigenvalues and an analytical
// method based on vector cross products for the eigenvectors.
// Only the diagonal and upper triangular parts of A need to contain meaningful
// values. However, all of A may be used as temporary storage and may hence be
// destroyed.
// ----------------------------------------------------------------------------
// Parameters:
//   A: The hermitian input matrix
//   Q: Storage buffer for eigenvectors
//   w: Storage buffer for eigenvalues
// ----------------------------------------------------------------------------
// Return value:
//   0: Success
//  -1: Error
// ----------------------------------------------------------------------------
  {
    const T DBL_EPSILON = std::numeric_limits<T>::denorm_min();
    double norm;          // Squared norm or inverse norm of current eigenvector
    double n0, n1;        // Norm of first and second columns of A
    double n0tmp, n1tmp;  // "Templates" for the calculation of n0/n1 - saves a few FLOPS
    double thresh;        // Small number used as threshold for floating point comparisons
    double error;         // Estimated maximum roundoff error in some steps
    double wmax;          // The eigenvalue of maximum modulus
    double f;     // Intermediate storage
    double t;             // Intermediate storage
    int i, j;             // Loop counters


    wmax = abs (w (0));

    if ( (t=abs (w (1))) > wmax)
      wmax = t;

    if ( (t=abs (w (2))) > wmax)
      wmax = t;

    thresh = SQ (8. * DBL_EPSILON * wmax);

    // Prepare calculation of eigenvectors
    n0tmp   = SQ (A.at (1,0)) + SQ (A.at (2,0));
    n1tmp   = SQ (A.at (1,0)) + SQ (A.at (2,1));
    Q.at (0,1) = A.at (1,0) *A.at (2,1) - A.at (2,0) *A.at (1,1);
    Q.at (1,1) = A.at (2,0) *A.at (1,0) - A.at (2,1) *A.at (0,0);
    Q.at (2,1) = SQ (A.at (1,0));

    // Calculate first eigenvector by the formula
    //   v(0) =  (A - w(0)).e1 x (A - w(0)).e2
    A.at (0,0) -= w (0);
    A.at (1,1) -= w (0);
    Q.at (0,0) = Q.at (0,1) + A.at (2,0) *w (0);
    Q.at (1,0) = Q.at (1,1) + A.at (2,1) *w (0);
    Q.at (2,0) = A.at (0,0) *A.at (1,1) - Q.at (2,1);
    norm    = SQ (Q.at (0,0)) + SQ (Q.at (1,0)) + SQ (Q.at (2,0));
    n0      = n0tmp + SQ (A.at (0,0));
    n1      = n1tmp + SQ (A.at (1,1));
    error   = n0 * n1;

    if (n0 <= thresh) {       // If the first column is zero, then (1,0,0) is an eigenvector
      Q.at (0,0) = 1.;
      Q.at (1,0) = 0.;
      Q.at (2,0) = 0.;
    } else if (n1 <= thresh) {   // If the second column is zero, then (0,1,0) is an eigenvector
      Q.at (0,0) = 0.;
      Q.at (1,0) = 1.;
      Q.at (2,0) = 0.;
    } else if (norm < SQ (64. * DBL_EPSILON) * error) {
      // If angle between A(0) and A(1) is too small, don't use
      t = SQ (A.at (1,0));   // cross product, but calculate v ~ (1, -A0/A1, 0)
      f = -A.at (0,0) / A.at (1,0);

      if (SQ (A.at (1,1)) > t) {
        t = SQ (A.at (1,1));
        f = -A.at (1,0) / A.at (1,1);
      }

      if (SQ (A.at (2,1)) > t)
        f = -A.at (2,0) / A.at (2,1);

      norm    = 1./sqrt (1 + SQ (f));
      Q.at (0,0) = norm;
      Q.at (1,0) = f * norm;
      Q.at (2,0) = 0.;
    } else {                  // This is the standard branch
      norm = sqrt (1. / norm);

      for (j=0; j < 3; j++)
        Q.at (j,0) = Q.at (j,0) * norm;
    }


    // Prepare calculation of second eigenvector
    t = w (0) - w (1);

    if (abs (t) > 8. * DBL_EPSILON * wmax) {
      // For non-degenerate eigenvalue, calculate second eigenvector by the formula
      //   v(1) =  (A - w(1)).e1 x (A - w(1)).e2
      A.at (0,0) += t;
      A.at (1,1) += t;
      Q.at (0,1)  = Q.at (0,1) + A.at (2,0) *w (1);
      Q.at (1,1)  = Q.at (1,1) + A.at (2,1) *w (1);
      Q.at (2,1)  = A.at (0,0) *A.at (1,1) - Q.at (2,1);
      norm     = SQ (Q.at (0,1)) + SQ (Q.at (1,1)) + SQ (Q.at (2,1));
      n0       = n0tmp + SQ (A.at (0,0));
      n1       = n1tmp + SQ (A.at (1,1));
      error    = n0 * n1;

      if (n0 <= thresh) {     // If the first column is zero, then (1,0,0) is an eigenvector
        Q.at (0,1) = 1.;
        Q.at (1,1) = 0.;
        Q.at (2,1) = 0.;
      } else if (n1 <= thresh) {   // If the second column is zero, then (0,1,0) is an eigenvector
        Q.at (0,1) = 0.;
        Q.at (1,1) = 1.;
        Q.at (2,1) = 0.;
      } else if (norm < SQ (64. * DBL_EPSILON) * error) {
        // If angle between A(0) and A(1) is too small, don't use
        t = SQ (A.at (1,0));   // cross product, but calculate v ~ (1, -A0/A1, 0)
        f = -A.at (0,0) / A.at (1,0);

        if (SQ (A.at (1,1)) > t) {
          t = SQ (A.at (1,1));
          f = -A.at (1,0) / A.at (1,1);
        }

        if (SQ (A.at (2,1)) > t)
          f = -A.at (2,0) / A.at (2,1) ;

        norm    = 1./sqrt (1 + SQ (f));
        Q.at (0,1) = norm;
        Q.at (1,1) = f * norm;
        Q.at (2,1) = 0.;
      } else {
        norm = sqrt (1. / norm);

        for (j=0; j < 3; j++)
          Q.at (j,1) = Q.at (j,1) * norm;
      }
    } else {
      // For degenerate eigenvalue, calculate second eigenvector according to
      //   v(1) =  v(0) x (A - w(1)).e(i)
      //
      // This would really get to complicated if we could not assume all of A to
      // contain meaningful values.
      A.at (1,0)  = A.at (1,0);
      A.at (2,0)  = A.at (2,0);
      A.at (2,1)  = A.at (2,1);
      A.at (0,0) += w (0);
      A.at (1,1) += w (0);

      for (i=0; i < 3; i++) {
        A.at (i,i) -= w (1);
        n0       = SQ (A.at (i,0)) + SQ (A (1,i)) + SQ (A.at (2,i));

        if (n0 > thresh) {
          Q.at (0,1)  = Q.at (1,0) *A.at (2,i) - Q.at (2,0) *A (1,i);
          Q.at (1,1)  = Q.at (2,0) *A.at (i,0) - Q.at (0,0) *A.at (2,i);
          Q.at (2,1)  = Q.at (0,0) *A (1,i) - Q.at (1,0) *A.at (i,0);
          norm     = SQ (Q.at (0,1)) + SQ (Q.at (1,1)) + SQ (Q.at (2,1));

          if (norm > SQ (256. * DBL_EPSILON) * n0) {    // Accept cross product only if the angle between
            // the two vectors was not too small
            norm = sqrt (1. / norm);

            for (j=0; j < 3; j++)
              Q.at (j,1) = Q.at (j,1) * norm;

            break;
          }
        }
      }

      if (i == 3) {   // This means that any vector orthogonal to v(0) is an EV.
        for (j=0; j < 3; j++)
          if (Q.at (j,0) != 0.) {    // Find nonzero element of v(0) ...
            // ... and swap it with the next one
            norm          = 1. / sqrt (SQ (Q.at (j,0)) + SQ (Q.at ( (j+1) %3,0)));
            Q.at (j,1)       = Q.at ( (j+1) %3,0) * norm;
            Q.at ( (j+1) %3,1) = -Q.at (j,0) * norm;
            Q.at ( (j+2) %3,1) = 0.;
            break;
          }
      }
    }

    // Calculate third eigenvector according to
    //   v(2) = v(0) x v(1)
    Q.at (0,2) = Q.at (1,0) *Q.at (2,1) - Q.at (2,0) *Q.at (1,1);
    Q.at (1,2) = Q.at (2,0) *Q.at (0,1) - Q.at (0,0) *Q.at (2,1);
    Q.at (2,2) = Q.at (0,0) *Q.at (1,1) - Q.at (1,0) *Q.at (0,1);
  }
}


template<class T, size_type D>
inline Tensor<T, D, 2> Sylvester_transform_matrix (Tensor<T,D,2,SYM> const& M) {
  Tensor<T, D, 2> Q; // eigenvectors
  Tensor<T, D> w;    // eigenvalues
  diagonalize (M, Q, w);

  for (size_type i=0; i<D; i++) for (size_type j=0; j<D; j++)
      Q (i, j) /= std::sqrt (std::abs (w (j)));

  return Q;
}

template<class T>
inline Tensor<T,2,2,NO_SYM> inv (Tensor<T,2,2,NO_SYM> const& M) {
  Tensor<T,2,2,NO_SYM> inv_;
  // Calculate inverse metric and determinant:
  T det_ = det (M);
  ASSERT2 (det (M) != 0);
  inv_ (0,0) =  M.at (1,1) /det_;
  inv_ (0,1) = -M.at (0,1) /det_;
  inv_ (1,0) = -M.at (1,0) /det_;
  inv_ (1,1) =  M.at (0,0) /det_;
  return inv_;
}

template<class T>
inline Tensor<T,2,2,SYM> inv (Tensor<T,2,2,SYM> const& M) {
  Tensor<T,2,2,SYM> inv_;
  // Calculate inverse metric and determinant:
  T det_ = det (M);
  ASSERT2 (det (M) != 0);
  inv_ (0,0) =  M.at (1,1) /det_;
  inv_ (1,0) = -M.at (1,0) /det_;
  inv_ (1,1) =  M.at (0,0) /det_;
  return inv_;
}

template<class T>
inline Tensor<T,3,2,NO_SYM> inv (Tensor<T,3,2,NO_SYM> const& M) {
  Tensor<T,3,2,NO_SYM> inv_;
  // Calculate inverse metric and determinant:
  T det_ = det (M);
  inv_ (0,0) = (M.at (2,2) *M.at (1,1)-M.at (2,1) *M.at (1,2)) /det_;
  inv_ (0,1) = (M.at (2,1) *M.at (0,2)-M.at (2,2) *M.at (0,1)) /det_;
  inv_ (0,2) = (M.at (1,2) *M.at (0,1)-M.at (1,1) *M.at (0,2)) /det_;
  inv_ (1,0) = (M.at (2,0) *M.at (1,2)-M.at (2,2) *M.at (1,0)) /det_;
  inv_ (1,1) = (M.at (2,2) *M.at (0,0)-M.at (2,0) *M.at (0,2)) /det_;
  inv_ (1,2) = (M.at (0,2) *M.at (1,0)-M.at (0,0) *M.at (1,2)) /det_;
  inv_ (2,0) = (M.at (1,0) *M.at (2,1)-M.at (1,1) *M.at (2,0)) /det_;
  inv_ (2,1) = (M.at (0,1) *M.at (2,0)-M.at (0,0) *M.at (2,1)) /det_;
  inv_ (2,2) = (M.at (0,0) *M.at (1,1)-M.at (0,1) *M.at (1,0)) /det_;
  return inv_;
}

template<class T>
inline Tensor<T,3,2,SYM> inv (Tensor<T,3,2,SYM> const& M) {
  Tensor<T,3,2,SYM> inv_;
  // Calculate inverse metric and determinant:
  T det_ = det (M);
  inv_ (0,0) = (M.at (2,2) *M.at (1,1)-M.at (2,1) *M.at (2,1)) /det_;
  inv_ (1,0) = (M.at (2,0) *M.at (2,1)-M.at (2,2) *M.at (1,0)) /det_;
  inv_ (1,1) = (M.at (2,2) *M.at (0,0)-M.at (2,0) *M.at (2,0)) /det_;
  inv_ (2,0) = (M.at (1,0) *M.at (2,1)-M.at (1,1) *M.at (2,0)) /det_;
  inv_ (2,1) = (M.at (1,0) *M.at (2,0)-M.at (0,0) *M.at (2,1)) /det_;
  inv_ (2,2) = (M.at (0,0) *M.at (1,1)-M.at (1,0) *M.at (1,0)) /det_;
  return inv_;
}


template<class T,  TensorSymmetryType S>
inline Tensor<T,4,2,S> inv (Tensor<T,4,2,S> const& M) {
  Tensor<T,4,2,S> inv_;
  // Calculate inverse metric and determinant:
  T det_ = det (M);
  inv_ (0,0) = (M (1,2) *M (2,3) *M (3,1) - M (1,3) *M (2,2) *M (3,1) + M (1,3) *M (2,1) *M (3,2) - M (1,1) *M (2,3) *M (3,2) - M (1,2) *M (2,1) *M (3,3) + M (1,1) *M (2,2) *M (3,3)) /det_;
  inv_ (0,1) = (M (0,3) *M (2,2) *M (3,1) - M (0,2) *M (2,3) *M (3,1) - M (0,3) *M (2,1) *M (3,2) + M (0,1) *M (2,3) *M (3,2) + M (0,2) *M (2,1) *M (3,3) - M (0,1) *M (2,2) *M (3,3)) /det_;
  inv_ (0,2) = (M (0,2) *M (1,3) *M (3,1) - M (0,3) *M (1,2) *M (3,1) + M (0,3) *M (1,1) *M (3,2) - M (0,1) *M (1,3) *M (3,2) - M (0,2) *M (1,1) *M (3,3) + M (0,1) *M (1,2) *M (3,3)) /det_;
  inv_ (0,3) = (M (0,3) *M (1,2) *M (2,1) - M (0,2) *M (1,3) *M (2,1) - M (0,3) *M (1,1) *M (2,2) + M (0,1) *M (1,3) *M (2,2) + M (0,2) *M (1,1) *M (2,3) - M (0,1) *M (1,2) *M (2,3)) /det_;
  inv_ (1,0) = (M (1,3) *M (2,2) *M (3,0) - M (1,2) *M (2,3) *M (3,0) - M (1,3) *M (2,0) *M (3,2) + M (1,0) *M (2,3) *M (3,2) + M (1,2) *M (2,0) *M (3,3) - M (1,0) *M (2,2) *M (3,3)) /det_;
  inv_ (1,1) = (M (0,2) *M (2,3) *M (3,0) - M (0,3) *M (2,2) *M (3,0) + M (0,3) *M (2,0) *M (3,2) - M (0,0) *M (2,3) *M (3,2) - M (0,2) *M (2,0) *M (3,3) + M (0,0) *M (2,2) *M (3,3)) /det_;
  inv_ (1,2) = (M (0,3) *M (1,2) *M (3,0) - M (0,2) *M (1,3) *M (3,0) - M (0,3) *M (1,0) *M (3,2) + M (0,0) *M (1,3) *M (3,2) + M (0,2) *M (1,0) *M (3,3) - M (0,0) *M (1,2) *M (3,3)) /det_;
  inv_ (1,3) = (M (0,2) *M (1,3) *M (2,0) - M (0,3) *M (1,2) *M (2,0) + M (0,3) *M (1,0) *M (2,2) - M (0,0) *M (1,3) *M (2,2) - M (0,2) *M (1,0) *M (2,3) + M (0,0) *M (1,2) *M (2,3)) /det_;
  inv_ (2,0) = (M (1,1) *M (2,3) *M (3,0) - M (1,3) *M (2,1) *M (3,0) + M (1,3) *M (2,0) *M (3,1) - M (1,0) *M (2,3) *M (3,1) - M (1,1) *M (2,0) *M (3,3) + M (1,0) *M (2,1) *M (3,3)) /det_;
  inv_ (2,1) = (M (0,3) *M (2,1) *M (3,0) - M (0,1) *M (2,3) *M (3,0) - M (0,3) *M (2,0) *M (3,1) + M (0,0) *M (2,3) *M (3,1) + M (0,1) *M (2,0) *M (3,3) - M (0,0) *M (2,1) *M (3,3)) /det_;
  inv_ (2,2) = (M (0,1) *M (1,3) *M (3,0) - M (0,3) *M (1,1) *M (3,0) + M (0,3) *M (1,0) *M (3,1) - M (0,0) *M (1,3) *M (3,1) - M (0,1) *M (1,0) *M (3,3) + M (0,0) *M (1,1) *M (3,3)) /det_;
  inv_ (2,3) = (M (0,3) *M (1,1) *M (2,0) - M (0,1) *M (1,3) *M (2,0) - M (0,3) *M (1,0) *M (2,1) + M (0,0) *M (1,3) *M (2,1) + M (0,1) *M (1,0) *M (2,3) - M (0,0) *M (1,1) *M (2,3)) /det_;
  inv_ (3,0) = (M (1,2) *M (2,1) *M (3,0) - M (1,1) *M (2,2) *M (3,0) - M (1,2) *M (2,0) *M (3,1) + M (1,0) *M (2,2) *M (3,1) + M (1,1) *M (2,0) *M (3,2) - M (1,0) *M (2,1) *M (3,2)) /det_;
  inv_ (3,1) = (M (0,1) *M (2,2) *M (3,0) - M (0,2) *M (2,1) *M (3,0) + M (0,2) *M (2,0) *M (3,1) - M (0,0) *M (2,2) *M (3,1) - M (0,1) *M (2,0) *M (3,2) + M (0,0) *M (2,1) *M (3,2)) /det_;
  inv_ (3,2) = (M (0,2) *M (1,1) *M (3,0) - M (0,1) *M (1,2) *M (3,0) - M (0,2) *M (1,0) *M (3,1) + M (0,0) *M (1,2) *M (3,1) + M (0,1) *M (1,0) *M (3,2) - M (0,0) *M (1,1) *M (3,2)) /det_;
  inv_ (3,3) = (M (0,1) *M (1,2) *M (2,0) - M (0,2) *M (1,1) *M (2,0) + M (0,2) *M (1,0) *M (2,1) - M (0,0) *M (1,2) *M (2,1) - M (0,1) *M (1,0) *M (2,2) + M (0,0) *M (1,1) *M (2,2)) /det_;
  return inv_;
}




// ================= STRING OUTPUT ====================
template < class T, size_type D >
string tostring (const Tensor<T,D>& v) {
  string out = "[";
  for (size_type i=0; i<D; ++i) {
    out += tostring (v (i));
    if (i != D-1) out += ", ";
  }
  out += "]";
  return out;
}

template < class T, size_type D, TensorSymmetryType S >
string tostring (const Tensor<T,D,2,S>& v) {
  string out = "[";
  for (size_type i=0; i<D; ++i) {
    for (size_type j=0; j<D; ++j) {
      out += tostring (v (i,j));
      if (j != D-1) out += ", ";
    }
    if (i != D-1) out += "\n ";
  }
  out += "]";
  return out;
}

template < class T, size_type D, TensorSymmetryType S >
string tostring (const Tensor<T,D,3,S>& v) {
  string out = "[";
  for (size_type i=0; i<D; ++i) {
    out += "[";
    for (size_type j=0; j<D; ++j) {
      for (size_type k=0; k<D; ++k) {
        out += tostring (v (i,j,k));
        if (k != D-1) out += ", ";
      }
      if (j != D-1) out += "\n  ";
    }
    out += "]";
    if (i != D-1) out += "\n ";
  }
  out += "]";
  return out;
}


template < class U, class T, size_type D, size_type O, TensorSymmetryType S  >
U& operator<< (U& out, const Tensor<T,D,O,S>& v) {
  return out << tostring (v);
}


// Type Aliases:
template<class T, size_type D> using Vector = Tensor<T,D>;
template<class T, size_type D> using Metric = Tensor<T,D,2,SYM>;
template<class T, size_type D> using ChristoffelSymbol = Tensor<T,D,3,SEMI_SYM>;
template<class T, size_type Q> using LatticeScalar = Tensor<T,Q>;
template<class T, size_type D, size_type Q> using LatticeVector = LatticeTensor<T,D,Q>;

template<class T, size_type LS> using Spinor = Tensor<T,LS>;
template<class T, size_type D>  using Matrix = Tensor<T,D,2>;

#endif // !defined TENSOR_HPP
