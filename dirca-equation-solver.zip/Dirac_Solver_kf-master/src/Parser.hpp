//Copyright (c) 2016 Jens-Daniel Debus, ETH Zurich
#ifndef PARSER_HPP
#define PARSER_HPP

// Command line and configfile parser
#include "GetPot.h"
#include "mpParser.h"

// Macros and Vectors
#include "macros.hpp"
#include "tensor.hpp"



typedef mup::Value Value;
typedef mup::ParserX ParserX;
typedef mup::Variable Variable;
typedef mup::ParserError ParserError;




//======== Type Casts from Value to double/complex/bool... ==========

template<typename T> T cast_Value (Value v);
template<> float_type cast_Value (Value v) {
  return v.GetFloat();
};
template<> complex<float_type> cast_Value (Value v) {
  return v.GetComplex();
};
template<> bool cast_Value (Value v) {
  return v.GetBool();
};
template<> string cast_Value (Value v) {
  return v.GetString();
};






// ====================== Parser Elements==========================

class ParserElement {
  protected:
    GetPot* command_line;
    GetPot* config_file;
    ParserX* p;

    string name_space; // section name in the config file
    string var_name;   // variable name in the config file

  public:
    ParserElement() {}
    ParserElement (GetPot* command_line_,
                   GetPot* config_file_,
                   ParserX* p_,
                   string name_space_,
                   string var_name_
                  )
      :
      command_line (command_line_),
      config_file (config_file_),
      p (p_),
      name_space (name_space_),
      var_name (var_name_) {}

    virtual int parse() = 0;
    virtual void update() = 0;
};


template<typename T, size_type L> // T = int or double type
class NumericVectorElement : public ParserElement {
  private:
    Vector<T,L>* var_pointer;   // pointer to the actual variable, to which the parsed value should be written
    Vector<Value,L> var; // internal variable in special parser type ('Value')

  public:
    template<typename U> // U = int or double type
    NumericVectorElement (GetPot* command_line_,
                          GetPot* config_file_,
                          ParserX* p_,
                          string name_space_,
                          string var_name_,
                          Vector<T,L>* var_pointer_,
                          Vector<U,L> default_value_)
      :
      ParserElement (command_line_, config_file_, p_, name_space_, var_name_),
      var_pointer (var_pointer_) {
      for (size_type l=0; l<L; l++)
        var (l) = static_cast<float_type> (default_value_ (l));
    }

    void update() override {
      for (size_type l=0; l<L; l++)
        (*var_pointer) (l) = var (l).GetFloat();
    }

    int parse () override {
      int n=0;
      for (size_type l=0; l<L; l++)
        n += parse (l);
      return n;
    }

    int parse (int l) {
      // First search in command line
      if (command_line->search ( ("--" + var_name).c_str())) {
        var (l) = command_line->next (0.);
        cout << "Using " << var_name << " = " << var (l) << endl;
        try {
          p->DefineVar (var_name, Variable (& (var (l))));
        } catch (ParserError& e) {
          if (e.GetCode() == mup::ecVARIABLE_DEFINED) return 0;
          else error ("PARSER ERROR in "+LINE+": "+e.GetMsg());
        }
      }

      // Else search in config file
      else {
        // Check if variable is set in config file (else use default value):
        if (config_file->vector_variable_size ( (name_space+"/"+var_name).c_str()) <= l) {
          cout << "PARSER INFO: Using default value for " <<  var_name << "[" << l << "] = " << var (l) << endl;
          return 0;
        }

        // Parse variable from config file
        try {
          string expr = (*config_file) ( (name_space+"/"+var_name).c_str(), "0", l);
          if (IS_NUMBER (expr)) {     // if expression is a simple number (e.g. 42)
            var (l) = stof (expr);
            p->DefineVar (var_name, Variable (& (var (l))));
          } else { // if expression is an expression (e.g. a+b)
            p->SetExpr (expr);
            var (l) = p->Eval();
            p->DefineVar (var_name, Variable (& (var (l))));
          }
        } catch (ParserError& e) {
          if (e.GetCode() == mup::ecUNASSIGNABLE_TOKEN) return 1;
          else if (e.GetCode() == mup::ecVARIABLE_DEFINED) return 0;
          else error ("PARSER ERROR in "+LINE+": "+e.GetMsg());
        }
      }
      return 0;
    }
};


template<typename T> // T = int or double type
class NumericElement : public ParserElement {
  private:
    T* var_pointer;     // pointer to the actual variable, to which the parsed value should be writte

    Vector<T,1> var;              // temporary field
    NumericVectorElement<T,1> el; // use the NumericVectorElement for parsing

  public:
    template<typename U> // U = int or double type
    NumericElement (GetPot* command_line_,
                    GetPot* config_file_,
                    ParserX* p_,
                    string name_space_,
                    string var_name_,
                    T* var_pointer_,
                    U default_value_)
      :
      var_pointer (var_pointer_),
      el (command_line_,
          config_file_,
          p_,
          name_space_,
          var_name_,
          &var,
          Vector<U,1> (default_value_)
         ) {}

    void update() override {
      el.update();  // update var
      *var_pointer = var (0);
    }

    int parse () override {
      return el.parse();
    }
};


template<typename T> // T = string or enum
class StringElement : public ParserElement {
  private:
    T* var_pointer;
    string var;

  public:
    StringElement (GetPot* command_line_,
                   GetPot* config_file_,
                   ParserX* p_,
                   string name_space_,
                   string var_name_,
                   T* var_pointer_,
                   string default_value_)
      :
      ParserElement (command_line_, config_file_, p_, name_space_, var_name_),
      var_pointer (var_pointer_),
      var (default_value_) {}

    void update() override {
      *var_pointer = cast_string<T> (var);
    };

    int parse () override {
      // First search in command line
      if (command_line->search ( ("--"+var_name).c_str())) {
        var = string (command_line->next (""));
        cout << "Using " << var_name << " = " << var << endl;
      }
      // Else search in config file
      else {
        int position = 0;
        if (config_file->vector_variable_size ( (name_space+"/"+var_name).c_str()) <= position) {
          cout << "PARSER INFO: Using default value for " <<  var_name << "[" << position << "] = " << var << endl;
          return 0;
        }
        var = (*config_file) ( (name_space+"/"+var_name).c_str(), "0", position);
      }

      auto var_split = split (var, '+');
      std::stringstream var_stream;
      for (int i=0; i<var_split.size(); i++) {
        string expr = var_split[i];
        try {
          p->SetExpr (expr);
          var_stream << p->Eval();
        } catch (ParserError& e) {
          var_stream << remove_token (expr, '\"');
        }
      }
      var = var_stream.str();
      return 0;
    }
};


template<typename T, size_type D, size_type L>
class VectorFunctionElement : public ParserElement {
  private:
    function<Vector<T, L> (Vector<float_type, D> xyz, float_type t) >* var_pointer;
    function<Vector<T, L> (Vector<float_type, D> xyz, float_type t) > var;

    string default_function_name;
    
    // x,y,z,t-variables for function objects
    Vector<Value, D>* xyz;
    Value* t;

  public:
    template<typename T1> // T1 = lambda function
    VectorFunctionElement (
      GetPot* command_line_,
      GetPot* config_file_,
      ParserX* p_,
      string name_space_,
      string var_name_,
      function<Vector<T, L> (Vector<float_type, D> xyz, float_type t) >* var_pointer_,
      T1 default_function_,
      string default_function_name_,
      Vector<Value, D>* xyz_,
      Value* t_)
      :
      ParserElement (command_line_, config_file_, p_, name_space_, var_name_),
      var_pointer (var_pointer_),
      var (default_function_),
      default_function_name(default_function_name_),
      xyz (xyz_),
      t (t_) {}

    void update() override {
      *var_pointer = var;
    }

    int parse () override {
      try {
        // Check if variable is set in config file (else use default value):
        if (config_file->vector_variable_size ( (name_space+"/" +var_name).c_str()) <= 0) {
          cout << "PARSER INFO: Using default function " <<  var_name << " = " << default_function_name << endl;
          return 0;
        }

        // get vector expression from config file
        string expr[L];
        for (size_type i=0; i<L; i++)
          expr[i] = (*config_file) ( (name_space+"/" +var_name).c_str(), "0", i);

        // Define vector function
        var = [&, expr] (Vector<float_type, D> xyz_, float_type t_) -> Vector<T, L> {
          Vector<T, L> res;
          # pragma omp critical
          {
            *xyz = xyz_;
            *t = t_;
            for (size_type i=0; i<L; i++) {
              try {
                p->SetExpr (expr[i]);
                Value result = p->Eval();
                res (i) = cast_Value<T> (result);
              } catch (ParserError& e) {
                error ("PARSER ERROR in "+LINE+": "+e.GetMsg());
              }
            }
          }
          return res;
        };
      } catch (ParserError& e) {
        error ("PARSER ERROR in "+LINE+": "+e.GetMsg());
      }
      return 0;
    }
};


template<typename T, size_type D, size_type L>
class VectorFunctionSpaceElement : public ParserElement {
  private:
    function<Vector<T, L> (Vector<float_type, D> xyz) >* var_pointer;     // pointer to the actual variable, to which the parsed value should be writte

    function<Vector<T, L> (Vector<float_type, D> xyz, float_type t) > var;              // temporary field
    VectorFunctionElement<T,D,L> el; // use the VectorFunctionElement for parsing

  public:
    template<typename T1> // T1 = lambda function type
    VectorFunctionSpaceElement (
      GetPot* command_line_,
      GetPot* config_file_,
      ParserX* p_,
      string name_space_,
      string var_name_,
      function<Vector<T, L> (Vector<float_type, D> xyz) >* var_pointer_,
      T1 default_function_,
      string default_function_name_,
      Vector<Value, D>* xyz_,
      Value* t_)
      :
      //ParserElement (command_line_, config_file_, p_, name_space_, var_name_),
      var_pointer (var_pointer_),
      el (command_line_,
          config_file_,
          p_,
          name_space_,
          var_name_,
          &var,
          [&] (Vector<float_type, D> xyz, float_type t) -> Vector<T,L> {
      return default_function_ (xyz);
    },
    default_function_name_,
    xyz_,
    t_) {}

    void update() override {
      el.update();
      *var_pointer = [&] (Vector<float_type, D> xyz) -> Vector<T,L> {
        return var (xyz,0);
      };
    }

    int parse () override {
      return el.parse(); // update var
    }
};


template<typename T, size_type D>
class FunctionElement : public ParserElement {
  private:
    function<T (Vector<float_type, D> xyz, float_type t) >* var_pointer;     // pointer to the actual variable, to which the parsed value should be writte

    function<Vector<T,1> (Vector<float_type, D> xyz, float_type t) > var;              // temporary field
    VectorFunctionElement<T,D,1> el; // use the VectorFunctionElement for parsing

  public:
    template<typename T1> // T1 = lambda function type
    FunctionElement (
      GetPot* command_line_,
      GetPot* config_file_,
      ParserX* p_,
      string name_space_,
      string var_name_,
      function<T (Vector<float_type, D> xyz, float_type t) >* var_pointer_,
      T1 default_function_,
      string default_function_name_,
      Vector<Value, D>* xyz_,
      Value* t_)
      :
      //ParserElement (command_line_, config_file_, p_, name_space_, var_name_),
      var_pointer (var_pointer_),
      el (command_line_,
          config_file_,
          p_,
          name_space_,
          var_name_,
          &var,
          (default_function_==NULL) ? 
      (function<Vector<T,1> (Vector<float_type, D> xyz, float_type t) >)NULL 
      : [&] (Vector<float_type, D> xyz, float_type t) -> Vector<T,1> {
      return Vector<T,1> (default_function_ (xyz,t));
    },
    default_function_name_,
    xyz_,
    t_) {}

    void update() override {
      el.update();
      *var_pointer = (var==NULL) ? 
      (function<T (Vector<float_type, D> xyz, float_type t) >)NULL 
      : [&] (Vector<float_type, D> xyz, float_type t) -> T {
        return var (xyz,t) (0);
      };
    }

    int parse () override {
      return el.parse(); // update var
    }
};


template<typename T, size_type D>
class FunctionSpaceElement : public ParserElement {
  private:
    function<T (Vector<float_type, D> xyz) >* var_pointer;     // pointer to the actual variable, to which the parsed value should be writte

    function<Vector<T,1> (Vector<float_type, D> xyz, float_type t) > var;              // temporary field
    VectorFunctionElement<T,D,1> el; // use the VectorFunctionElement for parsing

  public:
    template<typename T1> // T1 = lambda function type
    FunctionSpaceElement (
      GetPot* command_line_,
      GetPot* config_file_,
      ParserX* p_,
      string name_space_,
      string var_name_,
      function<T (Vector<float_type, D> xyz) >* var_pointer_,
      T1 default_function_,
      string default_function_name_,
      Vector<Value, D>* xyz_,
      Value* t_)
      :
      //ParserElement (command_line_, config_file_, p_, name_space_, var_name_),
      var_pointer (var_pointer_),
      el (command_line_,
          config_file_,
          p_,
          name_space_,
          var_name_,
          &var,
          [&] (Vector<float_type, D> xyz, float_type t) -> Vector<T,1> {
      return Vector<T,1> (default_function_ (xyz));
    },
    default_function_name_,
    xyz_,
    t_) {}

    void update() override {
      el.update();
      *var_pointer = [&] (Vector<float_type, D> xyz) -> T {
        return var (xyz,0) (0);
      };
    }

    int parse () override {
      return el.parse(); // update var
    }
};









// ========================== Parser ============================

template<size_type D>
class Parser {
  private:
    GetPot command_line;
    GetPot config_file;
    ParserX p;

    // x,y,z,t-variables for function objects
    Vector<Value,D> xyz;
    Value t;

    vector<ParserElement*> variable_pool;
    vector<ParserElement*> string_pool;
    vector<ParserElement*> function_pool;

  public:
    Parser (int argc, char* argv[]) {
      // command line parser
      command_line = GetPot (argc,argv);

      // config file parser
      if (command_line.search ("-c")) {      // parse config file
        const vector<string> cfgname_tmp  = command_line.nominus_followers ("-c");
        ASSERT1 (cfgname_tmp.size() == 1)
        string cfgname = cfgname_tmp[0];
        cout << "Using config file " << cfgname << endl << endl;

        // make sure the config file can be read
        std::ifstream cfgfile (cfgname.c_str());
        if (!cfgfile) error ("PARSER ERROR in "+LINE+": Can't open config file: " + cfgname);
        cfgfile.close();

        config_file = GetPot (cfgname.c_str());
      } else print_help (argv[0]);

      // Initialize function variables (x,y,z,t)
      if (D==2) {
        p.DefineVar ("x", &xyz[0]);
        p.DefineVar ("y", &xyz[1]);
        p.DefineVar ("t", &t);
      } else if (D==3) {
        p.DefineVar ("x", &xyz[0]);
        p.DefineVar ("y", &xyz[1]);
        p.DefineVar ("z", &xyz[2]);
        p.DefineVar ("t", &t);
      } else error ("PARSER ERROR in "+LINE+": Dimension D="+to_string (D) +" not supported by function parser");
    }


    string get_config_filename() {
      if (command_line.search ("-c")) {      // parse config file
        const vector<string> cfgname_tmp  = command_line.nominus_followers ("-c");
        ASSERT1 (cfgname_tmp.size() == 1)
        return cfgname_tmp[0];
      } else
        return NULL;
    }




    // ================ register methods ====================

    template<typename T, typename U>
    void register_variable (T* var, string name_space, string var_name, U default_value) {
      variable_pool.push_back (
        new NumericElement<T> (
          &command_line,
          &config_file,
          &p,
          name_space,
          var_name,
          var,
          default_value
        )
      );
    }

    template<typename T, typename U, size_type L>
    void register_variable (Vector<T,L>* var, string name_space, string var_name, Vector<U,L> default_value) {
      variable_pool.push_back (
        new NumericVectorElement<T,L> (
          &command_line,
          &config_file,
          &p,
          name_space,
          var_name,
          var,
          default_value
        )
      );
    }

    template<typename T>
    void register_string (T* var, string name_space, string var_name, string default_value) {
      string_pool.push_back (
        new StringElement<T> (
          &command_line,
          &config_file,
          &p,
          name_space,
          var_name,
          var,
          default_value
        )
      );
    }

    template<typename T, size_type L, typename T1>
    void register_function (function<Vector<T,L> (Vector<float_type, D>, float_type) >* var, string name_space, string var_name, T1 default_function, string default_function_name) {
      function_pool.push_back (
        new VectorFunctionElement<T,D,L> (
          &command_line,
          &config_file,
          &p,
          name_space,
          var_name,
          var,
          default_function,
          default_function_name,
          &xyz,
          &t)
      );
    }

    template<typename T, size_type L, typename T1>
    void register_function (function<Vector<T,L> (Vector<float_type, D>) >* var, string name_space, string var_name, T1 default_function, string default_function_name) {
      function_pool.push_back (
        new VectorFunctionSpaceElement<T,D,L> (
          &command_line,
          &config_file,
          &p,
          name_space,
          var_name,
          var,
          default_function,
          default_function_name,
          &xyz,
          &t)
      );
    }

    template<typename T, typename T1>
    void register_function (function<T (Vector<float_type, D>, float_type) >* var, string name_space, string var_name, T1 default_function, string default_function_name) {
      function_pool.push_back (
        new FunctionElement<T,D> (
          &command_line,
          &config_file,
          &p,
          name_space,
          var_name,
          var,
          default_function,
          default_function_name,
          &xyz,
          &t)
      );
    }

    template<typename T, typename T1>
    void register_function (function<T (Vector<float_type, D>) >* var, string name_space, string var_name, T1 default_function, string default_function_name) {
      function_pool.push_back (
        new FunctionSpaceElement<T,D> (
          &command_line,
          &config_file,
          &p,
          name_space,
          var_name,
          var,
          default_function,
          default_function_name,
          &xyz,
          &t)
      );
    }




    // ================ parsing methods ===================

    void parse_variables() {
      int r=0; // recursion level
      int n=1; // number of unresolved expressions
      while (r<MAX_PARSER_RECURSION_LEVEL && n>0) {
        n=0;
        for (unsigned int i=0; i<variable_pool.size(); i++) {
          n += variable_pool[i]->parse();
        }
        r++;
      }
      if (r==MAX_PARSER_RECURSION_LEVEL)
        error ("PARSER ERROR in "+LINE+": An expression in the config file cannot be resolved (maximum parser recursion level reached).");

      // update numeric pointers
      for (unsigned int i=0; i<variable_pool.size(); i++)
        variable_pool[i]->update();
    }

    void parse_strings() {
      for (unsigned int i=0; i<string_pool.size(); i++) {
        string_pool[i]->parse();
        string_pool[i]->update();
      }
    }

    void parse_functions() {
      for (unsigned int i=0; i<function_pool.size(); i++) {
        function_pool[i]->parse();
        function_pool[i]->update();
      }
    }
};


#endif // !defined PARSER_HPP
