/**
 * \file
 * \author Jens-Daniel Debus,  ETH Zurich
 * \date 2015
 * \brief Lattice Boltzmann solver for Dirac equation in curved space
 * \details
 */

// Packages,  Macros,  typedefs, Tensor-Containers (Vector, Tensor, Spinor...), Lattices
#include "macros.hpp"
#include "tensor.hpp"
#include "Lattice.hpp"
#include "ParameterCache.hpp"
#include "Writer.hpp"
#include "Parser.hpp"

// LB Core Class
#include "LB.hpp"

// Dirac Configuration Class
#include "ConfigDirac.hpp"


int main (int argc, char* argv[]) {

  // template parameters
  constexpr LatticeType LT = D2Q9;
  constexpr size_type D  = 2;
  constexpr size_type D0 = 3;
  constexpr size_type Q  = 9;
  constexpr size_type LS = 4;

  // parser (for config file and command line parameters)
  Parser<D> p (argc, argv);

  // parameter cache (containing all simulation parameters)
  ParameterCache* pc = new ParameterCache();
  vector<Writer<LT,D0,LS>*> writer_pool;

  // register variables
  size_type D_;
  p.register_variable (&D_,           "lattice", "D", 2);
  p.register_variable (&pc->LX,       "lattice", "LX", 128);
  p.register_variable (&pc->LY,       "lattice", "LY", 128);
  p.register_variable (&pc->refinement_level, "lattice", "refinement_level", 1);
  p.register_variable (&pc->dt,       "times", "dt", 1);
  p.register_variable (&pc->time_step,"times", "time_step", 1);
  p.register_variable (&pc->T_MAX,    "times", "T_MAX", 100);
  p.register_variable (&pc->mass,     "parameters", "mass", 0);

  // register strings
  string config = "default";
  p.register_string (&config, "config", "config", "default");
  p.register_string (&pc->path, "output", "path", "default");
  p.register_string (&pc->boundary_type, "boundaries", "boundary_type", "PERIODIC");
  p.register_string (&pc->potential_type, "external_potentials", "potential_type", "STATIC");
  p.register_string (&pc->potential_implementation, "external_potentials", "potential_implementation", "SCALAR");
  p.register_string (&pc->geometry_type, "geometry", "geometry_type", "STATIC");
  p.register_string (&pc->initial_state_path, "input", "initial_state_path", "NONE");
  p.register_string (&pc->hamiltonian_type, "external_potentials", "hamiltonian_type", "GRAPHENE");

  string writer_type[30];
  p.register_string (&writer_type[0],  "output", "write_lattice_index", "false");
  p.register_string (&writer_type[1],  "output", "write_coordinates", "false");
  p.register_string (&writer_type[2],  "output", "write_metric", "false");
  p.register_string (&writer_type[3],  "output", "write_sqrt_metric", "false");
  p.register_string (&writer_type[4],  "output", "write_Christoffel_symbols", "false");
  p.register_string (&writer_type[5],  "output", "write_Ricci_scalar", "false");
  p.register_string (&writer_type[6],  "output", "write_density", "false");
  p.register_string (&writer_type[7],  "output", "write_current", "false");
  p.register_string (&writer_type[8],  "output", "write_psi", "false");
  p.register_string (&writer_type[9],  "output", "write_phase", "false");
  p.register_string (&writer_type[10], "output", "write_norm_t", "false");
  p.register_string (&writer_type[11], "output", "write_current_t", "false");
  p.register_string (&writer_type[12], "output", "write_psi_t", "false");
  p.register_string (&writer_type[13], "output", "write_phase_t", "false");
  p.register_string (&writer_type[14], "output", "write_energy_t", "false");
  p.register_string (&writer_type[15], "output", "write_momentum_t", "false");
  p.register_string (&writer_type[16], "output", "write_energy_density", "false");
  p.register_string (&writer_type[17], "output", "write_momentum_density", "false");
  p.register_string (&writer_type[18], "output", "write_spreads_t", "false");
  p.register_string (&writer_type[19], "output", "write_eigenfunction_state", "false");
  p.register_string (&writer_type[20], "output", "write_der_coordinates", "false");
  p.register_string (&writer_type[21], "output", "write_inverse_metric", "false");
  p.register_string (&writer_type[22],  "output", "write_tetrad", "false");
  p.register_string (&writer_type[23],  "output", "write_spin_connection_coefficient", "false");


  // register functions
  function<Spinor<complex<float_type>, LS> (Vector<float_type, D>) > initial_psi;
  function<Spinor<bool, LS> (Vector<float_type, D>) > fix_psi;
  function<float_type (Vector<float_type, D> xyz, float_type t) > V;
  function<Vector<float_type, D> (Vector<float_type, D> xyz, float_type t) > A;
  function<Vector<float_type, D0> (Vector<float_type, D> xyz, float_type t) > h;
  function<Vector<float_type, D0> (Vector<float_type, D> xyz, float_type t) > dh_dx0;
  function<Vector<float_type, D0> (Vector<float_type, D> xyz, float_type t) > dh_dx1;
  function<float_type (Vector<float_type, D> xyz, float_type t) > g00;
  function<float_type (Vector<float_type, D> xyz, float_type t) > g01;
  function<float_type (Vector<float_type, D> xyz, float_type t) > g11;
  
//   function<float_type (Vector<float_type, D> xyz, float_type t) > g00;
//   function<float_type (Vector<float_type, D> xyz, float_type t) > g01;
//   function<float_type (Vector<float_type, D> xyz, float_type t) > g11;
//   
  
  function<float_type (Vector<float_type, D> xyz, float_type t) > L000;
  function<float_type (Vector<float_type, D> xyz, float_type t) > L001;
  function<float_type (Vector<float_type, D> xyz, float_type t) > L011;
  function<float_type (Vector<float_type, D> xyz, float_type t) > L100;
  function<float_type (Vector<float_type, D> xyz, float_type t) > L101;
  function<float_type (Vector<float_type, D> xyz, float_type t) > L111;


  p.register_function (&initial_psi, "initial_fields", "psi",
  [] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
    return Spinor<complex<float_type>, LS> (0);
  },
  "(0,0,0,0)"
                      );
  p.register_function (&fix_psi,     "boundaries",           "fix_psi",
  [] (Vector<float_type, D> xyz) -> Spinor<bool, LS> {
    return Spinor<bool, LS> (false);
  },
  "(false,false,false,false)");
  p.register_function (&V,           "external_potentials",  "V",
  [] (Vector<float_type, D> xyz, float_type t) -> float_type {
    return 0;
  },
  "0");
  p.register_function (&A,           "external_potentials",  "A",
  [] (Vector<float_type, D> xyz, float_type t) -> Vector<float_type,D> {
    return Vector<float_type,D> (0);
  },
  "(0,0)");
  p.register_function (&h,           "geometry",             "h",
  [] (Vector<float_type, D> xyz, float_type t) -> Vector<float_type,D0> {
    return {{xyz (0),xyz (1),0}};
  },
  "(x,y,0)");
  p.register_function (&dh_dx0,      "geometry",             "dh_dx",
                       (function<Vector<float_type,D0> (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL");
  p.register_function (&dh_dx1,      "geometry",             "dh_dy",
                       (function<Vector<float_type,D0> (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&g00,      "geometry",             "g_xx",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&g01,      "geometry",             "g_xy",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&g11,      "geometry",             "g_yy",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  
  
//   p.register_function (&e00,      "geometry",             "g_xx",
//                        (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
//                        "NULL"
//                       );
//   p.register_function (&e01,      "geometry",             "g_xy",
//                        (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
//                        "NULL"
//                       );
//   p.register_function (&e11,      "geometry",             "g_yy",
//                        (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
//                        "NULL"
//                       );
  
  
  
  
  p.register_function (&L000,      "geometry",             "L_xxx",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&L001,      "geometry",             "L_xxy",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&L011,      "geometry",             "L_xyy",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&L100,      "geometry",             "L_yxx",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&L101,      "geometry",             "L_yxy",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );
  p.register_function (&L111,      "geometry",             "L_yyy",
                       (function<float_type (Vector<float_type, D> xyz, float_type t) >) NULL,
                       "NULL"
                      );


  // Parse base variables, strings and functions
  p.parse_variables();
  p.parse_strings();
  p.parse_functions();


  if (config == "default") {}

  else if (config == "free_particle_2D") {
    // Parse further variables (attention: pointers to previous variables in ParameterCache pc, as stored in the Parser, become invalid here)
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.parse_variables();

    p.register_string (&writer_type[12], "output", "write_spreads_t", "false");
    p.parse_strings();
    if (cast_string<bool> (writer_type[12]))
      writer_pool.push_back (new Spreads_t_Writer<LT,D0,LS> (pc->x0,pc->y0));

    p.parse_functions();

    cout << "path: " << pc->path << endl;

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      return 1./sqrt (2*M_PI*pc->spread*pc->spread) *exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,0 }};
    };
  }

  else if (config == "plane_wave_2D") {
    // Parse variables, strings and functions
    p.register_variable (&pc->nx,        "parameters", "nx", 0);
    p.register_variable (&pc->ny,        "parameters", "ny", 0);
    p.register_variable (&pc->a0,        "parameters", "a0", 0);
    p.register_variable (&pc->r0,        "parameters", "r0", 0);
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    // wave function parameters
    float_type px = (2.*M_PI*pc->nx) / (pc->LX*pc->dt);
    float_type py = (2.*M_PI*pc->ny) / (pc->LY*pc->dt);
    float_type E = sqrt (px*px + py*py + pc->mass*pc->mass);
    cout << "E = " << E << endl;
    float_type N = 1./sqrt ( (pc->LX*pc->dt) * (pc->LY*pc->dt) * (1.+ (px*px + py*py) / ( (E+pc->mass) * (E+pc->mass))));
    cout << "N = " << N << endl;

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      return N*Spinor<complex<float_type>, LS> {{ 1,0,0, (px+I*py) / (E+pc->mass) }}* exp (I* px* xyz (0))* exp (I* py*xyz (1));
      //return Spinor<complex<float_type>, LS> {{1,0,0,0}};
    };
  }

  else if (config == "plane_wave_ripples_2D"  ) {
//     Parse variables, strings and functions
    p.register_variable (&pc->nx,        "parameters", "nx", 0);
    p.register_variable (&pc->ny,        "parameters", "ny", 0);
    p.register_variable (&pc->a0,        "parameters", "a0", 0);
    p.register_variable (&pc->k0,        "parameters", "k0", 0);
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();



    cout << "path: " << pc->path << endl;

    auto f = [=] (float_type x) {
      return 0.5*dh_dx0 ( {{x,0}},0) (2) *dh_dx0 ( {{x,0}},0) (2);
    };

    auto phase_func = [=] (float_type x0, float_type x) -> float_type {
      float_type dx = 1e-2*pc->dt/pc->refinement_level;
      float_type upper_sum = 0;
      float_type lower_sum = 0;
#if LB_OMP
      #pragma omp parallel for reduction(+:lower_sum,upper_sum)
#endif
      for (int i=0; i<=int ( (x-x0) /dx-0.5); i++) {
        double x1 = i*dx+x0;
        lower_sum += sqrt (1+2*f (x1)) *dx;
        upper_sum += sqrt (1+2*f (x1+dx)) *dx;
      }
      return (lower_sum+upper_sum) /2;
    };

    // pre-initialize integral expression:
    cout << "Initializing integral expression..." << endl;
    vector<float_type> phase_vector (pc->LX*pc->refinement_level);
    phase_vector[0] = 0;
    for (size_type i=1; i<pc->LX*pc->refinement_level; i++) {
      float_type x0 = (i-1) *pc->dt/pc->refinement_level;
      float_type x1 = i*pc->dt/pc->refinement_level;
      phase_vector[i] = phase_vector[i-1] + phase_func (x0,x1);
    };
    cout << "Done.\n" << endl;

    auto phase = [=] (float_type x) -> float_type {
      // numerically:
      float_type dt = pc->dt/pc->refinement_level;
      size_type i = std::min (phase_vector.size()-1., round (x/dt));
      float_type x0 = i*dt;
      ASSERT1 (i < phase_vector.size(), "i="+tostring (i))
      return phase_vector[i] + phase_func (x0,x);
    };

    // wave function parameters
    float_type px = (2.*M_PI*pc->nx) / phase (pc->LX*pc->dt);
    float_type py = (2.*M_PI*pc->ny) / (pc->LY*pc->dt);
    float_type E = sqrt (px*px + py*py + pc->mass*pc->mass);
    float_type N = 1./sqrt (phase (pc->LX*pc->dt) * (pc->LY*pc->dt) * (1.+ (px*px + py*py) / ( (E+pc->mass) * (E+pc->mass))));

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      size_type i = round (xyz (0) /pc->dt);
      ASSERT1 (i < phase_vector.size(), "i="+tostring (i))
      return N*Spinor<complex<float_type>, LS> {{ 1,0,0, (px+I*py) / (E+pc->mass) }}* exp (I* py*xyz (1) + I* px* phase_vector[i]);
    };
  }

    else if (config == "2D_mobius_approximated_band_plane_wave_curved"  ) {
      
//    The solution can be found in mathematica under moebious band bound solution when you compare the x-dependent
//    solution to the x-y version, look for coeeficient of delx - del1 and dely then the form of the solution is 
//    is the second nobook under blue highlighter
//    To continue from here you need to A. check the bellow that gives the exact same solution as the plane wave ripples above
//    B. Implement a y depentance on the hx and check (not integrating along y, just depentance)
//    C. Implement the whole new solution for X part 
//    D. Do the same for y with y and x phases   
      
      
    // Parse variables, strings and functions
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->w,     "parameters", "r", 1);
    
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();
    cout << "path: " << pc->path << endl;


    auto hx = [=] (float_type x, float_type y) {
      return dh_dx0 ( {{x,y}},0) (2); //the (2) referes to the out of plane component and the {{x,y},t
    };
    
    
    auto phase_func = [=] (float_type x0, float_type x,float_type y) -> complex<float_type> {
      float_type dx = 1e-2*pc->dt/pc->refinement_level;
      complex<float_type> upper_sum = 0;
      complex<float_type> lower_sum = 0;
// #if LB_OMP
//       #pragma omp parallel for reduction(+:lower_sum,upper_sum)
// #endif
      for (int i=0; i<=int ( (x-x0) /dx-0.5); i++) {
        double x1 = i*dx+x0;
        lower_sum += sqrt (1+hx(x1,y)*hx (x1,y)) *dx;
        upper_sum += sqrt (1+hx(x1,y)*hx (x1+dx,y)) *dx;
      }
      return (lower_sum+upper_sum) / 2.0;
    };

    // pre-initialize integral expression:
    cout << "Initializing integral expression..." << endl;
    vector<complex<float_type>> phase_vector (pc->LX*pc->refinement_level);
    phase_vector[0] = 0;
    for (size_type i=1; i<pc->LX*pc->refinement_level; i++) {
      float_type y=0;
      float_type x0 = (i-1) *pc->dt/pc->refinement_level;
      float_type x1 = i*pc->dt/pc->refinement_level;
      phase_vector[i] = phase_vector[i-1] + phase_func (x0,x1,y);
    };
    cout << "Done.\n" << endl;

    auto phase = [=] (float_type x, float_type y) -> complex<float_type> {
      // numerically:
      float_type dt = pc->dt/pc->refinement_level;
      size_type i = std::min (phase_vector.size()-1., round (x/dt));
      float_type x0 = i*dt;
      ASSERT1 (i < phase_vector.size(), "i="+tostring (i))
      return phase_vector[i] + phase_func (x0,x,y);  //phase func determines the total accuired phase up to that point
    };

    // wave function parameters
    complex<float_type> px = (2.*M_PI*pc->nx) / phase (pc->LX*pc->dt,0);
    complex<float_type> py = (2.*M_PI*pc->ny) / (pc->LY*pc->dt);
    complex<float_type> E = sqrt (px*px + py*py + pc->mass*pc->mass);
    complex<float_type> N = 1./sqrt (phase (pc->LX*pc->dt,0) * (pc->LY*pc->dt) * (1.+ (px*px + py*py) / ( (E+pc->mass) * (E+pc->mass))));

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      size_type i = round (xyz (0) /pc->dt);
      ASSERT1 (i < phase_vector.size(), "i="+tostring (i))
      return N*Spinor<complex<float_type>, LS> {{ 1,0,0, (px+I*py) / (E+pc->mass) }}* exp (I* py*xyz (1) + I* px* phase_vector[i]);
    };
  }
  
  else if (config == "plane_wave_ripples_corrected_2D") {
    // Parse variables, strings and functions
    p.register_variable (&pc->nx,        "parameters", "nx", 0);
    p.register_variable (&pc->ny,        "parameters", "ny", 0);
    p.register_variable (&pc->a0,        "parameters", "a0", 0);
    p.register_variable (&pc->k0,        "parameters", "k0", 0);
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    auto f = [=] (float_type x) {
      return 0.5*dh_dx0 ( {{x,0}},0) (2) *dh_dx0 ( {{x,0}},0) (2);
    };

    auto phase_func = [=] (float_type x) -> float_type {
      float_type k = 2*M_PI*pc->k0/ (pc->LX*pc->dt);
      float_type R = sqrt (1.-pc->a0*pc->a0* k* k/2.);
      return 1./ (k*R) *atan (R*tan (k*x));
    };

    // pre-initialize phase expression:
    cout << "Unwrapping phase expression..." << endl;
    float_type k = 2*M_PI*pc->k0/ (pc->LX*pc->dt);
    float_type R = sqrt (1.-pc->a0*pc->a0*k*k/2.);
    vector<float_type> phase_vector0 (pc->LX*pc->refinement_level+1);
    vector<float_type> phase_vector (pc->LX*pc->refinement_level+1);
    phase_vector0[0] = phase_func (0);
    phase_vector[0] = phase_func (0);
    float_type phase_shift = 0;
    for (size_type i=1; i<phase_vector0.size(); i++) {
      float_type x = i*pc->dt/pc->refinement_level;
      phase_vector0[i] = phase_func (x);
      if (phase_vector0[i]-phase_vector0[i-1] > M_PI/ (2*k*R))
        phase_shift -= M_PI/ (k*R);
      if (phase_vector0[i-1]-phase_vector0[i] > M_PI/ (2*k*R))
        phase_shift += M_PI/ (k*R);
      phase_vector[i] = phase_vector0[i] + phase_shift;
    }
    cout << "Done.\n" << endl;

    auto phase = [=] (float_type x) -> float_type {
      // numerically:
      size_type i = round (x/pc->dt);
      ASSERT1 (i < phase_vector.size(), "phase_vector index out of range: i="+tostring (i))
      return phase_vector[i];
    };

    auto shift = [=] (float_type x) -> float_type {
      float_type k = 2*M_PI*pc->k0/ (pc->LX*pc->dt);
      return -0.5*log (1-f (x));
    };

    // wave function parameters
    float_type px = (2.*M_PI*pc->nx) / phase_vector[pc->LX*pc->refinement_level];
    float_type py = (2.*M_PI*pc->ny) / (pc->LY*pc->dt);
    float_type E = sqrt (px*px + py*py + pc->mass*pc->mass);
    float_type N = 1./sqrt ( (pc->LX*pc->dt) * (pc->LY*pc->dt) * (1.+ (px*px + py*py) / ( (E+pc->mass) * (E+pc->mass))));

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      size_type i = round (xyz (0) /pc->dt);
      ASSERT1 (i < phase_vector.size(), "i="+tostring (i))
      return N*Spinor<complex<float_type>, LS> {{ 1,0,0, (px+I*py) / (E+pc->mass) }}* exp (I* py*xyz (1) + I* px*phase (xyz (0)) + shift (xyz (0)));
    };
  }

   else if (config == "plane_wave_ripples_corrected_2D_effective_interactions") {
    // Parse variables, strings and functions
    p.register_variable (&pc->spread,      "parameters", "spread", 14);
    p.register_variable (&pc->x0,          "parameters", "x0", 64);
    p.register_variable (&pc->y0,          "parameters", "y0", 64);     
    p.register_variable (&pc->nx,          "parameters", "nx", 0);
    p.register_variable (&pc->ny,          "parameters", "ny", 0);
    p.register_variable (&pc->a0,          "parameters", "a0", 0);
    p.register_variable (&pc->k0,          "parameters", "k0", 0);
    p.register_variable (&pc->Bz,          "parameters", "Bz", 0);
    p.register_variable (&pc->Ey,          "parameters", "Ey", 0);
    p.register_variable (&pc->c0,          "parameters", "c0", 1);
    p.register_variable (&pc->d0,          "parameters", "d0", 1);
    p.register_variable (&pc->Ef,          "parameters", "Ef", 0);
    p.register_variable (&pc->Emin,        "parameters", "Emin", 0);
    p.register_variable (&pc->xc_kc,       "parameters", "xc_kc", 0);
    p.register_variable (&pc->xc_ksi,      "parameters", "xc_ksi", 0);
    p.register_variable (&pc->xc_rs,       "parameters", "xc_rs", 0);
    p.register_variable (&pc->xc_g,        "parameters", "xc_g", 0);
    p.register_variable (&pc->xc_alpha,    "parameters", "xc_alpha", 0);


    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    float_type B = pc->Bz;
// float_type E = pc->Ey;
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);

    cout << "path: " << pc->path << endl;

    auto f = [=] (float_type x) {
      return 0.5*dh_dx0 ( {{x,0}},0) (2) *dh_dx0 ( {{x,0}},0) (2);
    };

    auto phase_func = [=] (float_type x) -> float_type {
      float_type k = 2*M_PI*pc->k0/ (pc->LX*pc->dt);
      float_type R = sqrt (1.-pc->a0*pc->a0* k* k/2.);
      return 1./ (k*R) *atan (R*tan (k*x));
    };

    // pre-initialize phase expression:
    cout << "Unwrapping phase expression..." << endl;
    float_type k = 2*M_PI*pc->k0/ (pc->LX*pc->dt);
    float_type R = sqrt (1.-pc->a0*pc->a0*k*k/2.);
    vector<float_type> phase_vector0 (pc->LX*pc->refinement_level+1);
    vector<float_type> phase_vector (pc->LX*pc->refinement_level+1);
    phase_vector0[0] = phase_func (0);
    phase_vector[0] = phase_func (0);
    float_type phase_shift = 0;
    for (size_type i=1; i<phase_vector0.size(); i++) {
      float_type x = i*pc->dt/pc->refinement_level;
      phase_vector0[i] = phase_func (x);
      if (phase_vector0[i]-phase_vector0[i-1] > M_PI/ (2*k*R))
        phase_shift -= M_PI/ (k*R);
      if (phase_vector0[i-1]-phase_vector0[i] > M_PI/ (2*k*R))
        phase_shift += M_PI/ (k*R);
      phase_vector[i] = phase_vector0[i] + phase_shift;
    }
    cout << "Done.\n" << endl;

    auto phase = [=] (float_type x) -> float_type {
      // numerically:
      size_type i = round (x/pc->dt);
      ASSERT1 (i < phase_vector.size(), "phase_vector index out of range: i="+tostring (i))
      return phase_vector[i];
    };

    auto shift = [=] (float_type x) -> float_type {
      float_type k = 2*M_PI*pc->k0/ (pc->LX*pc->dt);
      return -0.5*log (1-f (x));
    };

    // wave function parameters
    float_type px = (2.*M_PI*pc->nx) / phase_vector[pc->LX*pc->refinement_level];
    float_type py = (2.*M_PI*pc->ny) / (pc->LY*pc->dt);
    float_type EN = sqrt (px*px + py*py + pc->mass*pc->mass);
    float_type N = 1./sqrt ( (pc->LX*pc->dt) * (pc->LY*pc->dt) * (1.+ (px*px + py*py) / ( (EN+pc->mass) * (EN+pc->mass))));

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      size_type i = round (xyz (0) /pc->dt);
      ASSERT1 (i < phase_vector.size(), "i="+tostring (i))
      return pc->c0*N*Spinor<complex<float_type>, LS> {{ 1,0,0, (px+I*py) / (EN+pc->mass) }}* exp (I* py*xyz (1) + I* px*phase (xyz (0)) + shift (xyz (0)));
    };
  }

  
  
  else if (config == "harmonic_potential_2D") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type beta = 1./ (sqrt (2.) *pc->spread);
    float_type N = beta/sqrt (M_PI*pow (2,pc->nx+pc->ny) *factorial (pc->nx) *factorial (pc->ny));

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      return N * Hermite (beta* (xyz (0)-pc->x0),pc->nx) * Hermite (beta* (xyz (1)-pc->y0),pc->ny) * exp (-beta* beta/2.* ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0))) * Spinor<complex<float_type>, LS> {{1,0,0,0}};
    };
  }
  
  
      else if (config == "Boundary_test") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 0);
    p.register_variable (&pc->c0,          "parameters", "c0", 1);

    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = M_PI*pc->nx/ (pc->LX*pc->dt);
    // @override
//     initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
// //       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
// //      return  {{ 1,1,1,1 }};
//           return  pc->c0*pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0) + ky *  (xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
// 
// };
//   schwradinger electron
//     beta = 1./ (sqrt (2.) *pc->spread);
//     float_type N = beta/sqrt (M_PI*pow (2,pc->nx+pc->ny) *factorial (pc->nx) *factorial (pc->ny));
// 
//     // @override
//     initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       return N * Hermite (beta* (xyz (0)-pc->x0),pc->nx) * Hermite (beta* (xyz (1)-pc->y0),pc->ny) * exp (-beta* beta/2.* ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0))) * Spinor<complex<float_type>, LS> {{1,0,0,0}};
//     };

    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(ky*xyz (1)),0,0,cos(ky*xyz (1))}};
    };


  }
  
    else if (config == "Trasmitance") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters","Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 0);
    p.register_variable (&pc->c0,          "parameters", "c0", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);

    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    std::cout << "kx=" << kx << " ky=" << ky << std::endl;   
    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return  pc->c0*pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0) + ky *  (xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
     //  return   pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0)))*exp(-(xyz (0)-pc->x0)*(xyz (0)-pc->x0)/(4.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};//   
     //  if(xyz (0)<(pc->LX/3*pc->dt)) return  0.0001*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};    
     //  else return Spinor<complex<float_type>, LS> {{ 0,0,0,0 }};    
     //  return 1./sqrt (2*M_PI*pc->spread*pc->spread) *exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
    };
  }
  
      else if (config == "Trasmitance_test") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 0);

    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    std::cout << "kx=" << kx << " ky=" << ky << std::endl;   
    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return  pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0) + ky *  (xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
     //  return   pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0)))*exp(-(xyz (0)-pc->x0)*(xyz (0)-pc->x0)/(4.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};//   
     //  if(xyz (0)<(pc->LX/3*pc->dt)) return  0.0001*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};    
     //  else return Spinor<complex<float_type>, LS> {{ 0,0,0,0 }};    
     //  return 1./sqrt (2*M_PI*pc->spread*pc->spread) *exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
    };
  }
  
    else if (config == "Landau_levels") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);
    p.register_variable (&pc->c0,     "parameters", "c0", 1);
    
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);

    auto phi = [=] (Vector<float_type, D> xyz, size_type nx) -> complex<float_type> {
      //float_type x1 = ky/beta;
      //return beta/sqrt (sqrt (M_PI) *pow (2,nx) *factorial (nx)) * Hermite (beta* (xyz (0)-pc->x0-x1),nx) * exp (-beta* beta/2.* ( (xyz (0)-pc->x0-x1) * (xyz (0)-pc->x0-x1)));

      // mixed initial state
      float_type sigma = 0.5;
      float_type x1 = 0;
      return sigma/sqrt (2*M_PI) * exp (-sigma* sigma/2.* ( (xyz (0)-pc->x0-x1) * (xyz (0)-pc->x0-x1)));
    };

    // @override
    float_type N0 = 1./sqrt (2.*pc->LY*pc->dt);
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      return N0* exp (I* ky*xyz (1)) * Spinor<complex<float_type>, LS> {{pow (I,pc->nx-1)* phi (xyz,pc->nx-1),0,0,pow (I,pc->nx)* phi (xyz,pc->nx) }};
    };
  }
  
  
  else if (config == "Landau_levels_2D") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 0);

    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    std::cout << "kx=" << kx << " ky=" << ky << std::endl;   
    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return  pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0) + ky *  (xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,0 }};
     //  return   pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0)))*exp(-(xyz (0)-pc->x0)*(xyz (0)-pc->x0)/(4.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};//   
     //  if(xyz (0)<(pc->LX/3*pc->dt)) return  0.0001*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};    
     //  else return Spinor<complex<float_type>, LS> {{ 0,0,0,0 }};    
     //  return 1./sqrt (2*M_PI*pc->spread*pc->spread) *exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
    };
  }
    else if (config == "2D_mobius_band_free_particle_2D") {
    // Parse further variables (attention: pointers to previous variables in ParameterCache pc, as stored in the Parser, become invalid here)
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->c0,     "parameters", "c0", 1);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);
    p.parse_variables();

    p.register_string (&writer_type[12], "output", "write_spreads_t", "false");
    p.parse_strings();
    if (cast_string<bool> (writer_type[12]))
      writer_pool.push_back (new Spreads_t_Writer<LT,D0,LS> (pc->x0,pc->y0));

    p.parse_functions();
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    cout << "path: " << pc->path << endl;

     initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return pc->c0/sqrt(2*M_PI*pc->spread*pc->spread)*exp(I* ( kx * (xyz (0)-pc->x0)+ky 
	    *(xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0)+(xyz (1)-pc->y0)* 
	    (xyz (1)-pc->y0)) / (2.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
  }; 
    
    // @override
//     initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       return 1./sqrt (2*M_PI*pc->spread*pc->spread) 
//       *exp(I* ( kx * (xyz (0)-pc->x0)+ky*(xyz (1)-pc->y0) ))
//       *exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,0 }};
//     };
  }
 
    else if (config == "2D_mobius_band_plane_wave") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);
    
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    std::cout << "kx=" << kx << " ky=" << ky << std::endl;   
    // @override
    
//  Trasmitance wavepacket:   
//     initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
// //       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
//      return  pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0) + ky *  (xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
//      //  return   pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0)))*exp(-(xyz (0)-pc->x0)*(xyz (0)-pc->x0)/(4.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};//   
//      //  if(xyz (0)<(pc->LX/3*pc->dt)) return  0.0001*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};    
//      //  else return Spinor<complex<float_type>, LS> {{ 0,0,0,0 }};    
//      //  return 1./sqrt (2*M_PI*pc->spread*pc->spread) *exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
//     }; 
    
//     Harmonic solutions from moebious paper: kf implemenl_implementation
//       initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//      return 1/sqrt(2*M_PI*1)*exp( 2*M_PI*xyz(0)/((pc->LX)*pc->dt)*I*sqrt(pc->nx*pc->nx/(1*1)+ M_PI*M_PI*pc->ny*pc->ny/(1) ) )*Spinor<complex<float_type>, LS> {{ 1,0,0,0 }};
//  }; 
//   JD flat wavefunction solution
     // wave function parameters
    float_type px = (2.*M_PI*pc->nx) / (pc->LX*pc->dt);
    float_type py = (2.*M_PI*pc->ny) / (pc->LY*pc->dt);
    float_type E = sqrt (px*px + py*py + pc->mass*pc->mass);
    cout << "E = " << E << endl;
    float_type N = 1./sqrt ( (pc->LX*pc->dt) * (pc->LY*pc->dt) * (1.+ (px*px + py*py) / ( (E+pc->mass) * (E+pc->mass))));
    cout << "N = " << N << endl;

    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      return N*Spinor<complex<float_type>, LS> {{ 1,0,0, (px+I*py) / (E+pc->mass) }}* exp (I* px* (xyz (0)-pc->x0))* exp (I* py*(xyz (1)-pc->y0));
      //return Spinor<complex<float_type>, LS> {{1,0,0,0}};
    };
 
 
 
}


    else if (config == "2D_mobius_band_gaussian_wavepacket_timedepented") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->c0,     "parameters", "c0", 1);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);


    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "\npath: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    
    std::cout << "\n2D_mobius_band_gaussian_wavepacket with  kx=" << kx << " ky=" << ky << " angle="<<  exp(atan(ky/kx)) <<  std::endl; 

    //Psi defined in parser       
    
// //  Gaussian wavepacket older:   
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return 1/sqrt(2*M_PI*pc->spread*pc->spread)*exp(I* ( kx * (xyz (0)-pc->x0)+ky 
	    *(xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0)+(xyz (1)-pc->y0)* 
	    (xyz (1)-pc->y0)) / (2.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0, 1*exp(atan(ky/kx)) }};
  }; 
    
//     Harmonic solutions:
//       initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//      return 1/sqrt(2*M_PI*1)*exp( 2*M_PI*xyz(0)/((pc->LX)*pc->dt)*I*sqrt(pc->nx*pc->nx/(1*1)+ M_PI*M_PI*pc->ny*pc->ny/(1) ) )*Spinor<complex<float_type>, LS> {{ 1,0,0,0 }};
//  };   0
//      
  }
       else if (config == "2D_mobius_band_with_new_planewave") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);
    p.register_variable (&pc->c0,     "parameters", "c0", 1);

    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;
    
    float_type beta = sqrt (pc->Bz);
    float_type ky = M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = M_PI*pc->nx/ (pc->LX*pc->dt);

    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       Working hole Spin
//      return pc->c0 * Spinor<complex<float_type>, LS> {{0,cos(kx*xyz (0)),I*sin(kx*xyz (0)),0}};
//       Working particle spin
      if (pc->ny >0.0) return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(ky*xyz (1)),0,0,cos(ky*xyz (1))}};
      else if (pc->nx >0.0)return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(kx*xyz (0)),0,0,cos(kx*xyz (0))}};
      else return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(ky*xyz (1)),0,0,cos(ky*xyz (1))}};

    };
// X wave, maybe usefull 
//     initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(ky*xyz (0)),0,0,cos(ky*xyz (0))}};
//     };

  }
    else if (config == "2D_mobius_band_closedboundary_wave") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);
    p.register_variable (&pc->c0,     "parameters", "c0", 1);

    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;
    
    float_type beta = sqrt (pc->Bz);
    float_type ky = M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = M_PI*pc->nx/ (pc->LX*pc->dt);

    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       Working
      if (pc->ny >0.0)return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(ky*xyz (1)),0,0,cos(ky*xyz (1))}};
      if (pc->nx >0.0)return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(kx*xyz (0)),0,0,cos(kx*xyz (0))}};


    };
// X wave, maybe usefull 
//     initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       return pc->c0 * Spinor<complex<float_type>, LS> {{I*sin(ky*xyz (0)),0,0,cos(ky*xyz (0))}};
//     };

  }
    
    
      else if (config == "2D_mobius_band_gaussian_wavepacket") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->c0,     "parameters", "c0", 1);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);


    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "\npath: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    
    std::cout << "\n2D_mobius_band_gaussian_wavepacket with  kx=" << kx << " ky=" << ky << " angle="<<  exp(atan(ky/kx)) <<  std::endl; 

    //Psi defined in parser       
    
// //  Gaussian wavepacket older:   
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return 1/sqrt(2*M_PI*pc->spread*pc->spread)*exp(I* ( kx * (xyz (0)-pc->x0)+ky 
	    *(xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0)+(xyz (1)-pc->y0)* 
	    (xyz (1)-pc->y0)) / (2.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0, 1*exp(atan(ky/kx)) }};
  }; 
    
//     Harmonic solutions:
//       initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//      return 1/sqrt(2*M_PI*1)*exp( 2*M_PI*xyz(0)/((pc->LX)*pc->dt)*I*sqrt(pc->nx*pc->nx/(1*1)+ M_PI*M_PI*pc->ny*pc->ny/(1) ) )*Spinor<complex<float_type>, LS> {{ 1,0,0,0 }};
//  };   0
//      
  }
   else if (config == "2D_mobius_band_1Dgaussian_wavepacket") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->c0,     "parameters", "c0", 1);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.register_variable (&pc->NN,     "parameters", "NN", 1);
    p.register_variable (&pc->w,     "parameters", "w", 1);
    p.register_variable (&pc->r,     "parameters", "r", 1);


    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "\npath: " << pc->path << endl;

    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    
    std::cout << "\n2D_mobius_band_gaussian_wavepacket with  kx=" << kx << " ky=" << ky << " angle="<<  exp(atan(ky/kx)) <<  std::endl; 

    //Psi defined in parser       
    
// //  Gaussian wavepacket older:   
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return 1/sqrt(2*M_PI*pc->spread*pc->spread)*exp(I* ( ky*(xyz (1)-pc->y0) ))*exp (- ((xyz (1)-pc->y0)* (xyz (1)-pc->y0)) / (2.*pc->spread*pc->spread))*Spinor<complex<float_type>, LS> {{ 1,0,0,I}};
  }; 
    
  }
  
  else if (config == "Hall_effect") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ey,     "parameters", "Ey", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;

    float_type B = pc->Bz;
    float_type E = pc->Ey;
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);

    auto phi = [=] (Vector<float_type, D> xyz, size_type ny) -> complex<float_type> {
      float_type W = pow (B*B-E*E,3./4.) /B * sqrt (2*ny) + kx*E/B;
      float_type y1 = (kx*B-W*E) / (B*B-E*E);
      float_type R = pow (B*B-E*E,1./4.) * (xyz (1)-pc->y0+y1);
      return 1./sqrt (sqrt (M_PI) *pow (2,ny) *factorial (ny)) * Hermite (R,ny) * exp (-1./2.*R*R);

      // mixed initial state
      //float_type sigma = 0.5;
      //float_type y1 = 0;
      //return sigma/sqrt(2*M_PI) * exp (-sigma*sigma/2.* ( (xyz (1)-pc->y0-y1) * (xyz (1)-pc->y0-y1)));
    };

    // @override
    float_type N0 = 1./sqrt (2.*pc->LX*pc->dt);
    auto psi_pure = [=] (Vector<float_type, D> xyz, size_type ny) -> Spinor<complex<float_type>, LS> {
      return N0* exp (I* kx*xyz (0)) * Spinor<complex<float_type>, LS> {{pow (I,ny-1)* phi (xyz,ny-1),0,0,pow (I,ny)* phi (xyz,ny) }};
    };



    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
      // pure state:
      // return psi_pure(xyz, pc->ny);
      // mixed state:
      return 2.* (psi_pure (xyz, 1) + 4.*psi_pure (xyz, 2));
    };
  }

    else if (config == "Hall_effect_alternative") {
    p.register_variable (&pc->spread, "parameters", "spread", 14);
    p.register_variable (&pc->x0,     "parameters", "x0", 64);
    p.register_variable (&pc->y0,     "parameters", "y0", 64);
    p.register_variable (&pc->nx,     "parameters", "nx", 0);
    p.register_variable (&pc->ny,     "parameters", "ny", 0);
    p.register_variable (&pc->a0,     "parameters", "a0", 0);
    p.register_variable (&pc->k0,     "parameters", "k0", 0);
    p.register_variable (&pc->Bz,     "parameters", "Bz", 0);
    p.register_variable (&pc->Ex,     "parameters", "Ex", 0);
    p.register_variable (&pc->Ey,     "parameters", "Ey", 0);
    p.register_variable (&pc->Ef,     "parameters", "Ef", 0);
    p.parse_variables();
    p.parse_strings();
    p.parse_functions();

    cout << "path: " << pc->path << endl;
    float_type beta = sqrt (pc->Bz);
    float_type ky = 2*M_PI*pc->ny/ (pc->LY*pc->dt);
    float_type kx = 2*M_PI*pc->nx/ (pc->LX*pc->dt);
    float_type A  = pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread);
    float_type a  = 1/(4.*pc->spread*pc->spread) ;
    float_type klI=-1;
    float_type klF=1;
    std::cout << "kx=" << kx << " ky=" << ky << std::endl;   
    // @override
    initial_psi = [=] (Vector<float_type, D> xyz) -> Spinor<complex<float_type>, LS> {
//       This arrangment is very special for propagation: (not so trivial to have a traveling wavepacket 
     return  pow(2,0.25)/sqrt(4*M_PI*pc->spread*pc->spread)*exp( I* ( kx *  (xyz (0)-pc->x0) + ky *  (xyz (1)-pc->y0) ))*exp (- ( (xyz (0)-pc->x0) * (xyz (0)-pc->x0) + (xyz (1)-pc->y0) * (xyz (1)-pc->y0)) / (4.*pc->spread*pc->spread)) *Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
// //     return 0.5*A*exp( (xyz (0)-pc->x0)*((I)*kx - a*(xyz (0)-pc->x0)))*(erfc((kx - 2.*klI*M_PI + 2.*I*a*(xyz (0)-pc->x0))/(2.*sqrt(a))) - erfc((kx - 2.*klF*M_PI + 2.*I*a*(xyz (0)-pc->x0))/(2.*sqrt(a))))*Spinor<complex<float_type>, LS> {{ 1,0,0,1 }};
    };
  }
  
  
  else error ("ERROR in "+LINE+": Configuration " + config + " unknown.");

  if (D != D_) error ("ERROR in "+LINE+": Lattice does not match with internal template parameter. Please compile again with the right lattice type.");

//================= REFINEMENT ===================
  pc->NX         = pc->LX*pc->refinement_level;
  pc->NY         = pc->LY*pc->refinement_level;
  pc->time_step *= pc->refinement_level;
  pc->T_MAX     *= pc->refinement_level;
  pc->dt        /= pc->refinement_level;
  Lattice<LT>::dt = pc->dt;

  //Initialize folders
  init_folders (pc->path,  p.get_config_filename());

  // Initialize writer
  if (cast_string<bool> (writer_type[0]))
    writer_pool.push_back (new LatticeIndexWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[1]))
    writer_pool.push_back (new CoordinateWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[2]))
    writer_pool.push_back (new MetricWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[3]))
    writer_pool.push_back (new SqrtMetricWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[4]))
    writer_pool.push_back (new ChristoffelWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[5]))
    writer_pool.push_back (new RicciScalarWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[6]))
    writer_pool.push_back (new RhoWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[7]))
    writer_pool.push_back (new CurrentWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[8]))
    writer_pool.push_back (new PsiWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[9]))
    writer_pool.push_back (new PhaseWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[10]))
    writer_pool.push_back (new Norm_t_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[11]))
    writer_pool.push_back (new Current_t_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[12]))
    writer_pool.push_back (new Psi_t_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[13]))
    writer_pool.push_back (new Phase_t_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[14]))
    writer_pool.push_back (new Energy_t_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[15]))
    writer_pool.push_back (new Momentum_t_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[16]))
    writer_pool.push_back (new Energy_Density_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[17]))
    writer_pool.push_back (new Momentum_Density_Writer<LT,D0,LS>());
  if (cast_string<bool> (writer_type[18]))
    writer_pool.push_back (new Spreads_t_Writer<LT,D0,LS> (pc->x0, pc->y0));
  if (cast_string<bool> (writer_type[19]))
    writer_pool.push_back (new EigenfunctionWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[20]))
    writer_pool.push_back (new CoordinateDerWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[21]))
    writer_pool.push_back (new InvMetricWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[22]))
    writer_pool.push_back (new TetradWriter<LT,D0,LS>());
  if (cast_string<bool> (writer_type[23]))
    writer_pool.push_back (new SpinConnectionCoefficientWriter<LT,D0,LS>());

  cout << "\nSimulation parameters:\n" << pc->print() << endl;


  // Construct dh_dx:
  function< Vector<Vector<float_type, D0>, D> (Vector<float_type, D>, float_type) > dh_dx;
  if (dh_dx0 == NULL || dh_dx1 == NULL) dh_dx = NULL;
  else dh_dx = [=] (Vector<float_type, D> xyz, float_type t)->Vector<Vector<float_type, D0>, D> {
    return {{dh_dx0 (xyz,t), dh_dx1 (xyz,t) }};
  };
 
  // Construct g:
  function< Metric<float_type, D> (Vector<float_type, D>, float_type) > g;
  if (g00 == NULL || g01 == NULL || g11 == NULL) g = NULL;
  else g = [=] (Vector<float_type, D> xyz, float_type t)->Metric<float_type, D> {
    return {{
	      g00 (xyz,t), g01 (xyz,t),
	      g01 (xyz,t), g11 (xyz,t) 
    }};
  };
  
  
    // Construct L:
  function< ChristoffelSymbol<float_type, D> (Vector<float_type, D>, float_type) > L;
    if (L000 == NULL || L001 == NULL || L011 == NULL || L100 == NULL || L101 == NULL || L111 == NULL ) L = NULL;
  else L = [=] (Vector<float_type, D> xyz, float_type t)-> ChristoffelSymbol<float_type, D> {
    return {{
      L000 (xyz,t), L001 (xyz,t), 
      L001 (xyz,t), L011 (xyz,t), 
      
      L100 (xyz,t), L101 (xyz,t),
      L101 (xyz,t), L111 (xyz,t) 
    }};
 
  };
   // Construct tetrad:
   function< Matrix<float_type, D> (Vector<float_type, D>, float_type) > tetrad;
   tetrad=NULL;
    
  ConfigDirac<LT, D0, LS> lb (pc,
                              initial_psi,
                              fix_psi,
                              V,
                              A,
                              h,
                              dh_dx,
                              g,
			      L,
			      tetrad,
                              writer_pool
                             );
  lb.run();

  return SUCCESS;
}



