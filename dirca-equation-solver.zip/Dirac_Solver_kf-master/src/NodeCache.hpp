/**
 * \file
 * \author Jens-Daniel Debus,  ETH Zurich
 * \date 2015
 * \brief NodeCache (Node container)
 * \details
 */
#ifndef NODECACHE_HPP
#define NODECACHE_HPP

#include "macros.hpp"
#include "Lattice.hpp"


template<LatticeType LT, size_type D0, size_type LS>
class NodeCache {

public:

     constexpr static size_type D = Lattice<LT>::D;          // Spatial dimension
     constexpr static size_type Q = Lattice<LT>::Q;         // Spatial dimension


     struct Node {

          position_type pos;                                  ///< Lattice position in position_type format

          Spinor<complex<float_type>, LS> psi;                ///< Spinor field,  psi(I) = \f$ \Psi_I \f$
          Spinor<complex<float_type>, LS> psip;
          Spinor<complex<float_type>, LS> psi_temp;           ///< Auxiliary field
          Spinor<bool, LS> psi_fixed;                         ///< Flag defining if the field psi is fixed at this node (e.g. at boundaries) or not

          float_type V;                                       ///< Scalar potential
          Vector<float_type,D> A;                             ///< Vector potential

          LatticeScalar<Node*, Q> nn;                         ///< List of neighbouring nodes

          Vector<float_type, D0> h;                           ///< map of the manifold
          Vector<Vector<float_type, D0>, D> dh_dx;            ///< derivatives of the map, dh_dx(i) = \f$ \frac{d}{dx^i} \vec h \f$, and dh_dx(i)(j) = \f$ \frac{d}{dx^i} h^j \f$
          Metric<float_type, D> g;                            ///< spatial metric tensor, g(i, j) = \f$ g_{ij}\f$,  (x, y, z)=(0, 1, 2)
          Metric<float_type, D> g_inv;                        ///< inverse metric tensor, g_inv(i, j) = \f$ g^{ij} \f$,  (x, y, z)=(0, 1, 2)
          float_type sqrt_g;                                  ///< square root of determinant of the metric, sqrt_g = \f$ \sqrt{\det g} \f$
          ChristoffelSymbol<float_type, D> L;                 ///< Christoffel symbols,  L(i, j, k) = \f$ \Gamma^i_{jk} \f$,  (x, y, z)=(0, 1, 2)

          Matrix<float_type, D> tetrad;                       ///< Tetrad, tetrad(a, i) = \f$ e_a^{\ i} \f$ (\f$ a \f$: spatial Minkowski index,  \f$ i \f$: curved space index)
          Matrix<float_type, D> cotetrad;                     ///< Co-Tetrad, cotetrad(a, i) = \f$ e^a_{\ i} = \eta^{a b} g_{ij} e_b^{\ j} \f$
          Tensor<float_type, D, 3> Omega;                     ///< Omega(a, b, i) = \f$ \Omega^{ab}_i = \frac{1}{2} e^{aj}(\partial_i e^b_{\ j}-\partial_j e^b_{\ i}) \f$
          Vector<Matrix<complex<float_type>, LS>, D> FF;      ///< Forcing term, FF(c)(I,J) = \f$ \mathcal F_{c, IJ} = \frac{\imath}{4} e_c^{\ i} \omega^{ab}_i \sigma_{c, ab, IJ} \f$

          Vector<float_type, D0> laplace_h;                   ///< Laplacian of chart, laplace_h(i) = \f$ \Delta h^i \f$
          Metric<float_type, D>  laplace_g;                   ///< Laplacian of metric, laplace_g(i, j) = \f$ \Delta g_{ij} \f$
          Matrix<float_type, D>  laplace_cotetrad;            ///< Laplacian of cotetrad, laplace_cotetrad(a, i) = \f$ \Delta e^a_{\ i} \f$

          float_type R;                                       ///< Ricci scalar

          Node() {};

          Node ( position_type pos_,
                 Spinor<complex<float_type>, LS> psi_,
                 Spinor<bool, LS> psi_fixed_,
                 float_type V_,
                 Vector<float_type,D> A_
               ) :
               pos ( pos_ ), psi ( psi_ ), psip(psi_), psi_fixed ( psi_fixed_ ), V ( V_ ), A ( A_ ) {};

     };



     struct BoundaryElement {
          size_type nid;
          vector< Vector<size_type, D> > normals;                 // list of normal distances to the boundaries (in different directions)
          vector< std::pair<size_type, size_type> > extrapolation_nodeIDs;        // list of extrapolation node std::pairs (in different directions)

          bool is_extrapolation_boundary;                     ///< whether this boundary element is also an extrapolation boundary element for the wavefunction psi
	  bool is_closed_boundary;
	  
          BoundaryElement ( size_type nid_, vector< Vector<size_type, D> > normals_,  bool is_extrapolation_boundary_ , bool is_closed_boundary_ )
               : nid ( nid_ ), normals ( normals_ ), is_extrapolation_boundary ( is_extrapolation_boundary_ ), is_closed_boundary ( is_closed_boundary_ )
          {}
     };


private:

     vector<Node> nodes_;
     std::unordered_map<position_type, size_type> pos_nodeID_map_;

     // Speed-independent boundary extrapolation scheme for geometrical quantities or other speed-independent quantities
     vector<BoundaryElement> boundary_elements;
     vector<size_type> derivative_bulk_nodeIDs; // nids of the boundary-nodes


public:

     vector<size_type> boundary_index_sectors; // index sectors for parallel boundary update without race conditions,  using extrapolation scheme

     size_type size() {
          return nodes_.size();
     };

     bool is_contained ( const Node n ) const {
          return pos_nodeID_map_.find ( n.pos ) != pos_nodeID_map_.end();
     }

     void insert ( const Node n ) {
          if ( !is_contained ( n ) ) {
               nodes_.push_back ( n );
               pos_nodeID_map_[ n.pos ] = nodes_.size()-1;
          } else error ("ERROR in "+LINE+": Node " + tostring(Lattice<LT>::p_to_ijk(n.pos)) + " is already contained in the NodeCache.");
     };

     Node & operator [] ( const size_type nid ) {
          ASSERT2 ( nid>=0 && nid<nodes_.size() )
          return nodes_[nid];
     };

     const Node & operator [] ( const size_type nid ) const {
          ASSERT2 ( nid>=0 && nid<nodes_.size() )
          return nodes_[nid];
     };

     size_type get_nodeID ( const Node& n ) const {
          auto got = pos_nodeID_map_.find ( n.pos );
          if ( got != pos_nodeID_map_.end() ) return got->second;
          else return -1;
     };

     size_type get_nodeID ( const position_type pos_pt ) const {
          auto got = pos_nodeID_map_.find ( pos_pt );
          if ( got != pos_nodeID_map_.end() ) return got->second;
          else return -1;
     };

     size_type get_nodeID ( const Vector<size_type, D> pos_ijk ) const {
          return get_nodeID ( Lattice<LT>::ijk_to_p ( pos_ijk ) );
     };

     size_type get_nodeID ( const Vector<float_type, D> pos_xyz ) const {
          return get_nodeID ( Lattice<LT>::xyz_to_p ( pos_xyz ) );
     };

     Node & get_node ( const position_type pos_pt ) {
          size_type nid = get_nodeID ( pos_pt );
          ASSERT2 ( nid>=0 && nid<nodes_.size() )
          return nodes_[ nid ];
     };

     Node & get_node ( const Vector<float_type, D> pos_xyz ) {
          return get_node ( Lattice<LT>::xyz_to_p ( pos_xyz ) );
     };

     Vector<float_type, D> get_position_xyz ( const size_type nid ) const  {
          return Lattice<LT>::p_to_xyz ( nodes_[nid].pos );
     }

     Vector<size_type, D> get_position_ijk ( const size_type nid ) const {
          return Lattice<LT>::p_to_ijk ( nodes_[nid].pos );
     }



     // Derivative-boundary nodes:
     Node & get_boundary_node ( const size_type bid ) {
          ASSERT1 ( bid>=0 && bid<no_boundary_nodes() )
          return nodes_[ boundary_elements[bid].nid ];
     }

     BoundaryElement & get_boundary_element ( const size_type bid ) {
          ASSERT1 ( bid>=0 && bid<no_boundary_nodes() )
          return boundary_elements[bid];
     }

     const BoundaryElement & get_boundary_element ( const size_type bid ) const {
          ASSERT1 ( bid>=0 && bid<no_boundary_nodes() )
          return boundary_elements[bid];
     }

     size_type no_boundary_nodes() const {
          return boundary_elements.size();
     }

     size_type get_derivative_boundaryID ( const size_type nid ) const {
          // get corresponding index (bid) in boundary_elements
          for ( size_type bid=0; bid<no_boundary_nodes(); ++bid ) {
               if ( boundary_elements[bid].nid == nid )
                    return bid;
          }
          return -1; // not found
     };

     size_type get_derivative_boundaryID ( const Node& n ) const {
          return get_derivative_boundaryID ( get_nodeID ( n ) );
     };

     bool is_boundary_node ( const size_type nid ) const {
          return get_derivative_boundaryID ( nid ) != -1;
     }

     void set_boundary_node ( const size_type nid, const vector<Vector<size_type, D>>& normals,  const bool is_extrapolation_boundary, const bool is_closed_boundary ) {
          ASSERT1 ( nid>=0 && nid<nodes_.size() )
          // register nid as boundary node, if not registered already
          if ( !is_boundary_node ( nid ) ) {
               BoundaryElement elem ( nid, normals, is_extrapolation_boundary, is_closed_boundary );

               // Initialize extrapolation node IDs:
               Vector<size_type, D> pos  = get_position_ijk ( nid );
               for ( size_type i=0; i<elem.normals.size(); ++i ) {

                    Vector<size_type, D> normal = elem.normals[i];
// 		    DEBUGGING AID:
// 		    std::cout << nid 
// 		    << " i=" << i+1 << "/"<<elem.normals.size()
// 		    <<" normal=" << normal << " pos=" << pos << " pos_shift=" << pos_shift ; //<< std::endl;
                    size_type nid1 = get_nodeID ( Vector<size_type, D> ( pos + 1*normal /*+pos_shift*/) );		    
                    size_type nid2 = get_nodeID ( Vector<size_type, D> ( pos + 2*normal /*+pos_shift*/) );		
// 		    std::cout << " pos nid1= " << get_position_ijk ( nid1 ) << " pos nid2=" << get_position_ijk ( nid2 ) <<std::endl;
		    ASSERT1 ( nid1 != -1 && nid2 != -1 )
                    elem.extrapolation_nodeIDs.push_back ( std::make_pair ( nid1, nid2 ) );
		     
               }

               boundary_elements.push_back ( elem );
          }
     }

//   TODO: maybe use this to adjust boundary derivatives if you want in the future   
//           void set_boundary_node ( const size_type nid, const vector<Vector<size_type, D>>& normals/*, const vector<Vector<size_type, D>>& pos_shifts*/,  const bool is_extrapolation_boundary, const bool is_closed_boundary ) {
//           ASSERT1 ( nid>=0 && nid<nodes_.size() )
//           // register nid as boundary node, if not registered already
//           if ( !is_boundary_node ( nid ) ) {
//                BoundaryElement elem ( nid, normals, is_extrapolation_boundary, is_closed_boundary );
// 
//                // Initialize extrapolation node IDs:
//                Vector<size_type, D> pos  = get_position_ijk ( nid );
//                for ( size_type i=0; i<elem.normals.size(); ++i ) {
// // 		 ====================
// // 		 TODO this is very stupid, find a way to optimize:
// // 		 if norms=2 pos=2 pos = i, if norms=2 pos=1 pos=0
// // 		    size_type j=0;
// // 		    if(pos_shifts.size()==elem.normals.size()) j=i;
// // 		    Vector<size_type, D> pos_shift = pos_shifts[j];
// //=============================================================
//                     Vector<size_type, D> normal = elem.normals[i];
// 
// 
// // 		    DEBUGGING AID:
// // 		    std::cout << nid 
// // 		    << " i=" << i+1 << "/"<<elem.normals.size()
// // 		    <<" normal=" << normal << " pos=" << pos << " pos_shift=" << pos_shift ; //<< std::endl;
//                     size_type nid1 = get_nodeID ( Vector<size_type, D> ( pos + 1*normal /*+pos_shift*/) );		    
//                     size_type nid2 = get_nodeID ( Vector<size_type, D> ( pos + 2*normal /*+pos_shift*/) );		
// // 		    std::cout << " pos nid1= " << get_position_ijk ( nid1 ) << " pos nid2=" << get_position_ijk ( nid2 ) <<std::endl;
// 		    ASSERT1 ( nid1 != -1 && nid2 != -1 )
//                     elem.extrapolation_nodeIDs.push_back ( std::make_pair ( nid1, nid2 ) );
// 		     
//                }
// 
//                boundary_elements.push_back ( elem );
//           }
//      }

     

     void sort_boundary_nodes ( ) {

          // Sort first by number of normals N, then by the accumulated distance sum(d_i) (i=1,...,N runs over all existing normal directions)
          std::sort ( boundary_elements.begin(), boundary_elements.end(),
          [] ( const BoundaryElement& elem1, const BoundaryElement& elem2 ) {
               size_type N1 = elem1.normals.size();
               size_type N2 = elem2.normals.size();

               if ( N1==N2 ) { // if equal number of normals, sort by distance to boundary
                    size_type d1 = 0;
                    for ( size_type i=0; i<N1; ++i )
                         d1 += norm ( elem1.normals[i] );

                    size_type d2 = 0;
                    for ( size_type i=0; i<N2; ++i )
                         d2 += norm ( elem2.normals[i] );

                    return d1>d2;
               } else return N1<N2; // else sort by number of normals
          } );



          // store index borders for parallelization
          size_type no_normals = 0;
          for ( size_type bid = 0; bid < no_boundary_nodes(); ++bid ) {
               size_type N = boundary_elements[bid].normals.size();
               if ( N > no_normals ) {
                    boundary_index_sectors.push_back ( bid );
                    no_normals = N;
               }
          }
          // last index:
          boundary_index_sectors.push_back ( no_boundary_nodes() );




          // check for race conditions
          for ( size_type bid=0; bid<no_boundary_nodes(); bid++ ) {
               const BoundaryElement& elem = boundary_elements[bid];
               for ( size_type i=0; i<elem.extrapolation_nodeIDs.size(); i++ ) {
                    size_type nid1 = elem.extrapolation_nodeIDs[i].first;
                    size_type nid2 = elem.extrapolation_nodeIDs[i].second;
                    Node& n1 = nodes_[nid1];
                    Node& n2 = nodes_[nid2];
// DEBUGGING AID		    
// std::cout <<  Lattice<LT>::p_to_ijk (get_boundary_node(bid).pos) << " i=" << i+1 << "/"<<elem.extrapolation_nodeIDs.size()
// << "   " << no_boundary_nodes() <<"n.pos n1="
// <<  Lattice<LT>::p_to_ijk (n1.pos)<< "n.pos n2=" 
// <<  Lattice<LT>::p_to_ijk (n2.pos)<< " nid1=" << nid1<< " nid2=" << nid2
// << std::endl;
                    size_type bid1 = get_derivative_boundaryID ( get_nodeID ( n1 ) );
                    size_type bid2 = get_derivative_boundaryID ( get_nodeID ( n2 ) );

                    ASSERT1 ( ( bid1 < bid ) && ( bid2 < bid ) )
               }
          }

     }




     // Derivative Bulk nodes:
     Node & get_derivative_bulk_node ( const size_type bid ) {
          ASSERT2 ( bid>=0 && bid<no_derivative_bulk_nodes() )
          return nodes_[ derivative_bulk_nodeIDs[bid] ];
     }

     size_type no_derivative_bulk_nodes() const {
          return derivative_bulk_nodeIDs.size();
     }

     bool is_derivative_bulk_node ( const size_type nid ) const {
          ASSERT2 ( nid>=0 && nid<nodes_.size() )
          return find ( derivative_bulk_nodeIDs.begin(), derivative_bulk_nodeIDs.end(), nid ) != derivative_bulk_nodeIDs.end();
     }

     bool is_derivative_bulk_node ( const Node& n ) const {
          return is_derivative_bulk_node ( get_nodeID ( n ) );
     }

     void init_derivative_bulk_nodes() {
          // for all nodes...
          for ( size_type nid = 0; nid < size(); ++nid ) {
               if ( !is_boundary_node ( nid ) )
                    derivative_bulk_nodeIDs.push_back ( nid );
          }

          // Check
          for ( size_type nid=0; nid<size(); nid++ ) {
               ASSERT1 ( is_boundary_node ( nid ) ^ is_derivative_bulk_node ( nid ) )
          }
     }
};


#endif //define NODECACHE_HPP







