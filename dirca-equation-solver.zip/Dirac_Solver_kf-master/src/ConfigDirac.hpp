/**
 * \file
 * \author Jens-Daniel Debus,  ETH Zurich
 * \date 2015
 * \brief Specific Configuration file for rectangular setup
 * \details
 */

#ifndef CONFIG_DIRAC_HPP
# define CONFIG_DIRAC_HPP

# include "macros.hpp"
# include "LB.hpp"

template<LatticeType LT, size_type D0 = Lattice<LT>::D, size_type LS=4>
class ConfigDirac : public LB<LT, D0, LS> {

public:

  using LB<LT,D0,LS>::nodes;
  using LB<LT,D0,LS>::D;
  using typename LB<LT,D0,LS>::Node;

  // Constructor
  ConfigDirac (ParameterCache* p,

    function<Spinor<complex<float_type>, LS> (Vector<float_type, D>) > initial_psi_, // remove to the float type t go back
    function<Spinor<bool, LS> (Vector<float_type, D>) > fix_psi_,

    function<float_type (Vector<float_type, D> xyz, float_type t) > V_,
    function<Vector<float_type, D> (Vector<float_type, D> xyz, float_type t) > A_,

    function<Vector<float_type, D0> (Vector<float_type, D> xyz, float_type t) > h_,
    function< Vector<Vector<float_type, D0>, D> (Vector<float_type, D>, float_type) > dh_dx_,
    function< Metric<float_type, D> (Vector<float_type, D>, float_type) > g_,
    function< ChristoffelSymbol<float_type, D> (Vector<float_type, D>, float_type) > L_,
    function< Matrix<float_type, D> (Vector<float_type, D>, float_type) > tetrad_,

    vector<Writer<LT,D0,LS>*> w_
   ) {


     ASSERT1 (p->dt == Lattice<LT>::dt)

     // Fill NodeCache with nodes:
     for (size_type y=0; y<p->NY; ++y) for (size_type x=0; x<p->NX; ++x) {

       Vector<float_type, D> xyz = {{p->dt*x, p->dt*y}};
       position_type pos_ = Lattice<LT>::xyz_to_p (xyz);

       nodes.insert (Node (pos_,
	 initial_psi_ (xyz),
	 fix_psi_ (xyz) ,
	 V_ (xyz,0),
	 A_ (xyz,0)
	));
      }





     // Initialize from file:
     if (p->initial_state_path != "NONE") {
       vector<vector<Spinor<complex<float_type>,LS>>> psi_eigen;
       for (size_type ny=0; ny<=6; ny++) {
	 vector<Spinor<complex<float_type>,LS>> psi_eigen_n;

	 cout <<  "Initializing from eigenfunction state file: " << (p->initial_state_path+"/eigenfunction_"+std::to_string (ny) +".lb") << endl;
	 fileinstream ifile ( (p->initial_state_path+"/eigenfunction_"+std::to_string (ny) +".lb").c_str(), std::ios::binary);
	 if (ifile.good()) {

    for (size_type nid=0; nid<nodes.size(); nid++) {
      Spinor<complex<float_type>,LS> psi_temp;
      for (size_type J=0; J<LS; J++) {
	float_type re, im;
	ifile >> re;
	ifile >> im;
	psi_temp(J) = re + I*im;
       }
      psi_eigen_n.push_back (psi_temp);
     }
    ifile.close();
   }
	 else {
    ifile.close();
    error ("ERROR in "+LINE+": Could not load initial state file: " + (p->initial_state_path+"/eigenfunction_"+std::to_string (ny) +".lb"));
   }

	 psi_eigen.push_back (psi_eigen_n);
	}
       cout << "Done." <<  endl;


       // PREPROCESSING....


       for (size_type nid=0; nid<nodes.size(); nid++) {
	 auto& n = nodes[nid];
	 n.psi = 1.5*psi_eigen[1][nid] 
	 + 0.0032/0.0033*psi_eigen[2][nid] 
	 + 0.0032/0.000822*psi_eigen[3][nid]
	 + 1.6*0.0032/0.0023*psi_eigen[4][nid];                
	 n.psip = n.psi;
	}
      }



     //======================= Link neighbours ========================================
     cout << " Linking Neighbours..." << endl;


     for (size_type nid=0; nid<nodes.size(); nid++) {

       //         if (nid%int (nodes.size() /100.+1) ==0) cout << "\r\t" << (100*nid) /nodes.size() <<  " \%" << flush;

       // get node positions:
       Vector<float_type, D> pos_xyz = Lattice<LT>::p_to_xyz (nodes[nid].pos);
       Vector< size_type, D> pos_ijk = Lattice<LT>::xyz_to_ijk (pos_xyz);

       // auxiliary variables for extrapolation boundaries
       bool is_derivative_boundary = false;
       bool is_extrapolation_boundary = false;
       bool is_closed_boundary= false;
       vector<Vector<size_type, D>> derivative_normals;
       

       for (size_type l=0; l<Lattice<LT>::Q; l++) {        // ordered by norm of velocity vectors
	 bool MOEBIUS_contional=false;
	 //real position of previous nodes (from which the velocity vectors point to this node)
	 Vector<float_type, D>next_xyz (pos_xyz - p->dt * Lattice<LT>::c (l));
	 Vector<size_type, D> next_ijk (Lattice<LT>::xyz_to_ijk (next_xyz));
	 // 	  Vector<float_type, D>next_xyz_inv (pos_xyz - p->dt * Lattice<LT>::c (Lattice<LT>::l_inv (l)));	  
	 //        Vector<size_type, D>next_ijk_inv (Lattice<LT>::xyz_to_ijk (next_xyz_inv));

	 // =========  boundaries (in ascending priority for extrapolation) =====================
	 if (next_ijk (0) < 0) {
    // Derivative boundaries
    Vector<size_type, D> normal = (pos_ijk (0) +1) *Vector<size_type, D> {{1, 0}};
// BD   Vector<size_type, D> pos_shift = {{0,0}};
    is_derivative_boundary = true;
    // Wave function boundaries:
    switch (p->boundary_type) {
      case EXTRAPOLATION:
      next_ijk = pos_ijk;                         // place holder
      is_extrapolation_boundary = true;
	break;
      case PERIODIC:
      next_ijk (0) = MOD (next_ijk (0), p->NX);
	break;
      case MOEBIUS:
      next_ijk (0) = MOD (next_ijk (0), p->NX); 
      MOEBIUS_contional=true;
	break;
      case MOEBIUS_PERIODIC:
      next_ijk (0) = MOD (next_ijk (0), p->NX); 
      MOEBIUS_contional=true;
	break;
      case RING:
      next_ijk (0) = MOD (next_ijk (0), p->NX);
	break;
      case CLOSED:
      next_ijk = pos_ijk;                         // place holder
      is_closed_boundary = true;
	break;
     }
// BD     insert_uniquely (pos_shifts, pos_shift);
     insert_uniquely (derivative_normals, normal);

   //                std::cout<< "l="<< l << "nid" << nid << " "  << normal << "A POSIJK=" << pos_ijk<< " next_ijk="<< next_ijk<<std::endl;	    
   }

	 if (p->boundary_type==MOEBIUS && p->NN>1){ 
    for( size_type i=1; i<p->NN; ++i){
      if (next_ijk (0)  >= (size_type)round(i*(p->NX-1)/(size_type)p->NN)) {
  
    MOEBIUS_contional=true;

//       std::cout<< "l="<< l << " nid " << nid << " "  << pos_ijk<< " before next_ijk="<< next_ijk <<  "after " <<  (p->NY-1) - next_ijk (1) <<  std::endl;	    

//       Observations for this here:
//       1. exactly the same with pos_ijk doesnot create the same effect
//  	 2. if you move forward the other boundaries work ok
//  	 3. if you move backwards {1, 0, 0, -1} then you loose one boundarie as you find yourself in "the other state"
// 	 4. The wavepacket stays "up" as long as the above condition is true,  other wise it 'falls' down perfectly
// 	 *. use nx=60,  ny=0,  x0=0.3,  y0=0.15,  spread=4 (and flat geometry for speed
       }
     }
   }
	 if (next_ijk (0) > p->NX-1) {
    Vector<size_type, D> normal = - (p->NX-pos_ijk (0)) *Vector<size_type, D> {{1, 0}};
//     Vector<size_type, D> pos_shift = {{0,0}};
    is_derivative_boundary = true;
    // Wave function boundaries:
    switch (p->boundary_type) {
      case EXTRAPOLATION:
      next_ijk = pos_ijk;                         // place holder
      is_extrapolation_boundary = true;
	break;
      case PERIODIC:
      next_ijk (0) = MOD (next_ijk (0), p->NX);
	break;
      case MOEBIUS:
      next_ijk(0) = MOD (next_ijk (0), p->NX);
      MOEBIUS_contional=true;
	break;
      case MOEBIUS_PERIODIC:
      next_ijk(0) = MOD (next_ijk (0), p->NX);
      MOEBIUS_contional=true;
	break;
      case RING:
      next_ijk (0) = MOD (next_ijk (0), p->NX);
	break;
      case CLOSED:
      next_ijk = pos_ijk;                         // place holder
      is_closed_boundary = true;
	break;		
     }
//      insert_uniquely (pos_shifts, pos_shift);
     insert_uniquely (derivative_normals, normal);

   }

	 if (next_ijk (1) < 0 ) {  
	   
    Vector<size_type, D> normal = (pos_ijk (1) +1) *Vector<size_type, D> {{0, 1}};
    is_derivative_boundary = true;

    // Wave function boundaries:
    switch (p->boundary_type) {
      case EXTRAPOLATION:
      next_ijk = pos_ijk;                         // place holder
      is_extrapolation_boundary = true;
	break;
      case PERIODIC:
      next_ijk (1) = MOD (next_ijk (1), p->NY);
	break;
      case MOEBIUS:
      next_ijk = pos_ijk;                                       // place holder
      is_closed_boundary = true;
	break;
      case MOEBIUS_PERIODIC:
      next_ijk (1) = MOD (next_ijk (1), p->NY);
	break;
      case RING:
      next_ijk = pos_ijk;                         // place holder
      is_closed_boundary = true;
	break;
      case CLOSED:
      next_ijk = pos_ijk;    // place holder
      is_closed_boundary = true;
	break;		
     }
//      insert_uniquely (pos_shifts, pos_shift);
     insert_uniquely (derivative_normals, normal);


   }
	 if (next_ijk (1) > p->NY-1 ) { 
    Vector<size_type, D> normal = - (p->NY-pos_ijk (1)) *Vector<size_type, D> {{0, 1}};
    Vector<size_type, D> pos_shift = {{0,0}};    
    is_derivative_boundary = true;
    // Wave function boundaries:
    switch (p->boundary_type) {
      case EXTRAPOLATION:
      next_ijk = pos_ijk;                         // place holder
      is_extrapolation_boundary = true;
	break;
      case PERIODIC:
      next_ijk (1) = MOD (next_ijk (1), p->NY);
	break;
      case MOEBIUS:
      next_ijk = pos_ijk;                                       // place holder
      is_closed_boundary = true;
	break;
      case MOEBIUS_PERIODIC:
      next_ijk (1) = MOD (next_ijk (1), p->NY);
	break;
      case RING:
      next_ijk = pos_ijk;                         // place holder
      is_closed_boundary = true;
	break;	    
      case CLOSED:
      next_ijk = pos_ijk;                         // place holder
      is_closed_boundary = true;
	break;
     }
//      insert_uniquely (pos_shifts, pos_shift);
     insert_uniquely (derivative_normals, normal);

   }
   
//        kf to avoid misplacing of normals for MOEBIUS      
//        kf the following mirrors the wavevectors alond the x-axis both in position and direction! 	 	  	     
	 if(MOEBIUS_contional) {
//     std::cout << "l="<< l<< " *****before_M=" << next_ijk <<std::endl;
    next_ijk(1) = (p->NY-1) - next_ijk (1);   
// 	  	     std::cout << "l="<< l<< " *****AFter_M=" << next_ijk <<std::endl;
  }
	 //link that node to this node
	 //kf nn has nodes and Q dim maybe here we get debugger error
	 nodes[nid].nn (l) = & (nodes.get_node (Lattice<LT>::ijk_to_p (next_ijk)));
	}
       // after all speeds have been checked:
       if (is_derivative_boundary) nodes.set_boundary_node (nid, derivative_normals, is_extrapolation_boundary, is_closed_boundary);
      }

     cout << "\r\t100 \%" << endl;
     cout << "  Done." << endl;

     //=================== ==================================================================

     cout << " Sorting boundary nodes..." << endl;
     nodes.sort_boundary_nodes();
     nodes.init_derivative_bulk_nodes();
     cout << "  Done." << endl;



     // Initialize LB Core:
     LB<LT,D0,LS>::init_LB (p,
     h_, dh_dx_, g_, L_, tetrad_,
     V_, A_,
     w_
    );
    }


 };
#endif                                                      //define CONFIG_DIRAC_HPP

