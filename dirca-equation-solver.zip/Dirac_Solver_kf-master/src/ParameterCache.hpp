//Copyright (c) 2016 Jens-Daniel Debus, ETH Zurich
#ifndef PARAMETERCACHE_HPP
#define PARAMETERCACHE_HPP

#include "macros.hpp"


//==================== BASE PARAMETER CLASS ===============================
class ParameterCache {
  public:
    TimeFlag geometry_type;
    TimeFlag potential_type;
    PotentialImplementation potential_implementation;
    BoundaryType boundary_type;
    HamiltonianType hamiltonian_type;
    // Path to output folders
    string path;
    string initial_state_path;
    
    // Simulation time
    sim_time_type time_step;
    sim_time_type T_MAX;
    float_type dt;

    // Dimensions and resolution
    size_type LX;
    size_type LY;
    size_type NX;
    size_type NY;
    size_type refinement_level;

    // Simulation parameters
    float_type mass;
    
    //=====================================    
    float_type spread;  // spread of wave package
    float_type x0,y0;   // center of perturbation
    float_type a0,r0;   // perturbation amplitude, range // radious of mobius
    float_type c0;      // psi^2 potential coupling
    float_type d0;      // non integer momentum multiplier
    float_type Bz;      // magnetic field
    float_type Ex, Ey;  // electric field
    float_type Ef, Emin;// Fermi energy, min energy if required.
    size_type nx,ny;    // quantum numbers
    size_type k0;       // ripple mode
    float_type NN;      // wringle mode // number of twists
    float_type w; 	// width of mobius
    float_type r; 	// r of mobius

    //=====================================
    
    //Exchange correlation potential
    float_type xc_kc;
    float_type xc_ksi;
    float_type xc_rs;
    float_type xc_g;
    float_type xc_alpha;  // alpha structure constant 

    
    // Parameter string
    virtual string print() const {
      std::stringstream parameters;
      parameters
          << " 1. " << "NX               = " << NX               << "\n"
          << " 2. " << "NY               = " << NY               << "\n"
          << " 3. " << "refinement_level = " << refinement_level << "\n"
          << " 4. " << "dt               = " << dt               << "\n"
          << " 5. " << "timestep         = " << time_step        << "\n"
          << " 6. " << "T_MAX            = " << T_MAX            << "\n"
          << " 7. " << "D0               = " << spread           << "\n \n"
          << " 8. " << "mass             = " << mass             << "\n"
          << " 9. " << "x0               = " << x0               << "\n"
          << "10. " << "y0               = " << y0               << "\n"
          << "11. " << "nx               = " << nx               << "\n"
          << "12. " << "ny               = " << ny               << "\n"
          << "13. " << "a0               = " << a0               << "\n"
          << "14. " << "r0               = " << r0               << "\n"
          << "15. " << "k0               = " << k0               << "\n"
          << "16. " << "Bz               = " << Bz               << "\n"
          << "17. " << "Ex               = " << Ex               << "\n"
          << "18. " << "Ey               = " << Ey               << "\n \n"
          << "19. " << "Ef               = " << Ef               << "\n"
	  << "20. " << "Emin             = " << Emin             << "\n \n"
	  << "21. " << "kc or k1         = " << xc_kc            << "\n"
	  << "22. " << "c0 or k0 or mobius radious         = " << c0               << "\n"
	  << "23. " << "g or epsilon_g or mobius width  = " << xc_g             << "\n"
	  << "24. " << "alpha            = " << xc_alpha         << "\n"
	  << "25. " << "NN, moebius twists or wringle mode  = " << NN         << "\n"

	  ;
      return parameters.str();
    }
};



//================ SPECIALIZED PARAMETER CLASS ==========================
class FreeParticleParameterCache : public ParameterCache {
  public:
    FreeParticleParameterCache(){}
    FreeParticleParameterCache (ParameterCache const& pc) : ParameterCache (pc) {}

    string print() const override {
      std::stringstream parameters;
      parameters
          << " 8. " << "D0               = "  << spread << "\n"
          << " 9. " << "x0               = "  << x0     << "\n"
          << "10. " << "y0               = "  << y0     << "\n";
      return ParameterCache::print() + parameters.str();
    }
};


//================ SPECIALIZED PARAMETER CLASS ==========================
class HarmonicPotentialParameterCache : public ParameterCache {
  public:    
    HarmonicPotentialParameterCache(){}
    HarmonicPotentialParameterCache (ParameterCache const& pc) : ParameterCache (pc) {}

    string print() const override {
      std::stringstream parameters;
      parameters
          << " 8. " << "D0                = "  << spread << "\n"
          << " 9. " << "x0                = "  << x0     << "\n"
          << "10. " << "y0                = "  << y0     << "\n"
          << "11. " << "nx                = "  << nx     << "\n"
          << "12. " << "ny                = "  << ny     << "\n";
      return ParameterCache::print() + parameters.str();
    }
};


//================ SPECIALIZED PARAMETER CLASS ==========================
class PlaneWaveParameterCache : public ParameterCache {
  public:    
    PlaneWaveParameterCache(){}
    PlaneWaveParameterCache (ParameterCache const& pc) : ParameterCache (pc) {}

    string print() const override {
      std::stringstream parameters;
      parameters
          << " 8. " << "nx                = "  << nx << "\n"
          << " 9. " << "ny                = "  << ny << "\n"
          << "10. " << "a0                = "  << a0 << "\n"
          << "11. " << "r0                = "  << r0 << "\n";
      return ParameterCache::print() + parameters.str();
    }
};



class PlaneWaveRipplesParameterCache : public ParameterCache {
  public:    
    PlaneWaveRipplesParameterCache(){}
    PlaneWaveRipplesParameterCache (ParameterCache const& pc) : ParameterCache (pc) {}

    string print() const override {
      std::stringstream parameters;
      parameters
          << " 8. " << "nx                = "  << nx << "\n"
          << " 9. " << "ny                = "  << ny << "\n"
          << "10. " << "a0                = "  << a0 << "\n"
          << "11. " << "k0                = "  << k0 << "\n";
      return ParameterCache::print() + parameters.str();
    }
};

#endif // !defined PARAMETERCACHE_HPP
