//Copyright (c) 2016 Jens-Daniel Debus, ETH Zurich
#ifndef WRITER_HPP
#define WRITER_HPP

#include "macros.hpp"
#include "ParameterCache.hpp"
#include "CliffordAlgebra.hpp"
#include <fftw3.h>

#define REAL 0
#define IMAG 1

// forward-declaration of pointer-types
template<LatticeType LT, size_type D0, size_type LS>
class LB;
template<LatticeType LT, size_type D0, size_type LS>
class NodeCache;




//==================== OBSERVABLE CACHE ===============================
template<LatticeType LT, size_type D0, size_type LS>
class ObservableCache {
  private:

  public:
    NodeCache<LT,D0,LS>* nc;
    ParameterCache* p;
    constexpr static size_type D = Lattice<LT>::D; // Spatial dimension

    typedef typename NodeCache<LT,D0,LS>::Node Node;

    bool geometry_is_dynamic;
    vector<Vector<float_type, D>> xyz;
    vector<Spinor<complex<float_type>, LS>> psi, psip;
    vector<Vector<float_type, D0>> h;
    vector<Vector<Vector<float_type, D0>, D>> dh_dx;
    vector<Metric<float_type, D>> g;
    vector<Metric<float_type, D>> g_inv;
    vector<ChristoffelSymbol<float_type, D>> L;
    vector<float_type> R;
    vector<Matrix<float_type, D>> tetrad;
    vector<Tensor<float_type, D, 3>> Omega;
    
    vector<vector<Spinor<complex<float_type>,LS>>> psi_t;

    ObservableCache() {}
    ObservableCache (NodeCache<LT,D0,LS>* nc_, ParameterCache* p_, TimeFlag geometry_type_)
      : nc (nc_), p (p_), geometry_is_dynamic (geometry_type_==DYNAMIC) {
      for (size_type nid=0; nid<nc->size(); nid++) {
        const Node& n = nc->operator[] (nid);
        xyz.push_back (Lattice<LT>::p_to_xyz (n.pos));
        psi.push_back (n.psi);
        psip.push_back (n.psip);
        h.push_back (n.h);
        dh_dx.push_back (n.dh_dx);
        g.push_back (n.g);
	g_inv.push_back (n.g_inv);
        L.push_back (n.L);
        R.push_back (n.R);
        tetrad.push_back (n.tetrad);
	Omega.push_back (n.Omega);
      }
      psi_t.push_back (psi);
    }

    void update() {
#if LB_OMP
      #pragma omp parallel for
#endif
      for (size_type nid=0; nid<nc->size(); nid++) {
        const Node& n = nc->operator[] (nid);
        psi[nid] = n.psi;
        psip[nid] = n.psip;
      }
      psi_t.push_back (psi);

      if (geometry_is_dynamic) {
#if LB_OMP
        #pragma omp parallel for
#endif
        for (size_type nid=0; nid<nc->size(); nid++) {
          const Node& n = nc->operator[] (nid);
          h[nid] = n.h;
          dh_dx[nid] = n.dh_dx;
          g[nid] = n.g;
	  g_inv[nid] = n.g_inv;
          L[nid] = n.L;
          R[nid] = n.R;
          tetrad[nid] = n.tetrad;
          Omega[nid] = n.Omega;	  
        }
      }
    }


    void filter_psi_t() {

      cout << "Filtering psi (low pass)..." << endl;

      // Filter
      size_type N = psi_t.size();
      float_type Tmax = N* p->time_step* p->dt;

      fftw_complex signal[LS][N];
      fftw_complex result[N];
      fftw_complex in[N];
      fftw_plan forward_plan;
      fftw_plan backward_plan;


// ==================== EIGENFUNCTION FILTER ===================
//       // eigenfunction index
//       size_type ny = 3;
//
//       for (size_type nid=0; nid<nc->size(); nid++) {
//         for (int J = 0; J < LS; ++J) {
//
// #if LB_OMP
//           #pragma omp parallel for
// #endif
//           for (int i = 0; i < N; ++i) {
//             signal[J][i][REAL] = psi_t[i][nid][J].real();
//             signal[J][i][IMAG] = psi_t[i][nid][J].imag();
//           }
//           forward_plan = fftw_plan_dft_1d (N, signal[J], result, FFTW_FORWARD, FFTW_ESTIMATE);
//           fftw_execute (forward_plan);
//
//           // select n-th eigenfunction
//           float_type B = p->Bz;
//           float_type E = p->Ey;
//           float_type kx = 2*M_PI*p->nx/ (p->LX*p->dt);
//           float_type gamma = sqrt (1.- (E*E) / (B*B));
//           float_type f_high = 1./ (2.*M_PI) * (gamma*sqrt (gamma*2*B* (ny+.5)) +kx*E/B);
//           float_type f_low  = 1./ (2.*M_PI) * (gamma*sqrt (gamma*2*B* (ny-.5)) +kx*E/B);
//
// #if LB_OMP
//           #pragma omp parallel for
// #endif
//           for (int i = 0; i < N; ++i) {
//             float_type f = i/Tmax;
//             in[i][REAL] = result[i][REAL] * ( (f>f_low) && (f<f_high));
//             in[i][IMAG] = result[i][IMAG] * ( (f>f_low) && (f<f_high));
//           }
//
//           backward_plan = fftw_plan_dft_1d (N, in, signal[J], FFTW_BACKWARD, FFTW_ESTIMATE);
//           fftw_execute (backward_plan);
//
// #if LB_OMP
//           #pragma omp parallel for
// #endif
//           for (int i = 0; i < N; ++i) {
//             psi_t[i][nid][J] = signal[J][i][REAL]/N + I* (signal[J][i][IMAG]/N);
//           }
//         }
//       }
//
// #if LB_OMP
//       #pragma omp parallel for
// #endif
//       for (int i = 0; i < N; ++i) {
//         // Normalize eigenfunction psi:
//         float_type norm_psi = 0;
//         for (size_type nid=0; nid<nc->size(); nid++) {
//           norm_psi += norm2 (psi_t[i][nid]) *sqrt (det (g[nid])) *p->dt*p->dt;
//         }
//         for (size_type nid=0; nid<nc->size(); nid++) {
//           psi_t[i][nid] /= sqrt (norm_psi);
//         }
//       }



// ==================== LOW PASS FILTER ===============================
      for (size_type nid=0; nid<nc->size(); nid++) {
        for (int J = 0; J < LS; ++J) {

#if LB_OMP
          #pragma omp parallel for
#endif
          for (int i = 0; i < N; ++i) {
            signal[J][i][REAL] = psi_t[i][nid][J].real();
            signal[J][i][IMAG] = psi_t[i][nid][J].imag();
          }
          forward_plan = fftw_plan_dft_1d (N, signal[J], result, FFTW_FORWARD, FFTW_ESTIMATE);
          fftw_execute (forward_plan);

          float_type f_Fermi = 1./ (2.*M_PI) * p->Ef;

#if LB_OMP
          #pragma omp parallel for
#endif
          for (int i = 0; i < N; ++i) {
            float_type f = i/Tmax;
            in[i][REAL] = result[i][REAL] * (f<f_Fermi);
            in[i][IMAG] = result[i][IMAG] * (f<f_Fermi);
          }

          backward_plan = fftw_plan_dft_1d (N, in, signal[J], FFTW_BACKWARD, FFTW_ESTIMATE);
          fftw_execute (backward_plan);

#if LB_OMP
          #pragma omp parallel for
#endif
          for (int i = 0; i < N; ++i) {
            psi_t[i][nid][J] = signal[J][i][REAL]/N + I* (signal[J][i][IMAG]/N);
          }
        }
      }
// ================================================================

      fftw_destroy_plan (forward_plan);
      fftw_destroy_plan (backward_plan);
    }
    
     void filter_psi_range() {

      cout << "Filtering psi (low and high pass)..." << endl;

      // Filter
      size_type N = psi_t.size();
      float_type Tmax = N* p->time_step* p->dt;

      fftw_complex signal[LS][N];
      fftw_complex result[N];
      fftw_complex in[N];
      fftw_plan forward_plan;
      fftw_plan backward_plan;


// ==================== LOW PASS FILTER ===============================
      for (size_type nid=0; nid<nc->size(); nid++) {
        for (int J = 0; J < LS; ++J) {

#if LB_OMP
          #pragma omp parallel for
#endif
          for (int i = 0; i < N; ++i) {
            signal[J][i][REAL] = psi_t[i][nid][J].real();
            signal[J][i][IMAG] = psi_t[i][nid][J].imag();
          }
          forward_plan = fftw_plan_dft_1d (N, signal[J], result, FFTW_FORWARD, FFTW_ESTIMATE);
          fftw_execute (forward_plan);

          float_type f_Fermi = 1./ (2.*M_PI) * p->Ef;
	  float_type f_min   = 1./ (2.*M_PI) * p->Emin; 

#if LB_OMP
          #pragma omp parallel for
#endif
          for (int i = 0; i < N; ++i) {
            float_type f = i/Tmax;
            in[i][REAL] = result[i][REAL] * (f<f_Fermi && (f>f_min));
            in[i][IMAG] = result[i][IMAG] * (f<f_Fermi && (f>f_min));
          }

          backward_plan = fftw_plan_dft_1d (N, in, signal[J], FFTW_BACKWARD, FFTW_ESTIMATE);
          fftw_execute (backward_plan);
          psi[nid][J]=signal[J][0][REAL]/N + I* (signal[J][0][IMAG]/N);
#if LB_OMP
          #pragma omp parallel for
#endif      
          for (int i = 0; i < N; ++i) {
            psi_t[i][nid][J] = signal[J][i][REAL]/N + I* (signal[J][i][IMAG]/N);
          }
        }
      }
// ================================================================

      fftw_destroy_plan (forward_plan);
      fftw_destroy_plan (backward_plan);
    }
    
    
};





//==================== ABSTRACT WRITER CLASS ===============================
template<LatticeType LT, size_type D0, size_type LS>
class Writer {

  public:
    ObservableCache<LT,D0,LS>* o;
    ParameterCache* p;

    constexpr static size_type D = Lattice<LT>::D; // Spatial dimension

    // virtual functions with standard implementations
    virtual void update() {};
    virtual void write (sim_time_type t) const {};
    virtual void write_at_end (sim_time_type t) const {
      write (t);
    };
};


//======================= WRITER IMPLEMENTATIONS ================================
template<LatticeType LT, size_type D0, size_type LS>
class LatticeIndexWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0) return; // only write once

      cout << "Writing (x_0,x_1,x_2) ... " << endl;

      std::stringstream s;
      s << p->path << "/data/pos" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->xyz.size(); nid++) {
        const auto& xyz = o->xyz[nid];
        for (size_type i=0; i<xyz.size(); i++)
          str << xyz (i) << "\t";
        str << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class EigenfunctionWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write_at_end (sim_time_type t) const override {
      cout <<  "\033[33mWriting eigenfunction state file... \033[0m" <<  endl;

      // Filter
      const auto& psi_t = o->psi_t;
      size_type N = psi_t.size();
      float_type Tmax = N* p->time_step* p->dt;

      fftw_complex signal[LS][N];
      fftw_complex result[N];
      fftw_complex in[N];
      fftw_plan forward_plan;
      fftw_plan backward_plan;

      // eigenfunction index
      for (size_type ny=0; ny<=6; ny++) {

        vector<Spinor<complex<float_type>,LS>> psi_eigen;
        for (size_type nid=0; nid<o->nc->size(); nid++) {
          Spinor<complex<float_type>,LS> psi_nid;
          for (int J = 0; J < LS; ++J) {

#if LB_OMP
            #pragma omp parallel for
#endif
            for (int i = 0; i < N; ++i) {
              signal[J][i][REAL] = o->psi_t[i][nid][J].real();
              signal[J][i][IMAG] = o->psi_t[i][nid][J].imag();
            }
            forward_plan = fftw_plan_dft_1d (N, signal[J], result, FFTW_FORWARD, FFTW_ESTIMATE);
            fftw_execute (forward_plan);

            // select n-th eigenfunction
            float_type B = p->Bz;
            float_type E = p->Ey;
            float_type kx = 2*M_PI*p->nx/ (p->LX*p->dt);
            float_type gamma = sqrt (1.- (E*E) / (B*B));
            float_type f_high = 1./ (2.*M_PI) * (gamma*sqrt (gamma*2*B* (ny+.5)) +kx*E/B);
            float_type f_low  = 1./ (2.*M_PI) * (gamma*sqrt (gamma*2*B* (ny-.5)) +kx*E/B);

#if LB_OMP
            #pragma omp parallel for
#endif
            for (int i = 0; i < N; ++i) {
              float_type f = i/Tmax;
              in[i][REAL] = result[i][REAL] * ( (f>f_low) && (f<f_high));
              in[i][IMAG] = result[i][IMAG] * ( (f>f_low) && (f<f_high));
            }

            backward_plan = fftw_plan_dft_1d (N, in, signal[J], FFTW_BACKWARD, FFTW_ESTIMATE);
            fftw_execute (backward_plan);

            psi_nid[J] = signal[J][0][REAL]/N + I* (signal[J][0][IMAG]/N);
          }
          psi_eigen.push_back (psi_nid);
        }

        // Normalize eigenfunction psi:
        float_type norm_psi = 0;
        for (size_type nid=0; nid<o->nc->size(); nid++) {
          norm_psi += norm2 (psi_eigen[nid]) *sqrt (det (o->g[nid])) *p->dt*p->dt;
        }
        for (size_type nid=0; nid<o->nc->size(); nid++) {
          psi_eigen[nid] /= sqrt (norm_psi);
        }

        fileoutstream ofile ( (p->path+string ("/eigenfunction_") +std::to_string (ny) +string (".lb")).c_str(), std::ios::binary);
        for (size_type nid=0; nid<o->nc->size(); nid++) {
          for (size_type J=0; J<LS; J++) {
            ofile << psi_eigen[nid] (J).real() << psi_eigen[nid] (J).imag();
          }
        }
        ofile.close();
      }

      fftw_destroy_plan (forward_plan);
      fftw_destroy_plan (backward_plan);
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class CoordinateWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing h ... " << endl;

      std::stringstream s;
      s << p->path << "/data/h" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& h = o->h[nid];
        for (size_type i=0; i<h.size(); i++)
          str << h (i) << "\t";
        str << "\n";
      }
      str.close();
    }
};

template<LatticeType LT, size_type D0, size_type LS>
class CoordinateDerWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing dh_dx ... " << endl;

      std::stringstream s;
      s << p->path << "/data/dh_dx" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& dh_dx = o->dh_dx[nid];
        for (size_type j=0; j<D0; j++) for (size_type i=0; i<D; i++) {
            str << dh_dx(i)(j) << "\t";
          }
        str << "\n";
      }
      str.close();
    }
};

template<LatticeType LT, size_type D0, size_type LS>
class MetricWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing g ... " << endl;

      std::stringstream s;
      s << p->path << "/data/g" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& g = o->g[nid];
        for (size_type j=0; j<D; j++) for (size_type i=0; i<D; i++) {
            str << g (i,j) << "\t";
          }
        str << "\n";
      }
      str.close();
    }
};

template<LatticeType LT, size_type D0, size_type LS>
class TetradWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing tetrad ... " << endl;

      std::stringstream s;
      s << p->path << "/data/tetrad" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
      const auto& tetrad = o->tetrad[nid];
      for (size_type j=0; j<D; j++) for (size_type i=0; i<D; i++) {
            str << tetrad (i,j) << "\t";
          }       
        str << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class SpinConnectionCoefficientWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing spin connection coefficients ... " << endl;

      std::stringstream s;
      s << p->path << "/data/omega" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& Omega = o->Omega[nid];
        for (size_type k=0; k<D; k++)
          for (size_type j=0; j<D; j++)
            for (size_type i=0; i<D; i++)
              str << Omega (i,j,k) << "\t";
        str << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class InvMetricWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing g_inv ... " << endl;

      std::stringstream s;
      s << p->path << "/data/g_inv" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& g_inv = o->g_inv[nid];
        for (size_type j=0; j<D; j++) for (size_type i=0; i<D; i++) {
            str << g_inv (i,j) << "\t";
          }
        str << "\n";
      }
      str.close();
    }
};




template<LatticeType LT, size_type D0, size_type LS>
class SqrtMetricWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing sqrt(g) ... " << endl;

      std::stringstream s;
      s << p->path << "/data/sqrt_g" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& g = o->g[nid];
        str << sqrt (det (g)) << "\n";
      }
      str.close();
    }
};




template<LatticeType LT, size_type D0, size_type LS>
class ChristoffelWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing L ... " << endl;

      std::stringstream s;
      s << p->path << "/data/L" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& L = o->L[nid];
        for (size_type k=0; k<D; k++)
          for (size_type j=0; j<D; j++)
            for (size_type i=0; i<D; i++)
              str << L (i,j,k) << "\t";
        str << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class RicciScalarWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      if (t>0 && !o->geometry_is_dynamic) return; // only write once

      cout << "Writing R ... " << endl;

      std::stringstream s;
      s << p->path << "/data/R" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        str << o->R[nid] << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class RhoWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      cout << "Writing rho..." << endl;

      std::stringstream s;
      s << p->path << "/data/rho" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& psi = o->psi[nid];
        str << norm2 (psi) << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class CurrentWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      cout << "Writing Dirac current..." << endl;

      std::stringstream s;
      s << p->path << "/data/current" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& psi = o->psi[nid];
        const auto& tetrad = o->tetrad[nid];

        Vector<float_type,D> Ji;
        for (size_type i=0; i<D; i++) {
          Ji (i) =0;
          for (size_type a=0; a<D; a++) {
            Ji (i) += real (dot (psi,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * psi));
          }
        }
        str << Ji (0) << "\t" << Ji (1) << "\n";
      }
      str.close();
    }
};


template<LatticeType LT, size_type D0, size_type LS>
class PsiWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      cout << "Writing psi ... " << endl;

      std::stringstream s;
      s << p->path << "/data/psi" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& psi = o->psi[nid];
        str << psi (0).real() << "\t"
            << psi (1).real() << "\t"
            << psi (2).real() << "\t"
            << psi (3).real() << "\t"
            << psi (0).imag() << "\t"
            << psi (1).imag() << "\t"
            << psi (2).imag() << "\t"
            << psi (3).imag() << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class PhaseWriter : public Writer<LT,D0,LS> {

  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      cout << "Writing phase ... " << endl;

      std::stringstream s;
      s << p->path << "/data/phase" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& psi = o->psi[nid];
        str << atan2 (psi (0).imag(), psi (0).real()) << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class Norm_t_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void update() override {
      float_type norm = 0;
      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& psi = o->psi[nid];
        const auto& g = o->g[nid];
        norm += norm2 (psi) * p->dt*p->dt * sqrt (det (g));
      }
      norm_t.push_back (sqrt (norm));
    }

    virtual void write_at_end (sim_time_type t) const override {
      cout << "Writing norm(psi)(t) ... " << endl;

      std::stringstream s;
      s << p->path << "/data/norm_t" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());
      for (size_type t=0; t<norm_t.size(); t++) {
        str << t* p->time_step* p->dt << "\t" << norm_t[t] << "\n";
      }
      str.close();
    }

  private:
    vector<float_type> norm_t;
};



template<LatticeType LT, size_type D0, size_type LS>
class Current_t_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write_at_end (sim_time_type t) const override {
      cout << "Writing current(t)... " << endl;
      std::stringstream s;
      s << p->path << "/data/current_t" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      const auto& psi_t = o->psi_t;
      for (size_type t=0; t<psi_t.size(); t++) {
        Vector<float_type,D> ReJi_tot (0);
// 	Vector<float_type,D> ImJi_tot (0);
//         Vector<float_type,D> ReJi_up_tot (0);
// 	Vector<float_type,D> ImJi_up_tot (0);
//         Vector<float_type,D> ReJi_down_tot (0);
// 	Vector<float_type,D> ImJi_down_tot (0);	
//         Vector<Vector<float_type,LS>,D> Ji_K_tot (0);
        for (size_type nid=0; nid<o->nc->size(); nid++) {
          const auto& psi = psi_t[t][nid];
          const auto& g = o->g[nid];
          const auto& tetrad = o->tetrad[nid];
// 	  Spinor<complex<float_type>, LS> psi_up={{psi(0),complex<double>(0, 0),complex<double>(0, 0),psi(3) }};
// 	  Spinor<complex<float_type>, LS> psi_down={{complex<double>(0, 0),psi(1),psi(2),complex<double>(0, 0) }};
          Vector<float_type,D> ReJi;
/*          Vector<float_type,D> ImJi;
          Vector<float_type,D> ReJi_up;
          Vector<float_type,D> ImJi_up;
          Vector<float_type,D> ReJi_down;
          Vector<float_type,D> ImJi_down;	*/  
          for (size_type i=0; i<D; i++) {
            ReJi (i) =0;
// 	    ImJi (i) =0;
//             ReJi_up (i) =0;
// 	    ImJi_up (i) =0;
//             ReJi_down (i) =0;
// 	    ImJi_down (i) =0;	    	    
            for (size_type a=0; a<D; a++) {
              ReJi (i) += real (dot (psi,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * psi));
//               ImJi (i) += imag (dot (psi,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * psi));	      
//               ReJi_up (i) += real (dot (psi_up,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * psi_up));
//               ImJi_up (i) += imag (dot (psi_up,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * psi_up));	      
//               ReJi_down (i) += real (dot (psi_down,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * psi_down));
//               ImJi_down (i) += imag (dot (psi_down,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * psi_down));	       
	    }
           }
                    ReJi_tot += ReJi * p->dt*p->dt * sqrt (det (g));
// 		    ImJi_tot += ImJi * p->dt*p->dt * sqrt (det (g));
//                     ReJi_up_tot += ReJi_up * p->dt*p->dt * sqrt (det (g));
// 		    ImJi_up_tot += ImJi_up * p->dt*p->dt * sqrt (det (g));
//                     ReJi_down_tot += ReJi_down * p->dt*p->dt * sqrt (det (g));
// 		    ImJi_down_tot += ImJi_down * p->dt*p->dt * sqrt (det (g));		    
	 }
          str << t* p->time_step* p->dt << "\t" << ReJi_tot (0) << "\t" << ReJi_tot (1) 
// 	  << "\t" << ImJi_tot (0) << "\t" << ImJi_tot (1) 
// 	  << "\t" << ReJi_up_tot (0) << "\t" << ReJi_up_tot (1)<< "\t" << ImJi_up_tot (0) << "\t" << ImJi_up_tot (1) 
// 	  << "\t" << ReJi_down_tot (0) << "\t" << ReJi_down_tot (1)<< "\t" << ImJi_down_tot (0) << "\t" << ImJi_down_tot (1) 
	  << "\n";
	}
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class Psi_t_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write_at_end (sim_time_type t) const override {
      cout << "Writing psi(t) ... " << endl;
      std::stringstream s;
      s << p->path << "/data/psi_t" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      const auto& psi_t = o->psi_t;
      const size_type nid = o->nc->get_nodeID (Vector<size_type,D> {{p->NX/2, p->NY/2}});
      for (size_type t=0; t<psi_t.size(); t++) {
        str << t* p->time_step* p->dt
            << "\t" << psi_t[t][nid] (0).real()
            << "\t" << psi_t[t][nid] (1).real()
            << "\t" << psi_t[t][nid] (2).real()
            << "\t" << psi_t[t][nid] (3).real()
            << "\t" << psi_t[t][nid] (0).imag()
            << "\t" << psi_t[t][nid] (1).imag()
            << "\t" << psi_t[t][nid] (2).imag()
            << "\t" << psi_t[t][nid] (3).imag();
        str << "\n";
      }
      str.close();
    }
};





template<LatticeType LT, size_type D0, size_type LS>
class Phase_t_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void update() override {

      float_type phase_t_ = 0;
      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& psi = o->psi[nid];
        phase_t_ += atan2 (psi (0).imag(), psi (0).real());
      }
      phase_t_ /= o->nc->size();
      phase_t.push_back (phase_t_);
    }

    virtual void write_at_end (sim_time_type t) const override {
      cout << "Writing phase(t) ... " << endl;

      std::stringstream s;
      s << p->path << "/data/phase_t" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());
      for (size_type t=0; t<phase_t.size(); t++) {
        str << t* p->time_step* p->dt << "\t" << phase_t[t] << "\n";
      }
      str.close();
    }

  private:
    vector<float_type> phase_t;
};



template<LatticeType LT, size_type D0, size_type LS>
class Spreads_t_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    Spreads_t_Writer (float_type x0_, float_type y0_) : x0 (x0_), y0 (y0_) {}

    virtual void update() override {
      Vector<float_type, D> spreads_ (0);
      float_type norm0_ = 0;

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& xyz = o->xyz[nid];
        const auto& psi = o->psi[nid];
        const auto& g = o->g[nid];

        float_type x = xyz (0);
        float_type y = xyz (1);
        float_type sqrt_g = sqrt (det (g));

        //volume element dx*dy cancels later
        spreads_ (0) += real (conj (psi (0)) *psi (0)) * (x-x0) * (x-x0) *sqrt_g;
        spreads_ (1) += real (conj (psi (0)) *psi (0)) * (y-y0) * (y-y0) *sqrt_g;
        norm0_ += real (conj (psi (0)) *psi (0)) *sqrt_g;
      }

      spreads_ (0) = sqrt (spreads_ (0) /norm0_);
      spreads_ (1) = sqrt (spreads_ (1) /norm0_);

      spreads_t.push_back (spreads_);
    }

    virtual void write_at_end (sim_time_type t) const override {
      cout << "Writing norm(psi)(t) ... " << endl;

      std::stringstream s;
      s << p->path << "/data/spreads_t" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());
      for (size_type t=0; t<spreads_t.size(); t++) {
        str << t* p->time_step* p->dt << "\t";
        for (size_type i=0; i<D; i++)
          str << spreads_t[t] (i) << "\t";
        str << "\n";
      }
      str.close();
    }

  private:
    vector<Vector<float_type,D>> spreads_t;
    float_type x0, y0;
};



template<LatticeType LT, size_type D0, size_type LS>
class Energy_Density_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      cout << "Writing energy_density ... " << endl;

      std::stringstream s;
      s << p->path << "/data/energy_density" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& xyz = o->xyz[nid];
        const auto& psi = o->psi[nid];
        const auto& psip = o->psip[nid];
        const auto& g = o->g[nid];

        complex<float_type> T00 = I*dot (psi, Spinor<complex<float_type>, LS> ( (psi-psip) /p->dt));
        complex<float_type> E = T00;

        str << real (E) << "\t" << imag (E) << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class Momentum_Density_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void write (sim_time_type t) const override {
      cout << "Writing momenum_density ... " << endl;

      std::stringstream s;
      s << p->path << "/data/momenum_density" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& xyz = o->xyz[nid];
        const auto& psi = o->psi[nid];
        const auto& psip = o->psip[nid];
        const auto& g = o->g[nid];
        const auto& tetrad = o->tetrad[nid];

        Vector<complex<float_type>,D> Ti0;
        for (size_type i=0; i<D; i++) {
          Ti0 (i) =0;
          for (size_type a=0; a<D; a++) {
            Ti0 (i) += I*dot (psi,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * Spinor<complex<float_type>, LS> ( (psi-psip) /p->dt));
          }
        }
        str << real (Ti0 (0)) << "\t" << imag (Ti0 (0))
            << "\t" << real (Ti0 (1)) << "\t" << imag (Ti0 (1)) << "\t";

        // Now, flat momentum quantities:
        Vector<complex<float_type>,D> Ti0_flat;
        for (size_type a=0; a<D; a++) {
          Ti0_flat (a) =0;
          for (size_type i=0; i<D; i++) {
            // use cotetrad(a,i) = g(i,j)*tetrad(a,j)
            for (size_type j=0; j<D; j++) {
              Ti0_flat (a) += 1./sqrt (det (g)) * g (i,j) *tetrad (a,j) * Ti0 (i);
            }
          }
        }
        str << real (Ti0_flat (0)) << "\t" << imag (Ti0_flat (0))
            << "\t" << real (Ti0_flat (1)) << "\t" << imag (Ti0_flat (1)) << "\n";
      }
      str.close();
    }
};



template<LatticeType LT, size_type D0, size_type LS>
class Energy_t_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void update() override {
      complex<float_type> E = 0;
      float_type dpsi_dt_max = 0;
      float_type psi_max = 0;

      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& xyz = o->xyz[nid];
        const auto& psi = o->psi[nid];
        const auto& psip = o->psip[nid];
        const auto& g = o->g[nid];

        complex<float_type> T00 = I*dot (psi, Spinor<complex<float_type>, LS> ( (psi-psip) /p->dt));
        E += T00*p->dt*p->dt * sqrt (det (g));
      }
      energy_t.push_back (E);
    }

    virtual void write (sim_time_type t) const override {
      cout << "Writing energy(t) ... " << endl;

      std::stringstream s;
      s << p->path << "/data/energy_t" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());
      for (size_type t=0; t<energy_t.size(); t++) {
        str << t* p->time_step* p->dt << "\t" << real (energy_t[t]) << "\t" << imag (energy_t[t]) << "\n";
      }
      str.close();
    }

  private:
    vector<complex<float_type>> energy_t;
};



template<LatticeType LT, size_type D0, size_type LS>
class Momentum_t_Writer : public Writer<LT,D0,LS> {
  public:
    using Writer<LT,D0,LS>::o;
    using Writer<LT,D0,LS>::p;
    using Writer<LT,D0,LS>::D;

    virtual void update() override {
      complex<float_type> E = 0;
      float_type dpsi_dt_max = 0;
      float_type psi_max = 0;

      Vector<complex<float_type>,D> P (0);
      for (size_type nid=0; nid<o->nc->size(); nid++) {
        const auto& xyz = o->xyz[nid];
        const auto& psi = o->psi[nid];
        const auto& psip = o->psip[nid];
        const auto& g = o->g[nid];
        const auto& tetrad = o->tetrad[nid];

        for (size_type i=0; i<D; i++) {
          complex<float_type> Ti0 = 0;
          for (size_type a=0; a<D; a++) {
            Ti0 += I*dot (psi,  Matrix<complex<float_type>, LS> (CliffordAlgebra::GAMMA0 * CliffordAlgebra::GAMMA (a) * tetrad (a,i)) * Spinor<complex<float_type>, LS> ( (psi-psip) /p->dt));
          }
          P (i) += Ti0*p->dt*p->dt * sqrt (det (g));
        }
      }
      momentum_t.push_back (P);
    }

    virtual void write (sim_time_type t) const override {
      cout << "Writing momentum(t) ... " << endl;

      std::stringstream s;
      s << p->path << "/data/momentum_t" << std::setfill ('0') << std::setw (TIME_DIGITS_IN_OUTPUT_FILENAME) << t << ".dat";
      std::ofstream str (s.str().c_str());
      for (size_type t=0; t<momentum_t.size(); t++) {
        str << t* p->time_step* p->dt << "\t" << real (momentum_t[t] (0)) << "\t" << imag (momentum_t[t] (0)) << "\t" << real (momentum_t[t] (1)) << "\t" << imag (momentum_t[t] (1)) << "\n";
      }
      str.close();
    }

  private:
    vector<Vector<complex<float_type>,D>> momentum_t;
};




//======================= WRITER POOL ================================

template<LatticeType LT, size_type D0, size_type LS>
class WriterPool {

  private:
    vector<Writer<LT,D0,LS>*> w; // Writers
    ObservableCache<LT,D0,LS> o; // Observables

  public:

    void initialize (vector<Writer<LT,D0,LS>*> w_,
                     NodeCache<LT,D0,LS>* nc_,
                     ParameterCache* p_) {
      w = w_;
      o = ObservableCache<LT,D0,LS> (nc_, p_, p_->geometry_type);
      for (unsigned int i=0; i<w.size(); i++) {
        w[i]->o = &o;
        w[i]->p = p_;
      }
      write_parameters (p_);
    }

    void update_observableCache() {
      o.update();
    }

    void update() {
      for (unsigned int i=0; i<w.size(); ++i) {
        w[i]->update();
      }
    }

    void write (sim_time_type t) const {
      cout << "t = " << t << endl;
      for (unsigned int i=0; i<w.size(); ++i) {
        w[i]->write (t);
      }
    }

    void write_at_end (sim_time_type t) const {
      for (unsigned int i=0; i<w.size(); ++i) {
        w[i]->write_at_end (t);
//         w[i]->write (t);	
      }
    }

    void filter_psi_t () {
      o.filter_psi_t();
    };

    void filter_psi_range () {
      o.filter_psi_range();
    };    
    
    void write_parameters (ParameterCache* p_) {
      std::ofstream param_stream ( (p_->path + string ("/param.dat")).c_str());
      param_stream << p_->print();
      param_stream.close();
    }
};


#endif // !defined WRITER_HPP


