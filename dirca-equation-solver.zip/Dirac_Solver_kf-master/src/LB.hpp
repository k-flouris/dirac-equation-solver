/**
 * \file
 * \author Jens-Daniel Debus,  ETH Zurich
 * \date 2015
 * \brief Lattice Boltzmann core file
 * \details
 */
#ifndef LB_HPP
#define LB_HPP

#include "macros.hpp"
#include "Lattice.hpp"
#include "CliffordAlgebra.hpp"
#include "ParameterCache.hpp"
#include "NodeCache.hpp"
#include "Writer.hpp"
#include "Tests.hpp"


/**
 * @brief Lattice Boltzmann core class
 */
template<LatticeType LT, size_type D0 = Lattice<LT>::D, size_type LS=4>
class LB {
  
public:
  
  // Typedefs and enums
  typedef typename NodeCache<LT,D0,LS>::Node Node;
  
  
  
  //======================= MEMBERS  ================================
  
  // Template parameters
  constexpr static size_type D = Lattice<LT>::D;          // Spatial dimension
  
  ParameterCache p;
  sim_time_type t;
  
  // Nodes
  NodeCache<LT,D0,LS> nodes;
  
  // WriterPool (performing measurements and writing to files)
  WriterPool<LT,D0,LS> writer;
  std::thread writer_thread;
  
  // Analytical Metric and Christoffel symbols
  function< Vector<float_type, D0> (Vector<float_type, D>, float_type) > h_func;
  function< Vector<Vector<float_type, D0>, D> (Vector<float_type, D>, float_type) > dh_dx_func;
  function< Metric<float_type, D> (Vector<float_type, D>, float_type) > g_func;
  function< ChristoffelSymbol<float_type, D> (Vector<float_type, D>, float_type) > L_func;
  function< Matrix<float_type, D> (Vector<float_type, D>, float_type) > tetrad_func;

  // External potentials
  function<float_type (Vector<float_type, D> xyz, float_type t) > V;
  function<Vector<float_type, D> (Vector<float_type, D> xyz, float_type t) > A;
  
  // Lattice functions
  function<float_type (Vector<float_type, D> xyz, size_type i) > h;
  function<float_type (Vector<float_type, D> xyz, size_type i, size_type j) > dh_dx;
  function<float_type (Vector<float_type, D> xyz, size_type i, size_type j) > g;
  function<float_type (Vector<float_type, D> xyz, size_type i, size_type j) > g_inv;
  function<float_type (Vector<float_type, D> xyz, size_type i, size_type j, size_type k) > L;
  function<float_type (Vector<float_type, D> xyz, size_type i, size_type j) > tetrad;
  
  
  
  
  //======================= INITIALIZATION ================================
  
  void init_LB (ParameterCache* p_,
		
		function< Vector<float_type, D0> (Vector<float_type, D>, float_type) > h_func_,
		function< Vector<Vector<float_type, D0>, D> (Vector<float_type, D>, float_type) > dh_dx_func_,
		function< Metric<float_type, D> (Vector<float_type, D>, float_type) > g_func_,
		function< ChristoffelSymbol<float_type, D> (Vector<float_type, D>, float_type) > L_func_,
		function< Matrix<float_type, D> (Vector<float_type, D>, float_type) > tetrad_func_,
		
		function<float_type (Vector<float_type, D> xyz, float_type t) > V_,
		function<Vector<float_type, D> (Vector<float_type, D> xyz, float_type t) > A_,
		
		vector<Writer<LT,D0,LS>*> w_
  ) {
    p = *p_;
    t = 0;
    
    init_geometry_functions (h_func_, dh_dx_func_, g_func_, L_func_,tetrad_func_);
    init_lattice_functions();
    init_potential_functions (V_, A_);
    
    cout << " Initializing geometry..." << endl;
    update_geometry(); // Initialize metric, christoffels, Ricci...
    cout << "  Done." << endl;
    
    writer.initialize (w_, &nodes, p_);
  }
  
  
  
  void init_potential_functions (function<float_type (Vector<float_type, D> xyz, float_type t) > V_,
				 function<Vector<float_type, D> (Vector<float_type, D> xyz, float_type t) > A_) {
    V = V_;
    A = A_;
    
    
				 }
				 
				 
				 
				 void init_geometry_functions (function< Vector<float_type, D0> (Vector<float_type, D>, float_type) > h_func_,
							       function< Vector<Vector<float_type, D0>, D> (Vector<float_type, D>, float_type) > dh_dx_func_,
							       function< Metric<float_type, D> (Vector<float_type, D>, float_type) > g_func_,
							       function< ChristoffelSymbol<float_type, D> (Vector<float_type, D>, float_type) > L_func_,
							       function< Matrix<float_type, D> (Vector<float_type, D>, float_type) > tetrad_func_) {
				   
				   h_func = h_func_;
				   dh_dx_func = dh_dx_func_;
				   g_func = g_func_;
				   L_func = L_func_;
				   tetrad_func=tetrad_func_;
				   
				   
							       }
							       
							       
							       void init_lattice_functions() {
								 // Lattice functions
								 h     = [&] (Vector<float_type, D> pos_xyz, size_type i)             ->float_type { return nodes.get_node (pos_xyz).h (i); };
								 dh_dx = [&] (Vector<float_type, D> pos_xyz, size_type i, size_type j)->float_type { return nodes.get_node (pos_xyz).dh_dx (i) (j); };
								 g     = [&] (Vector<float_type, D> pos_xyz, size_type i, size_type j)->float_type { return nodes.get_node (pos_xyz).g (i,j); };
								 g_inv = [&] (Vector<float_type, D> pos_xyz, size_type i, size_type j)->float_type { return nodes.get_node (pos_xyz).g_inv (i,j); };
								 L     = [&] (Vector<float_type, D> pos_xyz, size_type i, size_type j, size_type k)->float_type { return nodes.get_node (pos_xyz).L (i,j,k); };
							       }
							       
							       
							       
							       //======================= DYNAMIC UPDATES ================================
							       
							       
							       void update_potentials() {
								 // cannot be run in parallel (lambda functions access same variable xyz,t)
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   Vector<float_type,D> xyz = Lattice<LT>::p_to_xyz (n.pos);
								   n.V = V (xyz,t);
								   n.A = A (xyz,t);
								 }
							       }
							       
							       
							       
							       void update_geometry () {
								 if (h_func == NULL) update_chart_manually();
								 else update_chart_analytically();
								 
								 if (dh_dx_func == NULL) update_vector_basis_numerically();
								 else update_vector_basis_analytically();
								 
								 if (g_func == NULL) update_metric_numerically();
								 else update_metric_analytically();
								 
								 if (L_func == NULL){
								   cout << "  Updating Christoffel symbols numerically ...";
								   update_christoffels_numerically();
								    cout << " Done" << endl;

								 }
								 else{								   
								   cout << "  Updating Christoffel symbols analytically ...";
								   update_christoffels_analytically();
								   cout << " Done" << endl;								   
								 }
								 if (tetrad_func == NULL)  update_tetrad_numerically();
								 else update_tetrad_analytically();
								 
								 update_Ricci_scalar_numerically();
								 update_Omega_numerically(); // spin connection
								 update_FF(); // forcing term
							       }
							       
							       
							       
							       virtual void update_chart_manually () {
								 // specify manual chart update as virtual function in child configuration class
							       }
							       
							       
							       
							       void update_chart_analytically () {
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   Vector<float_type, D>xyz =  Lattice<LT>::p_to_xyz (n.pos);
								   n.h = h_func (xyz, t*p.dt);
								 }
							       }
							       
							       
							       
							       void update_vector_basis_numerically() {
								 
								 // Update laplacian of h
								 // Bulk nodes (isotropic lattice derivative)
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type bid=0; bid<nodes.no_derivative_bulk_nodes(); bid++) {
								   Node& n = nodes.get_derivative_bulk_node (bid);
								   for (size_type i=0; i<D0; ++i) n.laplace_h (i) = laplace_h_bulk (n, i);
								 }
								 
								 
								 // Boundary extrapolation
								 for (size_type idx=0; idx<nodes.boundary_index_sectors.size()-1; ++idx) {
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type bid = nodes.boundary_index_sectors[idx]; bid < nodes.boundary_index_sectors[idx+1]; ++bid) {
								     Node& n = nodes.get_boundary_node (bid);
								     size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								     size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								     
								     Node& n1 = nodes[nid1];
								     Node& n2 = nodes[nid2];
								     n.laplace_h = 2*n1.laplace_h - n2.laplace_h;
								   }
								 }
								 
								 
								 
								 // update vector basis
								 // Bulk nodes (isotropic lattice derivative)
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type bid=0; bid<nodes.no_derivative_bulk_nodes(); bid++) {
								   Node& n = nodes.get_derivative_bulk_node (bid);
								   
								   for (size_type i=0; i<D0; ++i) for (size_type x=0; x<D; ++x)
								     n.dh_dx (x) (i) = dh (n, i, x);
								 }
								 
								 
								 
								 // Boundary extrapolation
								 for (size_type idx=0; idx<nodes.boundary_index_sectors.size()-1; ++idx) {
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type bid = nodes.boundary_index_sectors[idx]; bid < nodes.boundary_index_sectors[idx+1]; ++bid) {
								     Node& n = nodes.get_boundary_node (bid);
								     size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								     size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								     
								     Node& n1 = nodes[nid1];
								     Node& n2 = nodes[nid2];
								     
								     n.dh_dx = 2*n1.dh_dx - n2.dh_dx;
								   }
								 }
							       }
							       
							       
							       
							       void update_vector_basis_analytically() {
								 
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   Vector<float_type, D>xyz =  Lattice<LT>::p_to_xyz (n.pos);
								   n.dh_dx = dh_dx_func (xyz,t*p.dt);
								 }
							       }
							       
							       
							       
							       void update_metric_numerically () {
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   for (size_type i=0; i<D; i++) for (size_type j=0; j<=i; j++) {
								     n.g.at (i,j) = dot (n.dh_dx (i), n.dh_dx (j));
								   }
								   n.g_inv = inv (n.g);
								   n.sqrt_g = sqrt (det (n.g));
								 }
							       }
							       
							       
							       
							       void update_metric_analytically () {
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   Vector<float_type, D>xyz = Lattice<LT>::p_to_xyz (n.pos);
								   n.g = g_func (xyz,  t*p.dt);
								   n.g_inv = inv (n.g);
								   n.sqrt_g = sqrt (det (n.g));
								 }
							       }
							       
							       
							       
							       void update_christoffels_numerically () {
								 // Update laplacian of g
								 // Bulk nodes (isotropic lattice derivative)
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type bid=0; bid<nodes.no_derivative_bulk_nodes(); bid++) {
								   Node& n = nodes.get_derivative_bulk_node (bid);
								   for (size_type i=0; i<D; i++) for (size_type j=0; j<=i; j++)
								     n.laplace_g.at (i, j) = laplace_g_bulk (n, i, j);
								 }
								 
								 
								 // Boundary extrapolation
								 for (size_type idx=0; idx<nodes.boundary_index_sectors.size()-1; ++idx) {
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type bid = nodes.boundary_index_sectors[idx]; bid < nodes.boundary_index_sectors[idx+1]; ++bid) {
								     Node& n = nodes.get_boundary_node (bid);
								     size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								     size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								     
								     Node& n1 = nodes[nid1];
								     Node& n2 = nodes[nid2];
								     n.laplace_g = 2*n1.laplace_g - n2.laplace_g;
								   }
								 }
								 
								 // update christoffel symbols
								 // Bulk nodes (isotropic lattice derivative)
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type bid=0; bid<nodes.no_derivative_bulk_nodes(); bid++) {
								   Node& n = nodes.get_derivative_bulk_node (bid);
								   for (size_type i=0; i<D; i++) for (size_type j=0; j<D; j++) for (size_type k=0; k<=j; k++) {
								     n.L.at (i,j,k) = 1./2.*n.g_inv (i,0) * (dg_bulk (n, k,0,j) + dg_bulk (n, j,0,k) - dg_bulk (n, j,k,0));
								     for (size_type m=1; m<D; m++)
								       n.L.at (i,j,k) += 1./2.*n.g_inv (i,m) * (dg_bulk (n, k,m,j) + dg_bulk (n, j,m,k) - dg_bulk (n, j,k,m));
								   }
								 }
								 
								 // Boundary extrapolation
								 for (size_type idx=0; idx<nodes.boundary_index_sectors.size()-1; ++idx) {
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type bid = nodes.boundary_index_sectors[idx]; bid < nodes.boundary_index_sectors[idx+1]; ++bid) {
								     Node& n = nodes.get_boundary_node (bid);
								     size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								     size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								     
								     Node& n1 = nodes[nid1];
								     Node& n2 = nodes[nid2];
								     n.L = 2*n1.L - n2.L;
								   }
								 }
							       }
							       
							       
							       
							       void update_christoffels_analytically () {
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   Vector<float_type, D>xyz =  Lattice<LT>::p_to_xyz (n.pos);
								   n.L = L_func (xyz, t*p.dt);
								 }
							       }
							       
							       
							       
							       void update_Ricci_scalar_numerically () {
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   
								   Tensor<float_type, D, 2, SYM> Ric (D);
								   for (size_type i=0; i<D; i++) for (size_type j=0; j<=i; j++) {
								     Ric.at (i,j) = 0;
								     for (size_type k=0; k<D; k++) {
								       Ric.at (i,j) += dL (n, k,i,j,k) - dL (n, k,k,i,j);
								       for (size_type m=0; m<D; m++)
									 Ric.at (i,j) += n.L (k,k,m) * n.L (m,j,i) - n.L (k,j,m) * n.L (m,k,i);
								     }
								   }
								   
								   n.R = 0;
								   for (size_type i=0; i<D; i++) for (size_type j=0; j<D; j++) {
								     n.R += Ric (i,j) *n.g_inv (i,j);
								   }
								 }
							       }
							       
							       
							       /**
								* @brief Update the tetrad, tetrad(a, i)= \f$ e_a^{\ i} \f$, and cotetrad,  cotetrad(a, i)= \f$ e^a_{\ i} \f$
								* @details The tetrad is defined by \f$ g^{ij} = e_a^{\ i} \delta^{ab} e_b^{\ j} \f$.
								* The co-tetrad is defined by \f$ g_{ij} = e^a_{\ i} \delta_{ab} e^b_{\ j} \f$.
								* Tetrad and co-tetrad are connected by the relation \f$ e_a^{\ i} = g^{ij} e^a_{\ j} \f$
								* or, equivalently, \f$ e^a_{\ i} = g_{ij} e_a^{\ j} \f$
								*/
							       void update_tetrad_numerically() {
								 
								 float_type delta_ab_error_max = 0;
								 
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   auto xyz = Lattice<LT>::p_to_xyz (n.pos);
								   
								   //      // 1. possibility: Sylvester transform:
								   //             n.tetrad   = transpose ( Sylvester_transform_matrix ( n.g_inv ) );
								   //      // Calculate co-tetrad
								   //             for ( int a=0; a<D; a++ ) for ( int i=0; i<D; i++ ) {
								   //                     n.cotetrad ( a, i ) = 0;
								   //                     for ( int j=0; j<D; j++ )
								   //                         n.cotetrad ( a, i ) += n.g ( i, j ) *n.tetrad ( a, j );
								   //                 }
								   
								   
								   // 2. possibility: from paper "Optical conductivity in curved graphene" :
								   //         float_type hxhx = n.dh_dx (0) (2) *n.dh_dx (0) (2);
								   //         float_type hxhy = n.dh_dx (0) (2) *n.dh_dx (1) (2);
								   //         float_type hyhy = n.dh_dx (1) (2) *n.dh_dx (1) (2);
								   //         float_type R_ = hxhx + hyhy;
								   //         // Taylor expansion of (sqrt(1+R)-1)/R:
								   //         float_type A_ = 1./2.-1./8.*R_+1./16.*pow (R_,2)-5./128.*pow (R_,3) +7./256.*pow (R_,4)-21./1024.*pow (R_,5) +33./2048.*pow (R_,6)-429./32768.*pow (R_,7) +715./65536.*pow (R_,8)-2431./262144.*pow (R_,9) +4199./524288.*pow (R_,10);
								   //
								   //         n.cotetrad (0,0) = 1 + A_*hxhx;
								   //         n.cotetrad (0,1) = A_*hxhy;
								   //         n.cotetrad (1,0) = A_*hxhy;
								   //         n.cotetrad (1,1) = 1 + A_*hyhy;
								   
								   
								   // 3. possibility: explicitly from metric:
								   float_type R_ = sqrt (n.g.at (0,0) +n.g.at (1,1) +2*n.sqrt_g);
								   n.cotetrad (0,0) = (n.g.at (0,0) +n.sqrt_g) /R_;
								   n.cotetrad (0,1) = n.g.at (1,0) /R_;
								   n.cotetrad (1,0) = n.g.at (1,0) /R_;
								   n.cotetrad (1,1) = (n.g (1,1) +n.sqrt_g) /R_;
								   
								   
								   // Calculate corresponding tetrad
								   for (int a=0; a<D; a++) for (int i=0; i<D; i++) {
								     n.tetrad (a, i) = 0;
								     for (int j=0; j<D; j++)
								       n.tetrad (a, i) += n.g_inv (i, j) *n.cotetrad (a, j);
								   }
								   //        std::cout<<" g-inv="<<n.g_inv<<" cotetrad="<< n.cotetrad<<" sqrtG="<< n.sqrt_g<<std::endl;
								   
								   // Checking some identities
								   for (int a=0; a<D; a++) for (int b=0; b<D; b++) {
								     float_type delta_ab = 0;
								     for (int i=0; i<D; i++) for (int j=0; j<D; j++)
								       delta_ab += n.cotetrad (a, i) * n.g_inv (i, j) * n.cotetrad (b, j);
								     
								     //ASSERT1 ( abs ( delta_ab - ( a==b ) ) < 1e-14 )
								     if (abs (delta_ab - (a==b)) > delta_ab_error_max) {
								       delta_ab_error_max = abs (delta_ab - (a==b));
								     }
								   }
								   
								   for (int a=0; a<D; a++) for (int b=0; b<D; b++) {
								     float_type delta_ab = 0;
								     for (int i=0; i<D; i++) for (int j=0; j<D; j++)
								       delta_ab += n.tetrad (a, i) * n.g (i, j) * n.tetrad (b, j);
								     
								     //ASSERT1 ( abs ( delta_ab - ( a==b ) ) < 1e-14 )
								     if (abs (delta_ab - (a==b)) > delta_ab_error_max) {
								       delta_ab_error_max = abs (delta_ab - (a==b));
								     }
								   }
								   
								 }
								 
								 if (delta_ab_error_max > 1e-13)
								   cout << "\033[1;31mWarning: delta_ab - delta_ab_theo = " << delta_ab_error_max << "\033[0m" << endl;
							       }
							       
							      void update_tetrad_analytically () {
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   Vector<float_type, D>xyz =  Lattice<LT>::p_to_xyz (n.pos);
								   n.tetrad = tetrad_func (xyz, t*p.dt);
								 }
							       }
							         
							       
							       /**
								* @brief update Omega(a, b, i) = \f$ \Omega^{ab}_i = \frac{1}{2} e^{aj}(\partial_i e^b_{\ j}-\partial_j e^b_{\ i}) \f$
								*/
							       void update_Omega_numerically() {
								 
								 // Update laplacian of cotetrad
								 // Bulk nodes (isotropic lattice derivative)
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type bid=0; bid<nodes.no_derivative_bulk_nodes(); bid++) {
								   Node& n = nodes.get_derivative_bulk_node (bid);
								   for (size_type a=0; a<D; a++) for (size_type i=0; i<D; i++)
								     n.laplace_cotetrad (a, i) = laplace_cotetrad_bulk (n, a, i);
								 }
								 
								 
								 // Boundary extrapolation
								 for (size_type idx=0; idx<nodes.boundary_index_sectors.size()-1; ++idx) {
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type bid = nodes.boundary_index_sectors[idx]; bid < nodes.boundary_index_sectors[idx+1]; ++bid) {
								     Node& n = nodes.get_boundary_node (bid);
								     size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								     size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								     
								     Node& n1 = nodes[nid1];
								     Node& n2 = nodes[nid2];
								     n.laplace_cotetrad = 2*n1.laplace_cotetrad - n2.laplace_cotetrad;
								   }
								 }
								 
								 
								 
								 // update Omega
								 // Bulk nodes (isotropic lattice derivative)
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type bid=0; bid<nodes.no_derivative_bulk_nodes(); bid++) {
								   Node& n = nodes.get_derivative_bulk_node (bid);
								   for (size_type a=0; a<D; a++) for (size_type b=0; b<D; b++) for (size_type i=0; i<D; i++) {
								     n.Omega (a,b,i) = 0;
								     for (size_type j=0; j<D; j++) for (size_type r=0; r<D; r++)
								       n.Omega (a,b,i) += -0.5*n.cotetrad (a, r) *n.g_inv (r, j) * (
									 dcotetrad (n, b, j, i) - dcotetrad (n, b, i, j)
								       );
								   }
								 }
								 
								 // Boundary extrapolation
								 for (size_type idx=0; idx<nodes.boundary_index_sectors.size()-1; ++idx) {
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type bid = nodes.boundary_index_sectors[idx]; bid < nodes.boundary_index_sectors[idx+1]; ++bid) {
								     Node& n = nodes.get_boundary_node (bid);
								     size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								     size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								     
								     Node& n1 = nodes[nid1];
								     Node& n2 = nodes[nid2];
								     n.Omega = 2*n1.Omega - n2.Omega;
								   }
								 }
							       }
							       
							       
							       
							       //     /**
							       //      * @brief update Omega(a, b, i) = \f$ \Omega^{ab}_i = \frac{1}{2} e^{aj}(\partial_i e^b_{\ j}-\partial_j e^b_{\ i}) \f$
							       //      */
							       //     void update_Omega() {
							       //
							       //       // TODO Debug
							       //
							       // #if LB_OMP
							       //       #pragma omp parallel for
							       // #endif
							       //       for (size_type nid=0; nid<nodes.size(); nid++) {
							       //         Node& n = nodes[nid];
							       //
							       //         float_type R_ = sqrt (n.g.at (0,0) +n.g.at (1,1) +2*n.sqrt_g);
							       //
							       //         for (size_type a=0; a<D; a++) for (size_type b=0; b<D; b++) for (size_type i=0; i<D; i++) {
							       //               n.Omega (a,b,i) = 0;
							       //
							       //               // use e^{a,j} = -e_a^j = -tetrad(a,j)
							       //               for (size_type j=0; j<D; j++) for (size_type l=0; l<D; l++) {
							       //
							       //                   // auxiliary variables:
							       //                   float_type F_ill = 0;
							       //                   float_type F_jll = 0;
							       //                   for (size_type k=0; k<D; k++) {
							       //                     F_ill += n.L (l,i,k) *n.g (k,l);
							       //                     F_jll += n.L (l,j,k) *n.g (k,l);
							       //                   }
							       //
							       //                   // actual sum:
							       //                   n.Omega (a,b,i) += -0.5*n.tetrad (a,j) *
							       //                                      (
							       //                                        ( (n.L (l,i,b) *n.g (j,l)-n.L (l,j,b) *n.g (i,l))
							       //                                          + ( (b==j) *n.L (l,l,i)- (b==i) *n.L (l,l,j)) *n.sqrt_g) /R_
							       //                                        - ( (n.g (a,j) + (a==j) *n.sqrt_g) * (F_ill+n.L (l,l,i) *n.sqrt_g)
							       //                                            - (n.g (a,i) + (a==i) *n.sqrt_g) * (F_jll+n.L (l,l,j) *n.sqrt_g)) / (R_*R_*R_)
							       //                                      );
							       //                 }
							       //             }
							       //       }
							       //     }
							       
							       
							       
							       
							       /**
								* @brief Update the forcing term FF(c)(I,J) = \f$ \mathcal F_{c, IJ} = e_c^{\ i} (\frac{\imath}{4} \omega^{ab}_i \sigma_{c, ab, IJ} - i A_i) \f$
								* @details Here, \f$ \omega^{ab}_i = \Omega^{ab}_i - \Omega^{ba}_i - e^{aj}\Omega^{bc}_j e_{ci} \f$
								* is the spin connection, \f$ \Omega^{ab}_i = \frac{1}{2} e^{aj}(\partial_i e^b_{\ j}-\partial_j e^b_{\ i}) \f$
								* and \f$ \sigma_{c, ab} = \frac{\imath}{2} X_c^\dagger[\gamma_a, \gamma_b] X_c \f$.
								*/
							       void update_FF() {
								 
								 float_type omega_error = 0;
								 
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   Node& n = nodes[nid];
								   Vector<float_type,D> xyz = Lattice<LT>::p_to_xyz (n.pos);
								   
								   for (size_type c=0; c<D; c++) {
								     
								     n.FF (c).zero();
								     
								     for (size_type i=0; i<D; i++) {
								       
								       // pre-calculate omega^i_ab*sigma^ab
								       Matrix<complex<float_type>, LS> omega_sigma_i (0);
								       for (size_type a=0; a<D; a++) for (size_type b=0; b<D; b++) {
									 
									 // calculate omega^ab_i numerically:
									 float_type omega_ab_i = n.Omega (a, b, i) - n.Omega (b, a, i);
									 for (size_type j=0; j<D; j++) for (size_type c=0; c<D; c++) {
									   // use e^{a,j} = -e_a^j = -tetrad(a,j)
									   // use e_{c,i} = -e^c_i = -cotetrad(c,i)
									   omega_ab_i += -n.tetrad (a, j) *n.Omega (b, c, j) * n.cotetrad (c, i);
									 }
									 
									 
									 // analytical expression
									 /*float_type k = 2*M_PI*p.k0/ (p.NX*p.dt);
									  *                float_type df_dx = p.a0*p.a0*k*k*k*sin (k*xyz (0)) *cos (k*xyz (0));
									  *                if (i==1 && a==0 && b==1) omega_ab_i = - df_dx;
									  *                else if (i==1 && a==1 && b==0) omega_ab_i = + df_dx;
									  *                else omega_ab_i = 0;
									  */
									 
									 //                 // use analytical spin connection:
									 //                 float_type hxhx = n.g (0,0)-1;
									 //                 float_type hxhy = n.g (1,0);
									 //                 float_type hyhy = n.g (1,1)-1;	
									 //                 float_type R_ = hxhx + hyhy;
									 //                 float_type A_ = 1./2.-1./8.*R_+1./16.*pow (R_,2)-5./128.*pow (R_,3) +7./256.*pow (R_,4)-21./1024.*pow (R_,5) +33./2048.*pow (R_,6)-429./32768.*pow (R_,7) +715./65536.*pow (R_,8)-2431./262144.*pow (R_,9) +4199./524288.*pow (R_,10);
									 //                 float_type Omega_tilde = A_/sqrt (1+hxhx*hyhy);
									 //
									 //                 float_type h_a = n.dh_dx (a) (2);
									 //                 float_type h_b = n.dh_dx (b) (2);
									 //                 float_type h_bi = n.dh_dxdx (b,i) (2);
									 //                 float_type h_ia = n.dh_dxdx (i,a) (2);
									 //                 float_type omega_ab_i = (-h_a*h_bi + h_b*h_ia) *Omega_tilde;
									 
									 //ASSERT1 ( abs ( omega_ab_i - omega_ab_i_theo ) < 1e-14 )
									 //                   if (abs (omega_ab_i - omega_ab_i_theo) > omega_error) {
									 //                     omega_error = abs (omega_ab_i - omega_ab_i_theo);
									 //                   }
									 
									 
									 omega_sigma_i += omega_ab_i * CliffordAlgebra::sigma (c) (a, b);
								       }
								       
								       // calculate FF
								       n.FF (c) += I/4.*n.tetrad (c, i) * omega_sigma_i;
								     }
								   }
								 }
								 
								 if (omega_error > 1e-13)
								   cout << "\033[1;31mWarning: omega_ab_i - omega_ab_i_theo = " << omega_error << "\033[0m" << endl;
							       }
							       
							       
							       void update_boundary_by_extrapolation(size_type c) {
								 
								 // order is important (race condition!),  thus parallelization tricky
// 								 TODO: can do a container and remove each note once used
								 for (size_type bid=0; bid<nodes.no_boundary_nodes(); ++bid) {
								   
								   const typename NodeCache<LT,D0,LS>::BoundaryElement& el = nodes.get_boundary_element (bid);
								   
								   if (el.is_extrapolation_boundary) {
								     
								     Node& n = nodes.get_boundary_node (bid);
								     
								     for (size_type K=0; K<LS; K++) {
								       if (!n.psi_fixed (K)) {
									 
									 // average over all possible extrapolation directions
									 n.psi (K)      =0;
									 n.psi_temp (K) =0;
									 size_type N = 1;//el.extrapolation_nodeIDs.size();
									 for (size_type i=0; i<N; ++i) {   //for all boundary normal directions
// 									   This gets the "inside" extrapolation nodes as with the derivatives
									   size_type nid1 = el.extrapolation_nodeIDs[i].first;
									   size_type nid2 = el.extrapolation_nodeIDs[i].second;
									   
									   const Node& n1 = nodes[nid1]; 
									   const Node& n2 = nodes[nid2];
									   
									   n.psi (K)      += 2.*n1.psi (K) - n2.psi (K);
									   n.psi_temp (K) += 2.*n1.psi_temp (K) - n2.psi_temp (K);
									 }
									 n.psi (K)      /= static_cast<float_type> (N);
									 n.psi_temp (K) /= static_cast<float_type> (N);
								       }
								     }
								   }
								   else if (el.is_closed_boundary) {
								     
								     Node& n = nodes.get_boundary_node (bid);
								     
								     for (size_type K=0; K<LS; K++) {
								       if (!n.psi_fixed (K)){   
									 n.psi_temp (0) = complex<double>(0, 0)  ; 
								      }
// 									 TODO: make the closed into a reflective boundary maybe using the model of BB
// 									 const size_type l1 = Lattice<LT>::l_inv (l);
//  (									 const Node& nn	= n.nn (Lattice<LT>::lattice_index (c, -SIGN (K))));
// 								         use the fact that streaming is just setting the psi temp
// 									 streaming is in each dierection c
// 									 WARNING what about the corners? think
									 
// 									 Vector<float_type, D> pos_xyz = Lattice<LT>::p_to_xyz (n.pos);
// 									 Vector< size_type, D> pos_ijk = Lattice<LT>::xyz_to_ijk (pos_xyz);									    
// 							                 size_type lat_ind=Lattice<LT>::lattice_index (c, -SIGN (K)); //1 2 3 4
// 								         const Node& nn1 = * (n.nn (1)); // index of velocity componet (9)C and ( + + - - )
// 									 const Node& nn4 = * (n.nn (4));
// 									 const Node& nn2 = * (n.nn (2));									 
// 									 const Node& nn3 = * (n.nn (3));									 
// // 									    std::cout <<"c="<< c<< " K="<<K << " lat_ind= "<< lat_ind<< " pos=" <<  pos_ijk << " nn1.psi= " << nn1.psi << std::endl;	     
// 									 if (pos_ijk(0)==0){								
// 									   if (lat_ind==1) n.psi_temp (K) = nn1.psi_temp (K) - nn4.psi_temp (K);
// 									   if (lat_ind==4) n.psi_temp (K) = 0;
//    									}
// 									 else if (pos_ijk(0)==p.NX-1 ) {									
// 									   if (lat_ind==4)n.psi_temp (K) = - nn1.psi_temp (K) + nn4.psi_temp (K);
// 									   if (lat_ind==1)n.psi_temp (K) = 0;	
// 									  }									 
//  									 else if (pos_ijk(1)==0 ) {
// 									   if (lat_ind==2)n.psi_temp (K) = nn2.psi (K) - nn3.psi (K);
// 									   if (lat_ind==3)n.psi_temp (K) = 0;
// 									 }
//  									 else if (pos_ijk(1)==p.NY-1 ){
// 									   if (lat_ind==3)n.psi_temp (K) = - nn2.psi (K) + nn3.psi (K);
// 									   if (lat_ind==2)n.psi_temp (K) = 0;
// 									 }	 
// 									 else std::cout << "BOUNDARY ERROR" << std::endl;
									 
// 									 ATTEMPT ON REFLECTING BOUNDARY
// 									 if (pos_ijk(0)==0){								
// 									      n.psi_temp (K) = nn1.psi_temp (K) - nn4.psi_temp (K);
// 									      n.psi (K) = nn1.psi (K) - nn4.psi (K);
//    									}
// 									 else if (pos_ijk(0)==p.NX-1 ) {									
//                                                                                   n.psi_temp(0) =n.psi_temp (0) +n.psi_temp (3);
// 									          n.psi (0) = n.psi (0) +n.psi (3);
//                                                                                   n.psi_temp(3) =0;
// 									          n.psi (3) = 0	;										  
// 									  }									 
//  									 else if (pos_ijk(1)==0 ) {
// 									   if (lat_ind==2)n.psi_temp (K) = nn2.psi (K) - nn3.psi (K);
// 									   if (lat_ind==3)n.psi_temp (K) = 0;
// 									 }
//  									 else if (pos_ijk(1)==p.NY-1 ){
// 									   if (lat_ind==3)n.psi_temp (K) = - nn2.psi (K) + nn3.psi (K);
// 									   if (lat_ind==2)n.psi_temp (K) = 0;
// 									 }	 
// 									 else std::cout << "BOUNDARY ERROR" << std::endl;
									 
									 
// 								         The following are for sort of open/extrapolation boundaries
// 									 if(K==3){
// 									 n.psi (3)      = -nn4.psi (3)  ;
// 									 n.psi_temp (3) = -n.psi_temp (3) ;}
/*									 n.psi (3)      = complex<double>(0, 0) ;
									 n.psi_temp (3) = complex<double>(0, 0)  ;*/									 

// 									 Not sure about the following
/*									 n.psi (2)      = complex<double>(0, 0) ;
									 n.psi_temp (2) = complex<double>(0, 0)  ;*/									 
								       
								     }
								   }
								 }
							       }
							       
							       
							       
							       //======================= LB OPERATIONS ================================
							       
							       //   NOTE: kf n.psi_fixed was updated to be included in the code
							       
							       /**
								* @brief Rotation step (psi -> psi_temp)
								* @param n Node
								* @param c spatial direction of the splitted operator, (x, y, z) = (0, 1, 2)
								*/
							       inline void rotate (Node& n, size_type c) {
								 
								 n.psi_temp = CliffordAlgebra::X_inv (c) * n.psi;
								 
								 // Check rotation
								 for (int K=0; K<LS; K++) {
								   std::complex<float_type> psi_temp_K = 0;
								   for (int J=0; J<LS; J++) psi_temp_K += CliffordAlgebra::X_inv (c) (K, J) *n.psi (J);
								   ASSERT2 (abs (n.psi_temp (K) - psi_temp_K) < 1e-15)
								 }
							       }
							       
							       
							       /**
								* @brief Collisions (curvature effects and mass) (psi_temp -> psi)
								* @param n Node
								* @param c spatial direction of the splitted operator, (x, y, z) = (0, 1, 2)
								*/
							       inline void collide (Node& n, size_type c) {
								 Vector<float_type,D> xyz = Lattice<LT>::p_to_xyz (n.pos);
								 // *** sqrt_g for Hermitiancy of Hamiltonian
								 //kf maybe can improve this such that to i
								 float_type correction;
								 if (p.hamiltonian_type==GRAPHENE) correction= n.sqrt_g;
								 else if (p.hamiltonian_type==DIRAC) correction=1;
								 else {
								   std::cout<< "Error:Hamiltonian type not well defined. Exiting..."<<std::endl;
								   EXIT
								 }
								 // compute collision operator:
								 Matrix< complex< float_type >,  LS> g0 = CliffordAlgebra::GAMMA0;
								 Matrix< complex< float_type >,  LS> g0_c = CliffordAlgebra::X_inv (c) * g0 * CliffordAlgebra::X (c);
								 
								 float_type A_c = 0;
								 for (size_type i=0; i<D; i++) A_c += n.tetrad (c,i) *n.A (i);
								 
								 // *** sqrt_g for Hermitiancy of Hamiltonian
								 Matrix< complex< float_type >,  LS> Ctilde_c;
								 
								 if (p.potential_implementation == SCALAR)
								   Ctilde_c = correction* (-I* (p.mass-n.V) / (1.*D) *g0_c - g0*n.FF (c) + I*g0*A_c);
								 else if (p.potential_implementation == VECTOR)
								   Ctilde_c = correction* (-I* (p.mass*g0_c-n.V*CliffordAlgebra::ONE) / (1.*D) - g0*n.FF (c) + I*g0*A_c);
								 else if (p.potential_implementation == XC){
								   float_type norm_GSD_n = sqrt(norm2(n.psi));
								   float_type  GSD_n= norm2(n.psi);
								   Ctilde_c = correction* (-I* (p.mass*g0_c-n.V*CliffordAlgebra::ONE-p.c0*(p.xc_rs/4.0)*(sqrt(M_PI))*(1.-p.xc_g*p.xc_rs*p.xc_ksi)*sqrt(norm_GSD_n)*copysign(1.,GSD_n)*std::log(4.*p.xc_kc/sqrt(4.*M_PI*GSD_n))*CliffordAlgebra::ONE) / (1.*D) - g0*n.FF (c) + I*g0*A_c);
								   // 	std::cout << "psi=" << n.psi << "dot=" <<dot(n.psi, n.psi) << std::endl;
								 }
								 else if (p.potential_implementation == VF_XC){
								   // 	 vf_xc term: a/(8eg)*{ln(k0^2/k1^2)+1}
								   Ctilde_c = correction* (-I* (p.mass-n.V-p.xc_alpha/(8.*p.xc_g)*(std::log(p.c0*p.c0/(p.xc_kc*p.xc_kc))+1.)) / (1.*D)*g0_c - g0*n.FF (c) + I*g0*A_c);
								   // Temporary:
								   //      set kc=0.1, alpha =1 and c0=0.1 and you get something that sort of works    
								   // 	float_type structure_constant=p.xc_alpha;
								   //      Ctilde_c = n.sqrt_g* (-I* (p.mass-n.V-structure_constant/(8.*5)*(std::log(p.xc_kc)+std::log(p.c0*p.c0)+1.)) / (1.*D)*g0_c - g0*n.FF (c) + I*g0*A_c);
								 }      
								 else if (p.potential_implementation == NORM){
								   float_type temp= p.c0*norm2(n.psi);  //real(dot(n.psi, n.psi));
								   Ctilde_c = correction* (-I* (p.mass*g0_c-n.V*CliffordAlgebra::ONE+temp*CliffordAlgebra::ONE) / (1.*D) - g0*n.FF (c) + I*g0*A_c);
								 }
								 else error ("ERROR in "+LINE+": Potential implementation ill-defined.");
								 
								 //       std::cout <<"det(C)="  <<det(Ctilde_c) << std::endl;
								 Matrix< complex< float_type >,  LS> U1 = CliffordAlgebra::ONE - p.dt/2.*Ctilde_c;
								 Matrix< complex< float_type >,  LS> U2 = CliffordAlgebra::ONE + p.dt/2.*Ctilde_c;
								 Matrix< complex< float_type >,  LS> coll = inv (U1) * U2;
								 
								 for (size_type J=0; J<LS; ++J) {
								   
								   if (!n.psi_fixed (J)){   
								     
								     
								     n.psi (J) = 0;
								     
								     
								     // forcing term
								     if (p.potential_implementation == VF_XC) //kf does it need the curvature terms here?
								       for (size_type i=0; i<D; ++i) {
									 const Node& nn = * (n.nn (Lattice<LT>::lattice_index (i, SIGN (J))));
									 // *** sqrt_g for Hermitiancy of Hamiltonian
									 // vf_xc term: +a/(8eg*k1^2)*nabla^2
									 float_type xc_factor=p.xc_alpha/(8.*p.xc_g*p.xc_kc*p.xc_kc);
									 n.psi (J) -= (correction*  n.tetrad (c, i) - (c==i)) * ((nn.psi_temp (J) - n.psi_temp (J)))+(nn.psi_temp (J)*xc_factor - n.psi_temp (J)*xc_factor)*(nn.psi_temp (J)*xc_factor - n.psi_temp (J)*xc_factor );
								       }
								       else
									 for (size_type i=0; i<D; ++i) {
									   const Node& nn = * (n.nn (Lattice<LT>::lattice_index (i, SIGN (J))));
									   // *** sqrt_g for Hermitiancy of Hamiltonian
									   n.psi (J) -= (correction*  n.tetrad (c, i) - (c==i)) * (nn.psi_temp (J) - n.psi_temp (J));
									 }
									 
									 
									 
									 // collision term
									 for (size_type K=0; K<LS; ++K) {
									   n.psi (J) += coll (J, K) * n.psi_temp (K);
									 }
								   }
								 }
							       }
							       
							       
							       
							       
							       /**
								* @brief Streaming step (psi -> psi_temp)
								* @param n Node
								* @param c spatial direction of the splitted operator, (x, y, z) = (0, 1, 2)
								*/
							       //kf lattice index defines the +- 4 direction
// 							       kf there are n.nn(9 options) and we choose up down i.e. x1,+x4,y2,y3
							       inline void stream (Node& n, size_type c) {
								 for (size_type J=0; J<LS; ++J) {
								   const Node& nn = * (n.nn (Lattice<LT>::lattice_index (c, -SIGN (J)))); //* index of velocity componet (9)C and ( + + - - )
								if (!n.psi_fixed (J)) n.psi_temp (J) = nn.psi (J);
								 }
							       }
							       
							       
							       /**
								* @brief Back rotation step (psi_temp -> psi)
								* @param n Node
								* @param c spatial direction of the splitted operator, (x, y, z) = (0, 1, 2)
								*/
							       inline void rotate_back (Node& n, size_type c) {
								 n.psi = CliffordAlgebra::X (c) * n.psi_temp;
								 
								 // Check rotation
								 for (int K=0; K<LS; K++) {
								   std::complex<float_type> psi_K = 0;
								   for (int J=0; J<LS; J++) psi_K += CliffordAlgebra::X (c) (K, J) *n.psi_temp (J);
								   ASSERT2 (abs (n.psi (K) - psi_K) < 1e-15)
								 }
							       }
							       
							       
							       
							       
							       //======================= DERIVATIVES ================================
							       
							       inline float_type laplace_cotetrad (const Node& n, const size_type a, const size_type i) const {
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   return laplace_cotetrad_bulk (n, a, i);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   return (2* laplace_cotetrad (n1, a, i) - laplace_cotetrad (n2, a, i));
								 }
							       }
							       
							       inline float_type laplace_cotetrad_bulk (const Node& n, const size_type a, const size_type i) const {
								 ASSERT2 (nodes.is_derivative_bulk_node (n))
								 float_type result = 0;
								 for (size_type l=1; l<Lattice<LT>::Q; l++) {
								   const Node& nn = * (n.nn (Lattice<LT>::l_inv (l)));
								   result += Lattice<LT>::w (l) * (nn.cotetrad (a, i) -  n.cotetrad (a, i));
								 }
								 return result*2./ (p.dt*p.dt*Lattice<LT>::C_SQ);
							       }
							       
							       
							       inline float_type dcotetrad (const Node& n, const size_type a, const size_type i, const size_type x) const {
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   return dcotetrad_bulk (n,a,i,x);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   return (2* dcotetrad (n1, a, i, x) - dcotetrad (n2, a, i, x));
								 }
							       }
							       
							       inline float_type dcotetrad_bulk (const Node& n, const size_type a, const size_type i, const size_type x) const {
								 ASSERT2 (nodes.is_derivative_bulk_node (n))
								 float_type result = 0;
								 for (size_type l=1; l<Lattice<LT>::Q; l++) {
								   const Node& nn = * (n.nn (Lattice<LT>::l_inv (l)));
								   result += Lattice<LT>::w (l) *Lattice<LT>::c (x,l) * (nn.cotetrad (a, i) - 1./2.*p.dt*p.dt*Lattice<LT>::C_SQ*nn.laplace_cotetrad (a, i));
								 }
								 return result/ (p.dt*Lattice<LT>::C_SQ);
							       }
							       
							       inline float_type laplace_h (const Node& n, const size_type i) const {
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   return laplace_h_bulk (n, i);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   return (2* laplace_h (n1, i) - laplace_h (n2, i));
								 }
							       }
							       
							       inline float_type laplace_h_bulk (const Node& n, const size_type i) const  {
								 ASSERT2 (nodes.is_derivative_bulk_node (n))
								 float_type result = 0;
								 for (size_type l=1; l<Lattice<LT>::Q; l++) {
								   const Node& nn = * (n.nn (Lattice<LT>::l_inv (l)));
								   result += Lattice<LT>::w (l) * (nn.h (i) -  n.h (i));
								 }
								 return result*2./ (p.dt*p.dt*Lattice<LT>::C_SQ);
							       }
							       
							       inline float_type dh (const Node& n, const size_type i, const size_type x) const {
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   return dh_bulk (n, i, x);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   return (2* dh (n1, i, x) - dh (n2, i, x));
								 }
							       }
							       
							       inline float_type dh_bulk (const Node& n, const size_type i, const size_type x) const  {
								 ASSERT2 (nodes.is_derivative_bulk_node (n))
								 float_type result = 0;
								 for (size_type l=1; l<Lattice<LT>::Q; l++) {
								   const Node& nn = * (n.nn (Lattice<LT>::l_inv (l)));
								   result += Lattice<LT>::w (l) *Lattice<LT>::c (x,l) * (nn.h (i) - 1./2.*p.dt*p.dt*Lattice<LT>::C_SQ*nn.laplace_h (i));
								 }
								 return result/ (p.dt*Lattice<LT>::C_SQ);
							       }
							       
							       
							       
							       inline float_type laplace_g (const Node& n, const size_type i, const size_type j) const {
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   return laplace_g_bulk (n, i, j);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   return (2* laplace_g (n1, i, j) - laplace_g (n2, i, j));
								 }
							       }
							       
							       inline float_type laplace_g_bulk (const Node& n, const size_type i, const size_type j) const  {
								 ASSERT2 (nodes.is_derivative_bulk_node (n))
								 float_type result = 0;
								 for (size_type l=1; l<Lattice<LT>::Q; l++) {
								   const Node& nn = * (n.nn (Lattice<LT>::l_inv (l)));
								   result += Lattice<LT>::w (l) * (nn.g (i, j) -  n.g (i, j));
								 }
								 return result*2./ (p.dt*p.dt*Lattice<LT>::C_SQ);
							       }
							       
							       inline float_type dg (const Node& n, size_type i, size_type j, size_type x) {
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   return dg_bulk (n,i,j,x);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   return (2* dg (n1, i,j,x) - dg (n2, i,j,x));
								 }
							       }
							       
							       
							       inline float_type dg_bulk (const Node& n, size_type i, size_type j, size_type x) {
								 ASSERT2 (nodes.is_derivative_bulk_node (n))
								 float_type result = 0;
								 for (size_type l=1; l<Lattice<LT>::Q; l++) {
								   const Node& nn = * (n.nn (Lattice<LT>::l_inv (l)));
								   result += Lattice<LT>::w (l) *Lattice<LT>::c (x,l) * (nn.g (i,j)-1./2.*p.dt*p.dt*Lattice<LT>::C_SQ*nn.laplace_g (i, j));
								 }
								 return result/ (p.dt*Lattice<LT>::C_SQ);
							       }
							       
							       
							       inline float_type dL (const Node& n, size_type i, size_type j, size_type k, size_type x) {
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   return dL_bulk (n, i,j, k, x);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   return (2* dL (n1, i,j, k,  x) - dL (n2, i,j, k,  x));
								 }
							       }
							       
							       
							       inline float_type dL_bulk (const Node& n, size_type i, size_type j, size_type k, size_type x) {
								 ASSERT2 (nodes.is_derivative_bulk_node (n))
								 float_type result = 0;
								 for (size_type l=1; l<Lattice<LT>::Q; l++) {
								   const Node& nn = * (n.nn (Lattice<LT>::l_inv (l)));
								   result += Lattice<LT>::w (l) *Lattice<LT>::c (x,l) * (nn.L (i,j,k));         // receive information
								 }
								 return result/ (p.dt*Lattice<LT>::C_SQ);
							       }
							       
							       
							       /// SLOW, but fine for testing and debugging
							       float_type laplacian (function<float_type (Vector<float_type, D>) > func, Vector<float_type, D> xyz) {
								 
								 Node& n = nodes.get_node (xyz);
								 
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   float_type result = 0;
								   for (size_type l=1; l<Lattice<LT>::Q; l++) {
								     Vector<float_type, D> next_xyz (Lattice<LT>::p_to_xyz (n.nn (Lattice<LT>::l_inv (l))->pos));
								     result +=  Lattice<LT>::w (l) * (func (next_xyz) - func (xyz));
								   }
								   return result*2./ (p.dt*p.dt*Lattice<LT>::C_SQ);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   Vector<float_type, D> xyz1 = Lattice<LT>::p_to_xyz (n1.pos);
								   Vector<float_type, D> xyz2 = Lattice<LT>::p_to_xyz (n2.pos);
								   return (2* laplacian (func, xyz1) - laplacian (func, xyz2));
								 }
							       }
							       
							       
							       /// SLOW, but fine for testing and debugging
							       float_type differentiate (function<float_type (Vector<float_type, D>) > func, Vector<float_type, D> xyz, size_type x) {
								 
								 Node& n = nodes.get_node (xyz);
								 
								 // get boundary index
								 size_type bid = nodes.get_derivative_boundaryID (n);
								 // if not a boundary node, calculate isotropic lattice derivative
								 if (bid == -1) {
								   float_type result = 0;
								   for (size_type l=1; l<Lattice<LT>::Q; l++) {
								     Vector<float_type, D> next_xyz (xyz + p.dt*Lattice<LT>::c (l));
								     result +=  Lattice<LT>::w (l) *Lattice<LT>::c (x,l) * (func (next_xyz) - 1./2.*p.dt*p.dt*Lattice<LT>::C_SQ*laplacian (func, next_xyz));
								   }
								   return result/ (p.dt*Lattice<LT>::C_SQ);
								 }
								 // if boundary node,  extrapolate value from neighbouring nodes
								 else {
								   size_type nid1 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].first;
								   size_type nid2 = nodes.get_boundary_element (bid).extrapolation_nodeIDs[0].second;
								   
								   const Node& n1 = nodes[nid1];
								   const Node& n2 = nodes[nid2];
								   Vector<float_type, D> xyz1 = Lattice<LT>::p_to_xyz (n1.pos);
								   Vector<float_type, D> xyz2 = Lattice<LT>::p_to_xyz (n2.pos);
								   return (2* differentiate (func, xyz1, x) - differentiate (func, xyz2, x));
								 }
							       }
							       
							       
							       float_type differentiate (function<float_type (Vector<float_type, D>) > func, Vector<float_type, D> xyz, size_type x, size_type y) {
								 
								 function<float_type (Vector<float_type, D>) > dfunc_dx = [&] (Vector<float_type, D> xyz)->float_type {
								   return differentiate (func, xyz, x);
								 };
								 return differentiate (dfunc_dx, xyz, y);
							       }
							       
							       
							       float_type differentiate (function<float_type (Vector<float_type, D>) > func, Vector<float_type, D> xyz, size_type x, size_type y, size_type z) {
								 
								 function<float_type (Vector<float_type, D>) > dfunc_dx_dy = [&] (Vector<float_type, D> xyz)->float_type {
								   return differentiate (func, xyz, x, y);
								 };
								 return differentiate (dfunc_dx_dy, xyz, z);
							       }
							       
							       
							       
							       
							       
							       
							       //======================= SIMULATION RUN ================================
							       
							       /**
								*        Runs the simulation
								*/
							       void run() {
								 
								 
								 #ifndef LB_NDEBUG2
								 {
								   Tests<LT,D0,LS> tests (this);
								   tests.perform_tests();
								 }
								 #endif
								 
								 t=0;
								 write (t);   // t=0
								 
								 Timer timer1;
								 timer1.start();
								 while (t<=p.T_MAX) {
								   
								   if (t %p.time_step==0) {
								     cout << "===================================================" << endl;
								     cout << "time/timestep: " << (t/p.time_step) << "/" << (p.T_MAX/p.time_step) << "\t(" << int (100*double (t) /double (p.T_MAX)) << "%)" << endl;
								   }
								   
								   step (t*p.dt);  // step from t to t+1
								   t++;
								   
								   if (t%p.time_step==0) {
								     write (t);
								   }
								   
								   // ============== NAN Check ================
								   size_type nid = rand() %nodes.size();
								   if (norm2 (nodes[nid].psi) != norm2 (nodes[nid].psi)) {
								     cout << norm2 (nodes[nid].psi) << endl;
								     //rename ( path.c_str(), ( path + string ( "_NAN" ) ).c_str() );
								     cout << "\nNAN\n";
								     return;
								   }
								   // =========================================
								   
								 }
								 timer1.stop();
								 
								 t--;
								 write_at_end (t);
								 
								 double simtime = timer1.duration();
								 cout << "\nFinished.\nSimulation Time: " << int (simtime) /3600
								 <<  ":" << (int (simtime) %3600) /60
								 <<  ":" << (int (simtime) %3600) %60
								 <<  "." << int (round (1000* (simtime - int (simtime))))
								 <<  " (H:M:S)" << endl << endl
								 << "===================================================" << endl
								 << "===================================================" << endl << endl;
							       }
							       
							       
							       
							       void step (float_type t) {
								 
								 // update geometry
								 if (p.geometry_type == DYNAMIC) {
								   cout <<  "Updating geometry..." << endl;
								   update_geometry();
								 }
								 
								 // update potentials at current time t
								 if (p.potential_type == DYNAMIC) {
								   update_potentials();
								 }
								 
								 
								 #if LB_OMP
								 #pragma omp parallel for
								 #endif
								 for (size_type nid=0; nid<nodes.size(); nid++) {
								   nodes[nid].psip = nodes[nid].psi;
								 }
								 
								 
								 for (size_type c=0; c<D; ++c) {
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type nid=0; nid<nodes.size(); nid++)
								     rotate (nodes[nid], c);
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type nid=0; nid<nodes.size(); nid++)
								     collide (nodes[nid], c);
								   
// 								   update_boundary_by_extrapolation (c);
								   
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type nid=0; nid<nodes.size(); nid++)
								     stream (nodes[nid], c);
								   
								   update_boundary_by_extrapolation (c);
								   
								   
								   #if LB_OMP
								   #pragma omp parallel for
								   #endif
								   for (size_type nid=0; nid<nodes.size(); nid++)
								     rotate_back (nodes[nid], c);
								   
								   //             // Checks
								   //             for ( size_type nid=0; nid<nodes.size(); nid++ ) {
								   //                 const Node& n = nodes[nid];
								   //                 if ( norm2 ( n.psi ) != norm2 ( n.psi ) ) {
								   //                     HERE
								   //                     cout << norm2 ( n.psi ) << endl;
								   //                     EXIT
								   //                 }
								   //             }
								 }
							       }
							       
							       
							       
							       
							       
							       
							       
							       
							       
							       
							       
							       //======================= WRITER ================================
							       
							       void write (sim_time_type t) {
								 // do the rest in a parallel thread:
								 if (writer_thread.joinable()) {
								   writer_thread.join();
								 }
								 
								 writer.update_observableCache(); // update observables
								 writer_thread = std::thread (
								   [&,t]() {
								     writer.update(); // update time-vectors (norm(t), psi(t)...)
								 writer.write (t);   // write
								   }
								 );
								 
								 /// DEBUGGING
								 //       if (writer_thread.joinable()) {
								 //         writer_thread.join();
								 //       }
							       }
							       
							       void write_at_end (sim_time_type t) {
								 // wait for the previous writer thread to finish
								 if (writer_thread.joinable()) {
								   writer_thread.join();
								 }
								 
								 writer.update_observableCache();
								 writer.update();
								 if (p.Emin!=0){
								   if(p.Ef<=p.Emin) std::cout << " E fermi <= E min, please check cofig file " << std::endl;
								   writer.filter_psi_range();
								   writer.write(t+2); //to write filtered stuff if need
								   
								 }
								 else if (p.Ef!=0) {
								   writer.filter_psi_t();
								   writer.write(t+2); //to write filtered stuff if need
								   
								 }
								 writer.write_at_end (t);
							       }
							       
								};
								
								#endif //define LB_HPP
								
								
								
								
								
								
								
								