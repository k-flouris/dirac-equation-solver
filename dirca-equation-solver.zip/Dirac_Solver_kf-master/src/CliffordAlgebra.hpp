/**
 * \file
 * \author Jens-Daniel Debus,  ETH Zurich
 * \date 2015
 * \brief This file contains objected related to the Spinor Algebra (Clifford Algebra)
 * \details
 */
#ifndef CLIFFORD_ALGEBRA_HPP
#define CLIFFORD_ALGEBRA_HPP

#include "macros.hpp"
#include "tensor.hpp"

/**
 * \brief This class contains objected related to the Spinor Algebra (Clifford Algebra)
 * \details
 */
class CliffordAlgebra {

    public:
    constexpr static const size_type LS = 4;            ///< Spinor dimensions
    constexpr static const size_type D  = 3;            ///< Spatial dimensions

    
    /**
     * @brief ONE(I,J) = \f$ {\mathbbm 1}_{IJ} \f$ is the unit matrix.
     */
    constexpr static const Matrix<complex<float_type>, LS> ONE =             {   
      {
                    1,           0,           0,           0,
                    0,           1,           0,           0,
                    0,           0,           1,           0,
                    0,           0,           0,           1
                }
            };
	    
	    
    
    /**
     * @brief GAMMA0(I,J) = \f$ \gamma^0_{IJ} \f$,  where \f$ \gamma_0 = \gamma^0 \f$
     *        is the \f$ \gamma^0 \f$-matrix in Dirac representation.
     */
    constexpr static const Matrix<complex<float_type>, LS> GAMMA0 =             {   
      {
                    1,           0,           0,           0,
                    0,           1,           0,           0,
                    0,           0,          -1,           0,
                    0,           0,           0,          -1
                }
            };
            
            
    /**
     * @brief GAMMA(a)(I,J) = \f$ \gamma^a_{IJ} \f$, where \f$ \gamma^a \f$
     *        are the contravariant spatial \f$ \gamma \f$-matrices in Dirac representation
     *        Index convention: a = (0, 1, 2) = (x, y, z)
     */
    constexpr static const Vector<Matrix<complex<float_type>, LS>, D> GAMMA = {
        {            
            Matrix<complex<float_type>, LS>
            {   {
                    0,           0,           0,           1,
                    0,           0,           1,           0,
                    0,          -1,           0,           0,
                    -1,           0,           0,           0
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    0,           0,           0,          complex<float_type> ( 0,-1 ),
                    0,           0,           complex<float_type> ( 0,1 ),           0,
                    0,           complex<float_type> ( 0,1 ),           0,           0,
                    complex<float_type> ( 0,-1 ),           0,           0,           0
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    0,           0,           1,           0,
                    0,           0,           0,          -1,
                    -1,           0,           0,           0,
                    0,           1,           0,           0
                }
            }
        }
    };


            

    /**
     * @brief GAMMA_CO(a)(I,J) = \f$ \gamma_{a, IJ} \f$,  where \f$ \gamma_a = \eta_{ab} \gamma^b = - \gamma^a \f$
     *        are the covariant spatial \f$ \gamma \f$-matrices in Dirac representation.
     * 	      Index convention: a = (0, 1, 2) = (x, y, z)
     */
    constexpr static const Vector<Matrix<complex<float_type>, LS>, D> GAMMA_CO = {
        {
            Matrix<complex<float_type>, LS>
            {   {
                    0,           0,           0,           -1,
                    0,           0,           -1,           0,
                    0,          1,           0,           0,
                    1,           0,           0,           0
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    0,           0,           0,          complex<float_type> ( 0,1 ),
                    0,           0,           complex<float_type> ( 0,-1 ),           0,
                    0,           complex<float_type> ( 0,-1 ),           0,           0,
                    complex<float_type> ( 0,1 ),           0,           0,           0
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    0,           0,           -1,           0,
                    0,           0,           0,          1,
                    1,           0,           0,           0,
                    0,           -1,           0,           0
                }
            }
        }
    };


    /**
     * @brief X(c)(I,J) = \f$ X_{c, IJ} \f$ are the unitary matrices that diagonalize
     *        the \f$ \alpha \f$-matrices (\f$\alpha^c = \gamma^0 \gamma^c\f$):
     *        \f$(X_c)^\dagger \alpha^c X_c = diag(1, 1, -1, -1) = \gamma^0\f$
     *        Index convention: c = (0, 1, 2) = (x, y, z)
     */
    constexpr static const Vector<Matrix<complex<float_type>, LS>, D> X = {
        {
            Matrix<complex<float_type>, LS>
            {   {
                    1./sqrt ( 2 ), 0, -1./sqrt ( 2 ), 0,
                    0,  1./sqrt ( 2 ), 0, -1./sqrt ( 2 ),
                    0,  1./sqrt ( 2 ), 0,  1./sqrt ( 2 ),
                    1./sqrt ( 2 ), 0,  1./sqrt ( 2 ), 0
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    0, complex<float_type> ( 0,1./sqrt ( 2. ) ), 0,  1./sqrt ( 2 ),
                    complex<float_type> ( 0,-1./sqrt ( 2. ) ), 0, complex<float_type> ( 0,1./sqrt ( 2. ) ), 0,
                    -1./sqrt ( 2 ), 0, -1./sqrt ( 2 ), 0,
                    0, -1./sqrt ( 2 ), 0,  complex<float_type> ( 0,-1./sqrt ( 2. ) )
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    1./sqrt ( 2 ), 0, 0, -1./sqrt ( 2 ),
                    0, -1./sqrt ( 2 ), 1./sqrt ( 2 ), 0,
                    1./sqrt ( 2 ), 0, 0,  1./sqrt ( 2 ),
                    0,  1./sqrt ( 2 ), 1./sqrt ( 2 ), 0
                }
            }
        }
    };

     
    /**
     * @brief X_inv(c)(I,J) = \f$ (X_c^{-1})_{IJ} = (X_c^\dagger)_{IJ} \f$
     * Index convention: c = (0, 1, 2) = (x, y, z)
     */
    constexpr static const Vector<Matrix<complex<float_type>, LS>, D> X_inv = {
        {
            Matrix<complex<float_type>, LS>
            {   {
                    1./sqrt ( 2 ), 0, 0, 1./sqrt ( 2 ),
                    0, 1./sqrt ( 2 ), 1./sqrt ( 2 ), 0,
                    -1./sqrt ( 2 ), 0, 0, 1./sqrt ( 2 ),
                    0, -1./sqrt ( 2 ), 1./sqrt ( 2 ), 0
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    0, complex<float_type> ( 0,1./sqrt ( 2. ) ), -1./sqrt ( 2 ), 0,
                    complex<float_type> ( 0,-1./sqrt ( 2. ) ), 0, 0, -1./sqrt ( 2 ),
                    0, complex<float_type> ( 0,-1./sqrt ( 2. ) ), -1./sqrt ( 2 ), 0,
                    1./sqrt ( 2 ), 0, 0, complex<float_type> ( 0,1./sqrt ( 2. ) )
                }
            },
            Matrix<complex<float_type>, LS>
            {   {
                    1./sqrt ( 2 ), 0, 1./sqrt ( 2 ), 0,
                    0, -1./sqrt ( 2 ), 0, 1./sqrt ( 2 ),
                    0, 1./sqrt ( 2 ), 0, 1./sqrt ( 2 ),
                    -1./sqrt ( 2 ), 0, 1./sqrt ( 2 ), 0
                }
            }
        }
    };


    
    /**
     * @brief sigma(c)(a,b)(I,J) = \f$ \sigma_{c, ab, IJ} \f$ are defined by the
     *        commutator of the covariant \f$ \gamma \f$-matrices,  rotated by \f$ X_c \f$:
     *        \f$ \sigma_{c, ab} = \frac{\imath}{2} X_c^\dagger [\gamma_a, \gamma_b] X_c \f$
     *        Index convention: a, b, c = (0, 1, 2) = (x, y, z)
     */
    constexpr static Vector<Tensor<Tensor<complex<float_type>,LS,2>, D, 2, NO_SYM>, D> sigma = {{
            Tensor<Tensor<complex<float_type>,LS,2>, D, 2, NO_SYM>{{
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ),
                            complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ),
                            complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    }
                }
            },
            Tensor<Tensor<complex<float_type>,LS,2>, D, 2, NO_SYM>{{             
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ),
                            complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ),
                            complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    }
                }
            },
            Tensor<Tensor<complex<float_type>,LS,2>, D, 2, NO_SYM>{{ 
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ),
                            complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ),
                            complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,1 ),
                            complex<float_type> ( 0,1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,-1 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ),
                            complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( -1,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    },
                    Tensor<complex<float_type>,LS,2>{{
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ),
                            complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 ), complex<float_type> ( 0,0 )
                        }
                    }
                }
            }
        }
    };
};


constexpr Matrix<complex<float_type>, CliffordAlgebra::LS> CliffordAlgebra::ONE;
constexpr Matrix<complex<float_type>, CliffordAlgebra::LS> CliffordAlgebra::GAMMA0;
constexpr Vector<Matrix<complex<float_type>, CliffordAlgebra::LS>, CliffordAlgebra::D> CliffordAlgebra::GAMMA;
constexpr Vector<Matrix<complex<float_type>, CliffordAlgebra::LS>, CliffordAlgebra::D> CliffordAlgebra::GAMMA_CO;
constexpr Vector<Matrix<complex<float_type>, CliffordAlgebra::LS>, CliffordAlgebra::D> CliffordAlgebra::X;
constexpr Vector<Matrix<complex<float_type>, CliffordAlgebra::LS>, CliffordAlgebra::D> CliffordAlgebra::X_inv;
constexpr Vector<Tensor<Tensor<complex<float_type>,CliffordAlgebra::LS,2>, CliffordAlgebra::D, 2, NO_SYM>, CliffordAlgebra::D>  CliffordAlgebra::sigma;

#endif // !defined CLIFFORD_ALGEBRA_HPP


