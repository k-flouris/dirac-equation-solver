//Copyright (c) 2016 Jens-Daniel Debus, ETH Zurich
#ifndef TESTS_HPP
#define TESTS_HPP

#include "macros.hpp"
#include "Lattice.hpp"


// forward-declaration of pointer-types
template<LatticeType LT, size_type D0, size_type LS>
class LB;
template<LatticeType LT, size_type D0, size_type LS>
class NodeCache;


//======================= WRITER POOL ================================

template<LatticeType LT, size_type D0, size_type LS>
class Tests {

     LB<LT,D0,LS>* lb;

public:  
      constexpr static size_type D = Lattice<LT>::D; // Spatial dimension
  
     Tests ( LB<LT,D0,LS>* lb_ ) : lb ( lb_ ) {}

     void perform_tests() const {
       test_lattice();
       test_metric();
     }

     void test_lattice() const {
          cout << "Testing lattice..." << flush;

          // Check sorting by norm
          float_type norm = 0;
          for ( size_type l=0; l<Lattice<LT>::Q; l++ ) {
               float_type norm1 = 0;
               for ( size_type i=0; i<D; i++ )
                    norm1 += Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( i,l );
               ASSERT2 ( norm1 - norm + .1 >= 0 );
               norm = norm1;
          }

          // Check normalization of weights
          float_type sum=0;
          for ( size_type l=0; l<Lattice<LT>::Q; l++ )
               sum += Lattice<LT>::w ( l );
          ASSERT2 ( abs ( 1 - sum ) < EPSILON );

          float_type sum1=0;
          for ( size_type l=0; l<Lattice<LT>::Q; l++ )
               sum1 += Lattice<LT>::w ( l );
          ASSERT2 ( abs ( 1 - sum1 ) < EPSILON );

          // Check 1. Hermite polynomial
          for ( size_type i=0; i<D; i++ ) {

               float_type sum = 0.;
               for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                    sum += Lattice<LT>::w ( l ) *Lattice<LT>::c ( i,l );
               ASSERT2 ( abs ( 0 - sum ) < EPSILON );

               float_type sum1 = 0.;
               for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                    sum1 += Lattice<LT>::w ( l ) *Lattice<LT>::c ( i,l );
               ASSERT2 ( abs ( 0 - sum1 ) < EPSILON );

               for ( size_type j=0; j<D; j++ ) {
                    float_type sum = 0.;
                    for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                         sum += Lattice<LT>::w ( l ) *Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l );
                    ASSERT2 ( abs ( Lattice<LT>::C_SQ* ( i==j ) - sum ) < EPSILON );
               }

               for ( size_type j=0; j<D; j++ ) {
                    float_type sum1 = 0.;
                    for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                         sum1 += Lattice<LT>::w ( l ) *Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l );
                    ASSERT2 ( abs ( Lattice<LT>::C_SQ* ( i==j ) - sum1 ) < EPSILON );
               }
          }

          // Check 2. Hermite polynomial
          for ( size_type i=0; i<D; i++ ) for ( size_type j=0; j<D; j++ ) {

                    float_type sum = 0.;
                    for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                         sum += Lattice<LT>::w ( l ) * ( Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l )- Lattice<LT>::C_SQ* ( i==j ) ) ;
                    ASSERT2 ( abs ( 0 - sum ) < EPSILON );

                    float_type sum1 = 0.;
                    for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                         sum1 += Lattice<LT>::w ( l ) * ( Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l )- Lattice<LT>::C_SQ* ( i==j ) ) ;
                    ASSERT2 ( abs ( 0 - sum1 ) < EPSILON );

                    for ( size_type k=0; k<D; k++ ) {
                         float_type sum = 0.;
                         for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                              sum += Lattice<LT>::w ( l ) * ( Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l )- Lattice<LT>::C_SQ* ( i==j ) ) * Lattice<LT>::c ( k,l ) ;
                         ASSERT2 ( abs ( 0 - sum ) < EPSILON );
                    }

                    for ( size_type k=0; k<D; k++ ) {
                         float_type sum1 = 0.;
                         for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                              sum1 += Lattice<LT>::w ( l ) * ( Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l )- Lattice<LT>::C_SQ* ( i==j ) ) * Lattice<LT>::c ( k,l ) ;
                         ASSERT2 ( abs ( 0 - sum1 ) < EPSILON );
                    }

                    for ( size_type k=0; k<D; k++ ) for ( size_type m=0; m<D; m++ ) {
                              float_type sum = 0.;
                              for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                                   sum += Lattice<LT>::w ( l ) * ( Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l ) - Lattice<LT>::C_SQ* ( i==j ) ) * ( Lattice<LT>::c ( k,l ) *Lattice<LT>::c ( m,l )- Lattice<LT>::C_SQ* ( k==m ) );
                              ASSERT2 ( abs ( Lattice<LT>::C_SQ*Lattice<LT>::C_SQ* ( ( i==k ) * ( j==m ) + ( i==m ) * ( j==k ) ) - sum ) < EPSILON );
                         }

                         for ( size_type k=0; k<D; k++ ) for ( size_type m=0; m<D; m++ ) {
                              float_type sum1 = 0.;
                              for ( size_type l=0; l<Lattice<LT>::Q; l++ )
                                   sum1 += Lattice<LT>::w ( l ) * ( Lattice<LT>::c ( i,l ) *Lattice<LT>::c ( j,l ) - Lattice<LT>::C_SQ* ( i==j ) ) * ( Lattice<LT>::c ( k,l ) *Lattice<LT>::c ( m,l )- Lattice<LT>::C_SQ* ( k==m ) );
                              ASSERT2 ( abs ( Lattice<LT>::C_SQ*Lattice<LT>::C_SQ* ( ( i==k ) * ( j==m ) + ( i==m ) * ( j==k ) ) - sum1 ) < EPSILON );
                         }
               }

          cout << " Done" << endl;
     }
     
     
     
     void test_metric() const {
       
       cout << "Testing inverse metric..." << flush;
       
       // Check equilibrium function
       for ( size_type nid=0; nid<lb->nodes.size(); nid++ ) {
         const auto& n = lb->nodes[nid];
         
         Tensor<float_type, D, 2> sum ( n.g*n.g_inv );
         for ( size_type i=0; i<D; i++ ) for ( size_type j=0; j<D; j++ )
           ASSERT2 ( abs ( sum ( i,j ) - ( i==j ) ) < EPSILON );
         
         Tensor<float_type, D, 2> sum2 ( n.g_inv * n.g );
         for ( size_type i=0; i<D; i++ ) for ( size_type j=0; j<D; j++ )
           ASSERT2 ( abs ( sum2 ( i,j ) - ( i==j ) ) < EPSILON );
       }
       
       cout << " Done" << endl;
     }

};





#endif // !defined TESTS_HPP


